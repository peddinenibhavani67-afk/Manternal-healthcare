import React, { useState } from 'react';
import { 
  X, 
  AlertTriangle, 
  PhoneCall, 
  MapPin, 
  Navigation, 
  Ambulance, 
  CheckCircle2, 
  Clock, 
  Hospital as HospitalIcon,
  ShieldAlert,
  HelpCircle,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { EMERGENCY_HOTLINES } from '../data/mockData';
import { EmergencySeverity } from '../types';

export const EmergencyModal: React.FC = () => {
  const { 
    isSosModalOpen, 
    closeSosModal, 
    submitEmergencyRequest, 
    activeEmergency,
    hospitals,
    currentUser,
    userLocation,
    setUserLocation
  } = useApp();

  const [patientName, setPatientName] = useState(currentUser.name || '');
  const [patientPhone, setPatientPhone] = useState(currentUser.phone || '');
  const [gestationalWeek, setGestationalWeek] = useState(currentUser.gestationalWeek || 32);
  const [address, setAddress] = useState(userLocation.address || 'Village Suburb, Main Road');
  const [landmark, setLandmark] = useState('');
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>(['Heavy vaginal bleeding']);
  const [severity, setSeverity] = useState<EmergencySeverity>('critical');
  const [notes, setNotes] = useState('');
  const [isLocating, setIsLocating] = useState(false);
  const [disclaimerAcknowledged, setDisclaimerAcknowledged] = useState(true);

  if (!isSosModalOpen) return null;

  const symptomsList = [
    { id: 'bleed', label: 'Heavy Vaginal Bleeding', severity: 'critical' as EmergencySeverity },
    { id: 'pain', label: 'Severe Constant Belly / Uterine Pain', severity: 'critical' as EmergencySeverity },
    { id: 'water', label: 'Water Broke / Fluid Gush (Green or Clear)', severity: 'high' as EmergencySeverity },
    { id: 'headache_bp', label: 'Severe Headache, Blurred Vision, Convulsions', severity: 'critical' as EmergencySeverity },
    { id: 'kicks', label: 'Reduced or Absent Fetal Movement', severity: 'high' as EmergencySeverity },
    { id: 'labor', label: 'Intense Contractions (< 3 mins apart)', severity: 'high' as EmergencySeverity },
    { id: 'fever', label: 'High Fever (> 101°F) with Chills', severity: 'moderate' as EmergencySeverity },
  ];

  const toggleSymptom = (label: string, symSeverity: EmergencySeverity) => {
    if (selectedSymptoms.includes(label)) {
      setSelectedSymptoms(prev => prev.filter(s => s !== label));
    } else {
      setSelectedSymptoms(prev => [...prev, label]);
      if (symSeverity === 'critical') setSeverity('critical');
      else if (symSeverity === 'high' && severity !== 'critical') setSeverity('high');
    }
  };

  const handleDetectLocation = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const detected = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          address: `Detected GPS: ${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}`,
          district: 'Detected Region'
        };
        setUserLocation(detected);
        setAddress(detected.address);
        setIsLocating(false);
      },
      (err) => {
        console.warn('Geolocation error:', err.message);
        // Fallback to demo location
        setAddress('Detected GPS: 28.6145° N, 77.2105° E (Sector 14 Corridor)');
        setIsLocating(false);
      },
      { timeout: 7000 }
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientPhone.trim()) {
      alert('Please enter a phone number so the emergency team can reach you.');
      return;
    }

    submitEmergencyRequest({
      patientName: patientName.trim() || 'Urgent Patient',
      patientPhone: patientPhone.trim(),
      gestationalWeek: Number(gestationalWeek) || 30,
      emergencyType: selectedSymptoms.length > 0 ? selectedSymptoms[0] : 'Acute Maternal Emergency',
      severity,
      symptoms: selectedSymptoms.length > 0 ? selectedSymptoms : ['Acute maternal symptoms reported'],
      notes: notes.trim() || undefined,
      location: {
        lat: userLocation.lat,
        lng: userLocation.lng,
        address: address.trim(),
        landmark: landmark.trim() || undefined
      }
    });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-rose-200 overflow-hidden my-6">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white p-4 sm:p-5 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white shrink-0 animate-pulse">
              <Ambulance className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-red-950/40 text-[11px] font-black tracking-wider uppercase px-2 py-0.5 rounded-full border border-red-300/30">
                  SOS PRIORITY DISPATCH
                </span>
                <span className="text-xs text-rose-100">Live Triage</span>
              </div>
              <h2 className="font-heading text-xl sm:text-2xl font-bold tracking-tight">
                Maternal Emergency Assistance
              </h2>
            </div>
          </div>
          <button 
            onClick={closeSosModal}
            className="text-white/80 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Mandatory Safety Notice / Disclaimer Banner */}
        <div className="bg-amber-50 border-b border-amber-200 p-3 sm:p-4 text-xs text-amber-900 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold">
              CRITICAL DISCLAIMER: Submitting this form does NOT guarantee an immediate emergency ambulance dispatch.
            </p>
            <p className="text-amber-800 mt-0.5 leading-relaxed">
              If the patient is unconscious, convulsing, or experiencing severe hemorrhaging, 
              <strong> call 108 or 112 immediately</strong> via phone. Do not wait for website updates.
            </p>
            <div className="mt-2 flex flex-wrap gap-2">
              <a 
                href="tel:108" 
                className="inline-flex items-center gap-1.5 bg-red-600 hover:bg-red-700 text-white font-bold px-2.5 py-1 rounded text-xs shadow-xs"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>Call 108 (Ambulance)</span>
              </a>
              <a 
                href="tel:102" 
                className="inline-flex items-center gap-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold px-2.5 py-1 rounded text-xs shadow-xs"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>Call 102 (Maternal Van)</span>
              </a>
            </div>
          </div>
        </div>

        {/* Content body: If active emergency exists, display live tracker. Otherwise, form */}
        <div className="p-4 sm:p-6 max-h-[75vh] overflow-y-auto">
          {activeEmergency ? (
            <div className="space-y-6">
              {/* Active Emergency Status Banner */}
              <div className="bg-rose-50 border border-rose-200 rounded-xl p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-red-600 animate-ping"></span>
                    <span className="font-bold text-sm text-red-700 uppercase tracking-wide">
                      Active Emergency Dispatch #{activeEmergency.id}
                    </span>
                  </div>
                  <span className="text-xs bg-red-100 text-red-800 font-semibold px-2.5 py-1 rounded-full uppercase">
                    Status: {activeEmergency.status.replace('_', ' ')}
                  </span>
                </div>

                <div className="mt-3 text-sm text-slate-700">
                  <p><strong>Patient:</strong> {activeEmergency.patientName} ({activeEmergency.gestationalWeek} Weeks Gestation)</p>
                  <p><strong>Reported Symptoms:</strong> {activeEmergency.symptoms.join(', ')}</p>
                  <p><strong>Address:</strong> {activeEmergency.location.address}</p>
                </div>
              </div>

              {/* Step Progression Timeline */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4">
                  Emergency Response Milestones
                </h4>
                
                <div className="space-y-4">
                  {/* Step 1 */}
                  <div className="flex items-start gap-3">
                    <div className="w-7 h-7 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0 text-xs">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-800">SOS Triggered & Geolocation Broadcast</p>
                      <p className="text-xs text-slate-500">Transmitted to central maternal emergency dispatch cell.</p>
                    </div>
                  </div>

                  {/* Step 2 */}
                  <div className="flex items-start gap-3">
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs ${
                      activeEmergency.status !== 'submitted'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-amber-500 text-white animate-pulse'
                    }`}>
                      {activeEmergency.status !== 'submitted' ? (
                        <CheckCircle2 className="w-4 h-4" />
                      ) : (
                        <Clock className="w-4 h-4" />
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-800">On-Call Obstetric Triage Review</p>
                      <p className="text-xs text-slate-500">
                        {activeEmergency.dispatcherNotes || 'Assessing severity and matching nearest hospital with 24/7 C-Section & NICU.'}
                      </p>
                    </div>
                  </div>

                  {/* Step 3 */}
                  <div className="flex items-start gap-3">
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs ${
                      activeEmergency.status === 'ambulance_dispatched' || activeEmergency.status === 'reached_hospital' || activeEmergency.status === 'resolved'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-200 text-slate-500'
                    }`}>
                      {activeEmergency.status === 'ambulance_dispatched' || activeEmergency.status === 'reached_hospital' || activeEmergency.status === 'resolved' ? (
                        <CheckCircle2 className="w-4 h-4" />
                      ) : (
                        <span>3</span>
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-bold text-slate-800">Ambulance Dispatched En Route</p>
                      {activeEmergency.assignedAmbulance ? (
                        <div className="mt-1 bg-white border border-slate-200 rounded-lg p-2.5 text-xs text-slate-700 space-y-1">
                          <div className="flex justify-between font-bold">
                            <span>Vehicle: {activeEmergency.assignedAmbulance.vehicleNo}</span>
                            <span className="text-red-600 font-extrabold">
                              ETA ~{activeEmergency.assignedAmbulance.etaMinutes} mins
                            </span>
                          </div>
                          <div>Driver / EMT: {activeEmergency.assignedAmbulance.driverName}</div>
                          <div className="pt-1 flex gap-2">
                            <a 
                              href={`tel:${activeEmergency.assignedAmbulance.driverPhone}`}
                              className="inline-flex items-center gap-1 text-rose-600 hover:text-rose-700 font-bold"
                            >
                              <PhoneCall className="w-3 h-3" />
                              <span>Call Ambulance Driver ({activeEmergency.assignedAmbulance.driverPhone})</span>
                            </a>
                          </div>
                        </div>
                      ) : (
                        <p className="text-xs text-slate-500">Matching closest available transport vehicle...</p>
                      )}
                    </div>
                  </div>

                  {/* Step 4 */}
                  <div className="flex items-start gap-3">
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs ${
                      activeEmergency.status === 'reached_hospital' || activeEmergency.status === 'resolved'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-200 text-slate-500'
                    }`}>
                      {activeEmergency.status === 'reached_hospital' || activeEmergency.status === 'resolved' ? (
                        <CheckCircle2 className="w-4 h-4" />
                      ) : (
                        <span>4</span>
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-800">Receiving Maternity Hospital</p>
                      <p className="text-xs text-slate-600">
                        Designated: <strong>{activeEmergency.assignedHospitalName || hospitals[0]?.name}</strong>
                      </p>
                      <p className="text-[11px] text-slate-400">Emergency C-Section team & Blood Unit kept on standby alert.</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Direct Hospital Contact Buttons */}
              <div>
                <h4 className="text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
                  Immediate Direct Telephone Lines:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {hospitals.slice(0, 2).map((h) => (
                    <div key={h.id} className="border border-slate-200 rounded-lg p-2.5 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-slate-800 line-clamp-1">{h.name}</div>
                        <div className="text-[11px] text-emerald-600 font-semibold">{h.availableMaternityBeds} Beds Available</div>
                      </div>
                      <a 
                        href={`tel:${h.emergencyPhone}`} 
                        className="bg-rose-50 text-rose-700 hover:bg-rose-100 p-2 rounded-lg font-bold flex items-center gap-1 shrink-0"
                      >
                        <PhoneCall className="w-3.5 h-3.5" />
                        <span>Call ER</span>
                      </a>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={closeSosModal}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold text-xs transition cursor-pointer"
                >
                  Close Window
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Patient Basic Info */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-1">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Patient Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    placeholder="e.g. Amina Sharma"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  />
                </div>
                <div className="sm:col-span-1">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={patientPhone}
                    onChange={(e) => setPatientPhone(e.target.value)}
                    placeholder="+1 (555) 000-0000"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  />
                </div>
                <div className="sm:col-span-1">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Gestation (Weeks)
                  </label>
                  <input
                    type="number"
                    min="4"
                    max="44"
                    value={gestationalWeek}
                    onChange={(e) => setGestationalWeek(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Symptoms Checklist */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center justify-between">
                  <span>Select Observed Warning Signs / Emergency Symptoms *</span>
                  <span className="text-[11px] text-rose-600 font-medium">Select all that apply</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {symptomsList.map((sym) => {
                    const isSelected = selectedSymptoms.includes(sym.label);
                    return (
                      <button
                        type="button"
                        key={sym.id}
                        onClick={() => toggleSymptom(sym.label, sym.severity)}
                        className={`text-left p-2.5 rounded-xl border text-xs font-semibold transition flex items-center justify-between cursor-pointer ${
                          isSelected
                            ? 'border-rose-500 bg-rose-50/80 text-rose-900 ring-1 ring-rose-500'
                            : 'border-slate-200 hover:border-rose-200 text-slate-700 bg-white'
                        }`}
                      >
                        <span className="flex-1 pr-2">{sym.label}</span>
                        <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded ${
                          sym.severity === 'critical' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                        }`}>
                          {sym.severity}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Location and Geolocation */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-700">
                    Current Location / Address *
                  </label>
                  <button
                    type="button"
                    onClick={handleDetectLocation}
                    disabled={isLocating}
                    className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-600 hover:text-rose-700 disabled:opacity-50 cursor-pointer"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>{isLocating ? 'Detecting GPS...' : 'Auto-Detect My GPS'}</span>
                  </button>
                </div>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Street, Village, Colony, House number or GPS coordinates"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Prominent Landmark (for Ambulance Driver)
                </label>
                <input
                  type="text"
                  value={landmark}
                  onChange={(e) => setLandmark(e.target.value)}
                  placeholder="e.g. Near Old Water Tank, Primary Health Post, Panchayat Hall"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                />
              </div>

              {/* Additional Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Additional Details / Medical History (Optional)
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Known high blood pressure, prior C-section, water broke 1 hour ago, allergy to penicillin"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none resize-none"
                />
              </div>

              {/* Disclaimer Checkbox */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-start gap-2.5">
                <input
                  type="checkbox"
                  id="disclaimerCheck"
                  checked={disclaimerAcknowledged}
                  onChange={(e) => setDisclaimerAcknowledged(e.target.checked)}
                  className="mt-0.5 rounded text-rose-600 focus:ring-rose-500"
                />
                <label htmlFor="disclaimerCheck" className="text-xs text-slate-600 cursor-pointer select-none">
                  I understand that this digital request alerts local responders and coordinates transport, but in critical or deteriorating situations I must directly telephone emergency lines (<strong>108</strong> / <strong>112</strong>).
                </label>
              </div>

              {/* Submit CTA */}
              <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                <button
                  type="submit"
                  disabled={!disclaimerAcknowledged}
                  className="w-full flex-1 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 disabled:opacity-50 text-white font-extrabold text-sm py-3 px-6 rounded-xl shadow-lg shadow-rose-600/30 flex items-center justify-center gap-2 transform active:scale-95 transition cursor-pointer"
                >
                  <Ambulance className="w-5 h-5" />
                  <span>TRANSMIT EMERGENCY SOS REQUEST</span>
                </button>
                <button
                  type="button"
                  onClick={closeSosModal}
                  className="w-full sm:w-auto px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs transition cursor-pointer"
                >
                  Cancel
                </button>
              </div>

              {/* Emergency Hotline Direct Links */}
              <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
                <span>Immediate Toll-Free Numbers:</span>
                <div className="flex gap-2">
                  <a href="tel:108" className="text-red-600 font-bold hover:underline">108 (Ambulance)</a>
                  <span>•</span>
                  <a href="tel:102" className="text-rose-600 font-bold hover:underline">102 (Maternal)</a>
                  <span>•</span>
                  <a href="tel:112" className="text-slate-800 font-bold hover:underline">112 (Universal)</a>
                </div>
              </div>

            </form>
          )}
        </div>

      </div>
    </div>
  );
};
