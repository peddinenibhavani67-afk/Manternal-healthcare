import React, { useState } from 'react';
import { 
  HeartHandshake, 
  PhoneCall, 
  Ambulance, 
  MapPin, 
  Stethoscope, 
  BookOpen, 
  User, 
  ShieldAlert, 
  Menu, 
  X,
  Radio,
  ChevronDown,
  Building2
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  const { 
    currentUser, 
    switchUserRole, 
    openSosModal, 
    activeEmergency, 
    emergencyRequests,
    hospitalRegistrations
  } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);

  const activeSosCount = emergencyRequests.filter(
    r => r.status === 'submitted' || r.status === 'triaged' || r.status === 'ambulance_dispatched'
  ).length;

  const pendingHospitalCount = hospitalRegistrations.filter(r => r.status === 'pending').length;

  const navLinks = [
    { id: 'home', label: 'Home', icon: HeartHandshake },
    { id: 'emergency', label: 'Emergency Help', icon: Ambulance, highlight: true },
    { id: 'hospitals', label: 'Find Hospitals', icon: MapPin },
    { id: 'hospital_reg', label: 'Register Hospital', icon: Building2 },
    { id: 'doctors', label: 'Consult Doctors', icon: Stethoscope },
    { id: 'care', label: 'Pregnancy Care', icon: BookOpen },
    { id: 'dashboard', label: 'My Dashboard', icon: User },
    { id: 'admin', label: 'Admin Hub', icon: ShieldAlert, badge: (activeSosCount + pendingHospitalCount) > 0 ? (activeSosCount + pendingHospitalCount) : undefined },
  ];

  const handleNavClick = (tabId: string) => {
    setActiveTab(tabId);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-rose-100 shadow-xs">
      {/* Top emergency awareness strip */}
      <div className="bg-gradient-to-r from-rose-600 via-rose-700 to-red-700 text-white text-xs py-1.5 px-4 font-medium">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-200 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
            </span>
            <span className="font-semibold tracking-wide uppercase text-[11px]">24/7 Maternal Emergency Protocol Active</span>
            <span className="hidden sm:inline text-rose-200">|</span>
            <span className="hidden sm:inline text-rose-100">National Ambulance: <strong>108</strong> • Maternal Van: <strong>102</strong></span>
          </div>
          <div className="flex items-center gap-3">
            <a 
              href="tel:108" 
              className="inline-flex items-center gap-1.5 bg-white/20 hover:bg-white/30 px-2 py-0.5 rounded text-[11px] font-bold transition"
            >
              <PhoneCall className="w-3 h-3 text-rose-200" />
              <span>Speed Dial 108</span>
            </a>
            <div className="relative">
              <button
                onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
                className="inline-flex items-center gap-1 bg-rose-950/40 hover:bg-rose-950/60 px-2 py-0.5 rounded text-[11px] font-medium transition cursor-pointer"
                title="Switch demo preview role"
              >
                <span>Role: <strong className="capitalize">{currentUser.role}</strong></span>
                <ChevronDown className="w-3 h-3" />
              </button>
              {roleDropdownOpen && (
                <div className="absolute right-0 mt-1.5 w-44 bg-white rounded-lg shadow-xl border border-slate-200 py-1 text-slate-700 z-50 text-xs">
                  <div className="px-3 py-1 font-semibold text-[10px] text-slate-400 uppercase tracking-wider">
                    Switch Test View
                  </div>
                  <button
                    onClick={() => {
                      switchUserRole('patient');
                      setRoleDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 flex items-center gap-2 hover:bg-rose-50 ${
                      currentUser.role === 'patient' ? 'font-bold text-rose-600 bg-rose-50/50' : ''
                    }`}
                  >
                    <User className="w-3.5 h-3.5" />
                    <span>Patient (Amina S.)</span>
                  </button>
                  <button
                    onClick={() => {
                      switchUserRole('admin');
                      setRoleDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 flex items-center gap-2 hover:bg-rose-50 ${
                      currentUser.role === 'admin' ? 'font-bold text-rose-600 bg-rose-50/50' : ''
                    }`}
                  >
                    <ShieldAlert className="w-3.5 h-3.5" />
                    <span>Admin Dispatcher</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main navigation bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          
          {/* Brand Logo */}
          <button 
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 text-left focus:outline-none group cursor-pointer"
          >
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-rose-500 via-rose-600 to-pink-500 text-white flex items-center justify-center shadow-md shadow-rose-500/20 group-hover:scale-105 transition-transform">
              <HeartHandshake className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-heading font-extrabold text-lg sm:text-xl text-slate-900 tracking-tight">
                  MATERNAL CARE
                </span>
                <span className="font-heading font-extrabold text-lg sm:text-xl text-rose-600 tracking-tight">
                  CONNECT
                </span>
              </div>
              <p className="text-[11px] font-medium text-slate-500 leading-none">
                Bridging the Maternal Healthcare Emergency Gap
              </p>
            </div>
          </button>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = activeTab === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`relative px-3.5 py-2 rounded-xl text-sm font-semibold transition-all duration-150 flex items-center gap-2 cursor-pointer ${
                    isActive
                      ? 'text-rose-700 bg-rose-50 shadow-xs'
                      : 'text-slate-600 hover:text-rose-600 hover:bg-slate-50'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-rose-600' : 'text-slate-400'}`} />
                  <span>{link.label}</span>
                  {link.badge !== undefined && (
                    <span className="inline-flex items-center justify-center px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-rose-600 text-white">
                      {link.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Header Action: SOS Emergency Button */}
          <div className="hidden sm:flex items-center gap-3">
            {activeEmergency ? (
              <button
                onClick={() => handleNavClick('emergency')}
                className="flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-md shadow-amber-500/20 transition cursor-pointer animate-pulse"
              >
                <Radio className="w-4 h-4" />
                <span>Active SOS #{activeEmergency.id.slice(-4)}</span>
              </button>
            ) : null}

            <button
              onClick={openSosModal}
              className="relative group overflow-hidden bg-gradient-to-r from-red-600 via-rose-600 to-red-600 hover:from-red-700 hover:to-rose-700 text-white px-4.5 py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-rose-600/30 transition-all transform active:scale-95 flex items-center gap-2 animate-emergency cursor-pointer"
            >
              <Ambulance className="w-4 h-4" />
              <span>SOS EMERGENCY</span>
            </button>
          </div>

          {/* Mobile menu trigger */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              onClick={openSosModal}
              className="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-md shadow-red-600/20 flex items-center gap-1.5 animate-emergency cursor-pointer"
            >
              <Ambulance className="w-3.5 h-3.5" />
              <span>SOS</span>
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-700 hover:bg-slate-100 focus:outline-none"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-2 pb-5 space-y-1 shadow-lg">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-semibold transition ${
                  isActive
                    ? 'text-rose-700 bg-rose-50 font-bold'
                    : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-5 h-5 ${isActive ? 'text-rose-600' : 'text-slate-400'}`} />
                  <span>{link.label}</span>
                </div>
                {link.badge !== undefined && (
                  <span className="px-2 py-0.5 text-xs font-bold rounded-full bg-rose-600 text-white">
                    {link.badge}
                  </span>
                )}
              </button>
            );
          })}

          <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
            <div className="text-xs text-slate-500 font-medium px-2">
              Current Mode: <strong className="text-slate-800 capitalize">{currentUser.role}</strong> ({currentUser.name})
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => switchUserRole('patient')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-medium border text-center ${
                  currentUser.role === 'patient'
                    ? 'border-rose-500 bg-rose-50 text-rose-700 font-bold'
                    : 'border-slate-200 text-slate-600'
                }`}
              >
                Patient View
              </button>
              <button
                onClick={() => switchUserRole('admin')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-medium border text-center ${
                  currentUser.role === 'admin'
                    ? 'border-rose-500 bg-rose-50 text-rose-700 font-bold'
                    : 'border-slate-200 text-slate-600'
                }`}
              >
                Admin Dispatcher
              </button>
            </div>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                openSosModal();
              }}
              className="w-full mt-2 bg-red-600 text-white py-2.5 rounded-xl font-bold text-sm shadow-md flex items-center justify-center gap-2"
            >
              <Ambulance className="w-4 h-4" />
              <span>TRIGGER MATERNAL SOS NOW</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
