import React from 'react';
import { 
  HeartHandshake, 
  PhoneCall, 
  Ambulance, 
  MapPin, 
  ShieldCheck, 
  AlertTriangle,
  Heart
} from 'lucide-react';
import { EMERGENCY_HOTLINES } from '../data/mockData';

interface FooterProps {
  setActiveTab: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab }) => {
  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800">
      
      {/* Top emergency strip in footer */}
      <div className="bg-rose-950/60 border-b border-rose-900/40 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2 text-rose-200">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>
              <strong>Life-Threatening Emergency?</strong> Call <strong>108</strong> (Ambulance) or <strong>102</strong> (Maternal Van) immediately.
            </span>
          </div>
          <div className="flex items-center gap-3">
            <a
              href="tel:108"
              className="bg-red-600 hover:bg-red-700 text-white font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 shadow-xs"
            >
              <PhoneCall className="w-3 h-3" />
              <span>Speed Dial 108</span>
            </a>
            <a
              href="tel:102"
              className="bg-rose-600 hover:bg-rose-700 text-white font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 shadow-xs"
            >
              <PhoneCall className="w-3 h-3" />
              <span>Call 102</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Footer Body */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8">
          
          {/* Brand & Mission */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-500 to-pink-500 text-white flex items-center justify-center shadow-md">
                <HeartHandshake className="w-5 h-5" />
              </div>
              <div>
                <span className="font-heading font-extrabold text-lg text-white">
                  MATERNAL CARE CONNECT
                </span>
                <p className="text-[11px] text-rose-400">Bridging the Maternal Healthcare Emergency Gap</p>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Dedicated to eliminating the Three Delays in maternal emergencies across rural and underserved communities by uniting pregnant women, emergency dispatch, and 24/7 maternity hospitals.
            </p>

            <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700/60 text-[11px] text-slate-300">
              <div className="font-bold text-white flex items-center gap-1.5 mb-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Verified Healthcare Startup Initiative</span>
              </div>
              Realistic demo dataset preloaded for testing ambulance dispatch, bed capacity tracking, and doctor tele-consultations.
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-heading font-bold text-sm text-white uppercase tracking-wider">
              Quick Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button 
                  onClick={() => { setActiveTab('home'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-rose-400 transition"
                >
                  Home & Overview
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { setActiveTab('emergency'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-rose-400 transition text-red-400 font-semibold"
                >
                  SOS Emergency Help Center
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { setActiveTab('hospitals'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-rose-400 transition"
                >
                  Find Nearby Hospitals & Beds
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { setActiveTab('hospital_reg'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-rose-400 transition text-rose-300 font-semibold"
                >
                  Hospital Registration & Onboarding
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { setActiveTab('doctors'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-rose-400 transition"
                >
                  Consult Qualified Obstetricians
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { setActiveTab('care'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-rose-400 transition"
                >
                  Pregnancy Care & Warning Signs
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { setActiveTab('dashboard'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-rose-400 transition"
                >
                  Patient Care Passport
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { setActiveTab('admin'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-rose-400 transition"
                >
                  Emergency Dispatch Command (Admin)
                </button>
              </li>
            </ul>
          </div>

          {/* Emergency Hotlines Directory */}
          <div className="lg:col-span-4 space-y-3">
            <h4 className="font-heading font-bold text-sm text-white uppercase tracking-wider">
              National Emergency Helplines
            </h4>
            <div className="space-y-2 text-xs">
              {EMERGENCY_HOTLINES.map((h, i) => (
                <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-slate-800/60 border border-slate-700/50">
                  <div>
                    <span className="font-extrabold text-rose-400 mr-2">{h.number}</span>
                    <span className="text-slate-300">{h.title}</span>
                  </div>
                  <a href={`tel:${h.number.replace(/[^0-9]/g, '')}`} className="text-slate-400 hover:text-white">
                    <PhoneCall className="w-3.5 h-3.5" />
                  </a>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Safety & Legal Disclaimer */}
        <div className="mt-10 pt-6 border-t border-slate-800 text-[11px] text-slate-500 leading-relaxed space-y-2">
          <p>
            <strong>Medical & Emergency Service Disclaimer:</strong> Maternal Care Connect (MCC) is a digital coordination and referral platform designed to streamline communication and triage during obstetric situations. Submitting a digital request does not replace immediate voice contact with national ambulance providers (108/112). In life-threatening emergencies involving acute bleeding, unresponsiveness, or eclampsia, callers must immediately telephone local emergency dispatch authorities.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-2 text-slate-500">
            <div>
              © 2026 Maternal Care Connect. All rights reserved.
            </div>
            <div className="flex items-center gap-1 text-slate-400">
              <span>Built with dedication for safe motherhood</span>
              <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />
            </div>
          </div>
        </div>

      </div>
    </footer>
  );
};
