import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { Hospital, LocationCoordinates } from '../types';

interface HospitalMapProps {
  hospitals: Hospital[];
  selectedHospital: Hospital | null;
  onSelectHospital: (hospital: Hospital) => void;
  userLocation: LocationCoordinates;
  showRoute?: boolean;
}

export const HospitalMap: React.FC<HospitalMapProps> = ({
  hospitals,
  selectedHospital,
  onSelectHospital,
  userLocation,
  showRoute = true
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const routeLayerRef = useRef<L.Polyline | null>(null);

  // Initialize Leaflet map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [userLocation.lat, userLocation.lng],
        zoom: 12,
        zoomControl: true,
        scrollWheelZoom: true
      });

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 18
      }).addTo(map);

      markersLayerRef.current = L.layerGroup().addTo(map);
      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Update markers and route when hospitals, userLocation, or selectedHospital change
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !markersLayerRef.current) return;

    markersLayerRef.current.clearLayers();
    if (routeLayerRef.current) {
      routeLayerRef.current.remove();
      routeLayerRef.current = null;
    }

    // 1. User Location Pin
    const userDivIcon = L.divIcon({
      className: 'custom-user-marker',
      html: `
        <div class="relative flex items-center justify-center">
          <span class="absolute w-8 h-8 rounded-full bg-blue-500 opacity-40 animate-ping"></span>
          <div class="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-lg border-2 border-white text-[10px] font-bold">
            📍
          </div>
        </div>
      `,
      iconSize: [24, 24],
      iconAnchor: [12, 12]
    });

    const userMarker = L.marker([userLocation.lat, userLocation.lng], { icon: userDivIcon })
      .bindPopup(`
        <div class="p-1">
          <div class="font-bold text-xs text-blue-700 uppercase">You Are Here</div>
          <div class="text-xs text-slate-700">${userLocation.address}</div>
        </div>
      `);
    markersLayerRef.current.addLayer(userMarker);

    // 2. Hospital Pins
    const bounds = L.latLngBounds([[userLocation.lat, userLocation.lng]]);

    hospitals.forEach((hosp) => {
      bounds.extend([hosp.lat, hosp.lng]);
      const isSelected = selectedHospital?.id === hosp.id;
      
      const hospitalDivIcon = L.divIcon({
        className: 'custom-hosp-marker',
        html: `
          <div class="relative group cursor-pointer transition-transform ${isSelected ? 'scale-125 z-30' : 'scale-100 hover:scale-110'}">
            <div class="w-9 h-9 rounded-xl ${
              isSelected 
                ? 'bg-rose-600 ring-4 ring-rose-200' 
                : hosp.emergencyCSection24x7 
                  ? 'bg-red-600' 
                  : 'bg-emerald-600'
            } text-white flex items-center justify-center shadow-md font-bold text-xs border border-white">
              🏥
            </div>
            <div class="absolute -bottom-1 -right-1 bg-white text-[9px] font-extrabold px-1 rounded-full text-slate-800 shadow-xs border">
              ${hosp.availableMaternityBeds}b
            </div>
          </div>
        `,
        iconSize: [36, 36],
        iconAnchor: [18, 18]
      });

      const hospMarker = L.marker([hosp.lat, hosp.lng], { icon: hospitalDivIcon });
      
      hospMarker.on('click', () => {
        onSelectHospital(hosp);
      });

      hospMarker.bindPopup(`
        <div class="text-xs space-y-1">
          <div class="font-bold text-slate-900">${hosp.name}</div>
          <div class="text-[11px] text-slate-500">${hosp.type} • ${hosp.distanceKm || 'Nearby'} km</div>
          <div class="text-[11px] font-semibold text-emerald-700">
            ${hosp.availableMaternityBeds} Maternity Beds Available
          </div>
          <div class="text-[11px] font-medium text-slate-600">
            ${hosp.emergencyCSection24x7 ? '✅ 24/7 C-Section Available' : '⚠️ Normal Delivery Only'}
          </div>
          <div class="pt-1">
            <a href="tel:${hosp.emergencyPhone}" class="inline-block bg-rose-600 text-white px-2 py-1 rounded text-[10px] font-bold">
              Call ER: ${hosp.emergencyPhone}
            </a>
          </div>
        </div>
      `);

      markersLayerRef.current?.addLayer(hospMarker);
    });

    // 3. Draw route line if a hospital is selected
    if (selectedHospital && showRoute) {
      // Simulated intermediate waypoints for road curve
      const midLat = (userLocation.lat + selectedHospital.lat) / 2 + 0.004;
      const midLng = (userLocation.lng + selectedHospital.lng) / 2 - 0.003;
      
      const routePoints: [number, number][] = [
        [userLocation.lat, userLocation.lng],
        [midLat, midLng],
        [selectedHospital.lat, selectedHospital.lng]
      ];

      const polyline = L.polyline(routePoints, {
        color: '#e11d48',
        weight: 5,
        opacity: 0.85,
        dashArray: '8, 8',
        lineCap: 'round',
        lineJoin: 'round'
      }).addTo(map);

      routeLayerRef.current = polyline;
      map.fitBounds(L.latLngBounds(routePoints), { padding: [40, 40] });
    } else if (hospitals.length > 0) {
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [hospitals, selectedHospital, userLocation, showRoute, onSelectHospital]);

  return (
    <div className="relative w-full h-full min-h-[420px] rounded-2xl overflow-hidden shadow-inner border border-slate-200">
      <div ref={mapContainerRef} className="w-full h-full min-h-[420px]" />
      
      {/* Map Legend Overlay */}
      <div className="absolute bottom-3 left-3 z-20 bg-white/95 backdrop-blur-xs p-2.5 rounded-xl shadow-md border border-slate-200 text-[11px] space-y-1">
        <div className="font-bold text-slate-700">Map Indicators:</div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-full bg-blue-600 inline-block"></span>
          <span>Your Location</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded bg-red-600 inline-block"></span>
          <span>24/7 C-Section & NICU Center</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded bg-emerald-600 inline-block"></span>
          <span>Community / PHC Delivery Unit</span>
        </div>
        {selectedHospital && (
          <div className="flex items-center gap-1.5 text-rose-600 font-semibold pt-1 border-t border-slate-100">
            <span className="w-4 h-0.5 border-t-2 border-dashed border-rose-600 inline-block"></span>
            <span>Emergency Route (~{selectedHospital.travelTimeMinutes} mins)</span>
          </div>
        )}
      </div>
    </div>
  );
};
