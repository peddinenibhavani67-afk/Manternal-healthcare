import { 
  Hospital, 
  Doctor, 
  EmergencyRequest, 
  HealthReminder, 
  UserProfile, 
  HealthUpdate, 
  MedicalRecord, 
  VitalCheckLog, 
  AmbulanceInfo, 
  HospitalReferral,
  HospitalRegistration 
} from '../types';

export const EMERGENCY_HOTLINES = [
  {
    number: '108',
    title: 'Emergency Medical & Ambulance',
    desc: 'Toll-free 24/7 National Emergency Medical Response & Ambulance Dispatch',
    category: 'ambulance',
    badge: 'National Priority'
  },
  {
    number: '102',
    title: 'Janani Shishu Suraksha / Maternal Transport',
    desc: 'Dedicated free transport service for pregnant women and sick neonates',
    category: 'maternal',
    badge: 'Maternal Specific'
  },
  {
    number: '112',
    title: 'Unified Emergency Services',
    desc: 'All-in-one emergency dispatch (Police, Fire, Medical, Disaster Response)',
    category: 'police',
    badge: 'Universal SOS'
  },
  {
    number: '1800-180-1104',
    title: 'National Maternal & Child Health Helpline',
    desc: 'Tele-triage, pregnancy counseling & emergency referral coordination',
    category: 'counseling',
    badge: 'Toll Free'
  }
];

export const HEALTH_UPDATES: HealthUpdate[] = [
  {
    id: 'upd-1',
    title: 'National Maternal Tdap & Anemia Campaign 2026',
    category: 'vaccine_drive',
    badge: 'Public Health Advisory',
    date: 'Nov 04, 2026',
    summary: 'Free Tdap boosters and fortified Iron-Folic Acid (IFA) supplies available across all District Hospitals and 24/7 Primary Health Centers.',
    details: 'Expectant mothers between 27 and 36 weeks of gestation are urged to receive their single-dose Tdap booster to provide crucial passive immunity against pertussis (whooping cough) to newborns.',
    source: 'National Ministry of Health & Family Welfare'
  },
  {
    id: 'upd-2',
    title: 'Rural High-Risk Maternal Screening Camps This Weekend',
    category: 'rural_camp',
    badge: 'Free Screening Camp',
    date: 'Nov 02, 2026',
    summary: 'Mobile ultrasound units and obstetric specialists deployed to East and West Rural Blocks for free anomaly and growth scans.',
    details: 'Free portable Doppler fetal heart assessment, hemoglobin screening for severe gestational anemia, and on-spot high-risk pregnancy tagging with digital referral cards.',
    source: 'Regional Maternal Emergency Dispatch Authority'
  },
  {
    id: 'upd-3',
    title: 'Hydration & Heat Advisory for 3rd Trimester Expectant Mothers',
    category: 'advisory',
    badge: 'Clinical Notice',
    date: 'Oct 28, 2026',
    summary: 'Preventing premature contractions and oligohydramnios (low amniotic fluid) through structured daily hydration.',
    details: 'Dehydration during late pregnancy triggers pituitary release of oxytocin, leading to false or preterm contractions. Mothers should consume a minimum of 2.8 - 3.2 liters of clean fluids daily.',
    source: 'Obstetric & Perinatal Health Council'
  },
  {
    id: 'upd-4',
    title: 'Janani Shishu Suraksha Karyakram (JSSK) Cashless Delivery Entitlement',
    category: 'advisory',
    badge: 'Govt. Scheme Guarantee',
    date: 'Oct 20, 2026',
    summary: 'Zero expenses for normal delivery, emergency C-section, medicines, blood transfusion, and return transport in all government hospitals.',
    details: 'Report any illegal out-of-pocket charges directly through the Maternal Care Connect grievance hotline or speed dial 102.',
    source: 'Maternal Rights & Healthcare Access Board'
  }
];

export const INITIAL_HOSPITALS: Hospital[] = [
  {
    id: 'hosp-1',
    name: 'District Mother & Child Specialty Hospital',
    type: 'District Hospital',
    address: 'Sector 4, Main Civil Lines, Civil Hospital Road',
    district: 'Central District',
    phone: '+1 (800) 456-7890',
    emergencyPhone: '+1 (800) 456-7891',
    ambulancePhone: '+1 (800) 456-7892',
    lat: 28.6139,
    lng: 77.2090,
    distanceKm: 2.4,
    travelTimeMinutes: 8,
    services: [
      '24/7 Emergency C-Section',
      'NICU Level III (Intensive)',
      'Blood Storage Unit & Component Therapy',
      'High-Risk Obstetric ICU',
      'Normal Delivery Suites',
      'Kangaroo Mother Care (KMC)',
      'Tele-Perinatal Referral Cell'
    ],
    emergencyCSection24x7: true,
    nicuLevel: 'Level III',
    bloodBankOnSite: true,
    freeGovtSubsidized: true,
    totalMaternityBeds: 60,
    availableMaternityBeds: 14,
    availableNicuBeds: 4,
    rating: 4.8,
    reviewsCount: 342,
    verifiedDate: 'Today, 08:00 AM',
    isOpen24x7: true
  },
  {
    id: 'hosp-2',
    name: 'Lotus Maternal & Perinatal Institute',
    type: 'Maternity Specialty Center',
    address: 'Plot 12, Healthcare Enclave, Ring Road',
    district: 'North District',
    phone: '+1 (800) 555-0144',
    emergencyPhone: '+1 (800) 555-0199',
    ambulancePhone: '+1 (800) 555-0198',
    lat: 28.6328,
    lng: 77.2197,
    distanceKm: 4.1,
    travelTimeMinutes: 12,
    services: [
      '24/7 Emergency C-Section',
      'NICU Level III',
      'Fetal Medicine & Echocardiography',
      'Painless Labor / Epidural Services',
      'Advanced Neonatal Transport Ambulance',
      'Maternal ICU (MICU)'
    ],
    emergencyCSection24x7: true,
    nicuLevel: 'Level III',
    bloodBankOnSite: true,
    freeGovtSubsidized: false,
    totalMaternityBeds: 45,
    availableMaternityBeds: 9,
    availableNicuBeds: 3,
    rating: 4.9,
    reviewsCount: 512,
    verifiedDate: 'Today, 07:45 AM',
    isOpen24x7: true
  },
  {
    id: 'hosp-3',
    name: 'Greenfield Sub-Divisional Rural Maternity Hospital',
    type: 'Sub-Divisional Hospital',
    address: 'Opposite Farmers Hub, Rural Corridor Hwy 14',
    district: 'East Rural District',
    phone: '+1 (800) 333-7821',
    emergencyPhone: '+1 (800) 333-7822',
    ambulancePhone: '+1 (800) 333-7823',
    lat: 28.5800,
    lng: 77.2500,
    distanceKm: 7.8,
    travelTimeMinutes: 19,
    services: [
      '24/7 Emergency C-Section',
      'NICU Level II',
      'Blood Storage Center',
      'Kangaroo Mother Care Ward',
      'Free Janani Shishu Scheme Delivery',
      'Emergency Referral Ambulance Hub'
    ],
    emergencyCSection24x7: true,
    nicuLevel: 'Level II',
    bloodBankOnSite: true,
    freeGovtSubsidized: true,
    totalMaternityBeds: 35,
    availableMaternityBeds: 8,
    availableNicuBeds: 2,
    rating: 4.6,
    reviewsCount: 189,
    verifiedDate: 'Today, 08:15 AM',
    isOpen24x7: true
  },
  {
    id: 'hosp-4',
    name: 'St. Mary Community Maternity & Health Unit',
    type: 'Community Health Center',
    address: 'Near Village Panchayat Hall, Block 3',
    district: 'South Rural District',
    phone: '+1 (800) 777-2211',
    emergencyPhone: '+1 (800) 777-2299',
    ambulancePhone: '+1 (800) 777-2298',
    lat: 28.5500,
    lng: 77.1900,
    distanceKm: 9.5,
    travelTimeMinutes: 24,
    services: [
      'Normal Delivery 24/7',
      'Basic Emergency Obstetric Care (BEmONC)',
      'Newborn Stabilization Unit',
      'Emergency Referral Ambulance Station',
      'Maternal Ultrasound Checkup'
    ],
    emergencyCSection24x7: false,
    nicuLevel: 'Level I',
    bloodBankOnSite: false,
    freeGovtSubsidized: true,
    totalMaternityBeds: 20,
    availableMaternityBeds: 6,
    availableNicuBeds: 1,
    rating: 4.5,
    reviewsCount: 120,
    verifiedDate: 'Today, 07:30 AM',
    isOpen24x7: true
  },
  {
    id: 'hosp-5',
    name: 'Apex Tertiary Medical College & Obstetric Trauma Unit',
    type: 'District Hospital',
    address: 'Campus Gate 2, Ring Road North, University Area',
    district: 'North-West District',
    phone: '+1 (800) 888-4400',
    emergencyPhone: '+1 (800) 888-4499',
    ambulancePhone: '+1 (800) 888-4498',
    lat: 28.6700,
    lng: 77.1600,
    distanceKm: 11.2,
    travelTimeMinutes: 26,
    services: [
      '24/7 Emergency C-Section',
      'NICU Level III (Extensive Care)',
      'Regional Blood Bank 24/7',
      'Obstetric Hemorrhage Rapid Response',
      'Critical Care Perinatal ECMO',
      'Inter-Hospital Referral Acceptance Desk'
    ],
    emergencyCSection24x7: true,
    nicuLevel: 'Level III',
    bloodBankOnSite: true,
    freeGovtSubsidized: true,
    totalMaternityBeds: 110,
    availableMaternityBeds: 21,
    availableNicuBeds: 5,
    rating: 4.7,
    reviewsCount: 780,
    verifiedDate: 'Today, 08:20 AM',
    isOpen24x7: true
  },
  {
    id: 'hosp-6',
    name: 'Aarogya Rural Primary Health Center (24/7 PHC)',
    type: 'Primary Health Center (24/7)',
    address: 'Post Office Road, Village Bilaspur',
    district: 'West Rural Cluster',
    phone: '+1 (800) 999-1234',
    emergencyPhone: '+1 (800) 999-1299',
    ambulancePhone: '+1 (800) 999-1298',
    lat: 28.5200,
    lng: 77.1300,
    distanceKm: 14.8,
    travelTimeMinutes: 32,
    services: [
      '24/7 Midwife-Led Normal Delivery',
      'Newborn Resuscitation Table',
      'Emergency Pre-Referral Medication',
      'Dedicated 108 Emergency Ambulance Post',
      'Tele-consultation with District Obstetrician'
    ],
    emergencyCSection24x7: false,
    nicuLevel: 'Level I',
    bloodBankOnSite: false,
    freeGovtSubsidized: true,
    totalMaternityBeds: 12,
    availableMaternityBeds: 4,
    availableNicuBeds: 0,
    rating: 4.4,
    reviewsCount: 94,
    verifiedDate: 'Today, 06:50 AM',
    isOpen24x7: true
  }
];

export const INITIAL_DOCTORS: Doctor[] = [
  {
    id: 'doc-1',
    name: 'Dr. Sunita Deshmukh',
    title: 'Senior Consultant Obstetrician & Gynecologist',
    specialization: 'Obstetrician & Gynecologist',
    hospitalId: 'hosp-1',
    hospitalName: 'District Mother & Child Specialty Hospital',
    experienceYears: 18,
    qualification: 'MD (OBGYN), DGO, Fellow in High-Risk Pregnancy',
    languages: ['English', 'Hindi', 'Marathi'],
    rating: 4.9,
    reviewsCount: 380,
    availableNow: true,
    nextAvailableSlot: 'Today, in 25 mins',
    consultationFee: 0, // Government subsidized
    avatarUrl: 'https://images.unsplash.com/photo-1594824813689-dd4b82d02c89?auto=format&fit=crop&w=400&q=80',
    bio: 'Dedicated to reducing maternal mortality in rural and peri-urban populations. Over 3,500 safe deliveries conducted, specializing in emergency operative obstetrics and hypertensive pregnancy management.',
    supportedModes: ['video', 'in-person', 'emergency-call']
  },
  {
    id: 'doc-2',
    name: 'Dr. Anita Roy-Chowdhury',
    title: 'Chief Perinatal & Maternal-Fetal Medicine Specialist',
    specialization: 'Maternal-Fetal Medicine (High Risk)',
    hospitalId: 'hosp-2',
    hospitalName: 'Lotus Maternal & Perinatal Institute',
    experienceYears: 15,
    qualification: 'MD, DM (Maternal-Fetal Medicine), Fellowship UK',
    languages: ['English', 'Hindi', 'Bengali'],
    rating: 4.95,
    reviewsCount: 290,
    availableNow: true,
    nextAvailableSlot: 'Today, 11:30 AM',
    consultationFee: 25,
    avatarUrl: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=400&q=80',
    bio: 'Specialist in high-risk pregnancies, preeclampsia, multiple gestations (twins/triplets), gestational diabetes, and fetal growth restriction. Passionate about maternal emergency preparedness.',
    supportedModes: ['video', 'in-person', 'emergency-call']
  },
  {
    id: 'doc-3',
    name: 'Sister Mary Varghese',
    title: 'Lead Certified Nurse-Midwife & Community Triage Officer',
    specialization: 'Certified Nurse Midwife',
    hospitalId: 'hosp-3',
    hospitalName: 'Greenfield Sub-Divisional Rural Maternity Hospital',
    experienceYears: 22,
    qualification: 'BSc Nursing, Certified Nurse-Midwife (CNM), Neonatal CPR Trainer',
    languages: ['English', 'Hindi', 'Malayalam'],
    rating: 4.8,
    reviewsCount: 410,
    availableNow: true,
    nextAvailableSlot: 'Available Now (Walk-in / Video)',
    consultationFee: 0,
    avatarUrl: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=400&q=80',
    bio: 'A compassionate pillar of rural maternal support. Leads antenatal preparation, labor comfort techniques, emergency warning signs triage, and postpartum newborn care.',
    supportedModes: ['video', 'in-person']
  },
  {
    id: 'doc-4',
    name: 'Dr. Tariq Al-Mansoor',
    title: 'Consultant Obstetric Surgeon & Emergency Triage Specialist',
    specialization: 'Obstetrician & Gynecologist',
    hospitalId: 'hosp-5',
    hospitalName: 'Apex Tertiary Medical College & Obstetric Trauma Unit',
    experienceYears: 14,
    qualification: 'MS (OBGYN), Fellow in Critical Care Obstetrics (FICM)',
    languages: ['English', 'Hindi', 'Urdu'],
    rating: 4.85,
    reviewsCount: 215,
    availableNow: false,
    nextAvailableSlot: 'Today, 02:00 PM',
    consultationFee: 15,
    avatarUrl: 'https://images.unsplash.com/photo-1622902046580-2b47f47f5471?auto=format&fit=crop&w=400&q=80',
    bio: 'Heads the 24/7 Rapid Obstetric Response Unit at Apex Medical. Expert in postpartum hemorrhage management, emergency surgical delivery, and preeclampsia crisis control.',
    supportedModes: ['video', 'in-person', 'emergency-call']
  },
  {
    id: 'doc-5',
    name: 'Dr. Meenakshi Sundaram',
    title: 'Perinatal & Lactation Medicine Consultant',
    specialization: 'Lactation & Postnatal Consultant',
    hospitalId: 'hosp-1',
    hospitalName: 'District Mother & Child Specialty Hospital',
    experienceYears: 11,
    qualification: 'MD (Pediatrics / Perinatal), IBCLC',
    languages: ['English', 'Hindi', 'Tamil'],
    rating: 4.9,
    reviewsCount: 175,
    availableNow: true,
    nextAvailableSlot: 'Today, in 45 mins',
    consultationFee: 0,
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80',
    bio: 'Guidance through the critical first 42 days postpartum. Addresses breastfeeding challenges, mastitis prevention, neonatal jaundice signs, and postpartum depression counseling.',
    supportedModes: ['video', 'in-person']
  }
];

export const INITIAL_AMBULANCE_FLEET: AmbulanceInfo[] = [
  {
    id: 'amb-108-1',
    vehicleNo: 'MCC-AMB-108-ALPHA',
    driverName: 'Ramesh Singh (EMT-Paramedic)',
    driverPhone: '+1 (555) 789-1088',
    type: 'Advanced Neonatal/Maternal ALS',
    status: 'dispatched',
    currentLocationName: 'Sector 14 Bypass Junction',
    currentLat: 28.6010,
    currentLng: 77.2210,
    etaMinutes: 6,
    assignedRequestId: 'sos-9021',
    assignedHospital: 'District Mother & Child Specialty Hospital'
  },
  {
    id: 'amb-102-2',
    vehicleNo: 'MCC-AMB-102-BRAVO',
    driverName: 'Mohan Kumar (Certified Midwife Driver)',
    driverPhone: '+1 (555) 321-1022',
    type: 'Community Maternal Van',
    status: 'available',
    currentLocationName: 'Sub-Divisional Hospital Standby Bay',
    currentLat: 28.5800,
    currentLng: 77.2500,
    etaMinutes: 12
  },
  {
    id: 'amb-108-3',
    vehicleNo: 'MCC-AMB-108-CHARLIE',
    driverName: 'Sanjay Yadav (ALS Paramedic)',
    driverPhone: '+1 (555) 444-1089',
    type: 'Advanced Neonatal/Maternal ALS',
    status: 'dispatched',
    currentLocationName: 'North Ring Road Highway',
    currentLat: 28.6380,
    currentLng: 77.2280,
    etaMinutes: 11,
    assignedRequestId: 'sos-9015',
    assignedHospital: 'Lotus Maternal & Perinatal Institute'
  },
  {
    id: 'amb-102-4',
    vehicleNo: 'MCC-AMB-102-DELTA',
    driverName: 'Kishore Patel (First Responder)',
    driverPhone: '+1 (555) 888-1024',
    type: 'Basic Life Support (BLS)',
    status: 'available',
    currentLocationName: 'Central District Hospital Emergency Bay',
    currentLat: 28.6140,
    currentLng: 77.2095,
    etaMinutes: 4
  }
];

export const INITIAL_EMERGENCY_REQUESTS: EmergencyRequest[] = [
  {
    id: 'sos-9021',
    patientName: 'Pooja Verma',
    patientPhone: '+1 (555) 234-8901',
    gestationalWeek: 36,
    emergencyType: 'Severe Abdominal Pain & Bleeding',
    severity: 'critical',
    symptoms: ['Heavy vaginal bleeding', 'Sharp continuous uterine pain', 'Faintness'],
    notes: 'Patient feels weak; gestation 36 weeks. Near primary school landmark.',
    location: {
      lat: 28.5900,
      lng: 77.2300,
      address: 'House #42, Village Kheda, East Rural Sector',
      landmark: 'Near Government High School',
      district: 'East Rural District'
    },
    status: 'ambulance_dispatched',
    timestamp: '18 minutes ago',
    assignedAmbulance: INITIAL_AMBULANCE_FLEET[0],
    assignedHospitalId: 'hosp-1',
    assignedHospitalName: 'District Mother & Child Specialty Hospital',
    dispatcherNotes: 'ALS Ambulance equipped with portable Doppler and oxygen en route. Hospital triage notified for rapid labor suite admission.'
  },
  {
    id: 'sos-9018',
    patientName: 'Kavita Patel',
    patientPhone: '+1 (555) 456-1122',
    gestationalWeek: 39,
    emergencyType: 'Active Labor Contractions (Water Broke)',
    severity: 'high',
    symptoms: ['Water broke (clear fluid)', 'Contractions 3 mins apart', 'Urge to push'],
    notes: 'Second child. Contractions started 2 hours ago, intensifying fast.',
    location: {
      lat: 28.6250,
      lng: 77.2050,
      address: 'Flat 301, Shanti Enclave, Block B',
      landmark: 'Opposite Mother Dairy Booth',
      district: 'Central District'
    },
    status: 'reached_hospital',
    timestamp: '42 minutes ago',
    assignedAmbulance: INITIAL_AMBULANCE_FLEET[1],
    assignedHospitalId: 'hosp-1',
    assignedHospitalName: 'District Mother & Child Specialty Hospital',
    dispatcherNotes: 'Patient safely admitted to Labor Ward Room 4. Doctor on call attending.'
  },
  {
    id: 'sos-9015',
    patientName: 'Meera Devi',
    patientPhone: '+1 (555) 987-6543',
    gestationalWeek: 34,
    emergencyType: 'Severe Headache & High BP Symptoms',
    severity: 'high',
    symptoms: ['Blurred vision / aura', 'Severe throbbing headache', 'Swelling in hands & face'],
    notes: 'Known preeclampsia risk. Home BP was 160/105 mmHg.',
    location: {
      lat: 28.6400,
      lng: 77.2300,
      address: 'Near Old Bus Stand, North Corridor',
      landmark: 'Behind Rural Bank of Commerce',
      district: 'North District'
    },
    status: 'triaged',
    timestamp: '1 hour ago',
    assignedAmbulance: INITIAL_AMBULANCE_FLEET[2],
    assignedHospitalId: 'hosp-2',
    assignedHospitalName: 'Lotus Maternal & Perinatal Institute',
    dispatcherNotes: 'Pre-eclampsia protocol initiated. Magnesium Sulfate preparedness confirmed with Lotus Institute.'
  }
];

export const INITIAL_REMINDERS: HealthReminder[] = [
  {
    id: 'rem-1',
    title: '32-Week Antenatal Care (ANC) Checkup',
    category: 'checkup',
    dueDate: '2026-11-12',
    completed: false,
    recommendedWeek: 32,
    description: 'Check blood pressure, urine protein, fundal height, and fetal heart sounds with your midwife/doctor.'
  },
  {
    id: 'rem-2',
    title: 'Tdap / Tetanus Toxoid Booster Vaccine',
    category: 'vaccine',
    dueDate: '2026-11-15',
    completed: false,
    recommendedWeek: 28,
    description: 'Protects both mother and newborn against neonatal tetanus and whooping cough.'
  },
  {
    id: 'rem-3',
    title: 'Daily Iron & Folic Acid Supplement',
    category: 'nutrition',
    dueDate: 'Daily Routine',
    completed: true,
    recommendedWeek: 12,
    description: 'Crucial for preventing maternal anemia and reducing postpartum hemorrhage risk.'
  },
  {
    id: 'rem-4',
    title: 'Third Trimester Growth & Doppler Ultrasound',
    category: 'scan',
    dueDate: '2026-11-20',
    completed: false,
    recommendedWeek: 34,
    description: 'Assesses fetal weight estimate, amniotic fluid index (AFI), and umbilical blood flow.'
  },
  {
    id: 'rem-5',
    title: 'Prepare Birth Emergency Transport & Kit',
    category: 'emergency_plan',
    dueDate: '2026-11-25',
    completed: false,
    recommendedWeek: 36,
    description: 'Pack hospital bag, store 108/102 emergency numbers on speed dial, and identify 2 blood donors.'
  }
];

export const SAMPLE_MEDICAL_RECORDS: MedicalRecord[] = [
  {
    id: 'rec-001',
    patientId: 'usr-patient-1',
    title: 'Level II Anomaly Ultrasound Scan Report',
    category: 'ultrasound',
    date: '2026-08-14',
    facility: 'District Mother & Child Specialty Hospital',
    doctor: 'Dr. Sunita Deshmukh',
    summary: 'Single live intrauterine gestation in cephalic presentation. Normal fetal cardiac 4-chamber view, normal spine, kidneys, and extremities. Placenta fundal-posterior, clear of internal os.',
    keyValues: {
      'Gestational Age at Scan': '20 Weeks 2 Days',
      'Estimated Fetal Weight': '360 grams',
      'Amniotic Fluid Index (AFI)': '14.2 cm (Normal)',
      'Placental Location': 'Posterior, Grade I Maturity',
      'Fetal Heart Rate': '144 bpm (Regular)'
    }
  },
  {
    id: 'rec-002',
    patientId: 'usr-patient-1',
    title: 'Third Trimester Complete Blood Count (CBC) & Hb',
    category: 'lab_report',
    date: '2026-10-18',
    facility: 'Central District Pathology Laboratory',
    doctor: 'Dr. Anita Roy-Chowdhury',
    summary: 'Hemoglobin slightly borderline for 30 weeks. Recommend continuing double-dose elemental Iron (100mg) with Vitamin C. Normal platelet count and white blood cell differential.',
    keyValues: {
      'Hemoglobin (Hb)': '10.8 g/dL (Borderline Mild Anemia)',
      'Platelet Count': '240,000 /mcL (Normal)',
      'Blood Group & Rh': 'B Positive (B+)',
      'Random Blood Sugar (RBS)': '92 mg/dL (Normal Fasting Equivalent)',
      'Urine Albumin': 'Nil (Negative for Preeclampsia Proteinuria)'
    }
  },
  {
    id: 'rec-003',
    patientId: 'usr-patient-1',
    title: 'Oral Glucose Tolerance Test (OGTT - 75g 2-Hr)',
    category: 'lab_report',
    date: '2026-09-22',
    facility: 'Lotus Maternal Diagnostics',
    doctor: 'Dr. Anita Roy-Chowdhury',
    summary: 'Screens negative for Gestational Diabetes Mellitus (GDM). Fasting, 1-hr, and 2-hr plasma glucose within normal non-diabetic thresholds.',
    keyValues: {
      'Fasting Blood Glucose': '82 mg/dL (Normal < 92)',
      '1-Hour Post-Glucose': '128 mg/dL (Normal < 180)',
      '2-Hour Post-Glucose': '110 mg/dL (Normal < 153)'
    }
  },
  {
    id: 'rec-004',
    patientId: 'usr-patient-1',
    title: 'Antenatal Prescription & Micronutrient Order',
    category: 'prescription',
    date: '2026-10-18',
    facility: 'District Mother & Child Specialty Hospital',
    doctor: 'Dr. Sunita Deshmukh',
    summary: 'Prescribed daily prophylactic therapy: Ferrous Ascorbate + Folic Acid 1 tab OD after lunch; Calcium Carbonate 500mg + Vitamin D3 1 tab OD at night. Paracetamol 500mg SOS for mild headache (max 2 tabs/day).',
    keyValues: {
      'Iron Formulation': 'Ferrous Ascorbate 100mg + Folic Acid 1.5mg',
      'Calcium Supplement': 'Calcium Carbonate 500mg + Vit D3 250 IU',
      'Review Date': 'Week 34 (2026-11-12)'
    }
  }
];

export const SAMPLE_VITAL_LOGS: VitalCheckLog[] = [
  {
    id: 'vit-1',
    date: '2026-11-06',
    time: '08:30 AM',
    gestationalWeek: 31,
    bloodPressureSystolic: 118,
    bloodPressureDiastolic: 76,
    fetalKickCount: 12,
    weightKg: 64.5,
    bloodSugarMgDl: 94,
    notes: 'Good active kicks after breakfast. No headaches or swelling.'
  },
  {
    id: 'vit-2',
    date: '2026-11-04',
    time: '06:45 PM',
    gestationalWeek: 31,
    bloodPressureSystolic: 122,
    bloodPressureDiastolic: 80,
    fetalKickCount: 11,
    weightKg: 64.3,
    notes: 'Mild fatigue after walking. Drank coconut water and rested on left side.'
  },
  {
    id: 'vit-3',
    date: '2026-11-01',
    time: '09:00 AM',
    gestationalWeek: 30,
    bloodPressureSystolic: 116,
    bloodPressureDiastolic: 74,
    fetalKickCount: 14,
    weightKg: 63.8,
    bloodSugarMgDl: 89,
    notes: 'Morning routine checkup at home.'
  }
];

export const SAMPLE_HOSPITAL_REFERRALS: HospitalReferral[] = [
  {
    id: 'ref-801',
    patientName: 'Radha Mondal',
    gestationalWeek: 35,
    referringFacility: 'Aarogya Rural PHC',
    receivingHospital: 'District Mother & Child Specialty Hospital',
    referralReason: 'Breech presentation in active labor with meconium stained amniotic fluid. Emergency C-Section & NICU bed required.',
    status: 'in_transit',
    timestamp: '25 mins ago',
    priority: 'emergency_csection'
  },
  {
    id: 'ref-798',
    patientName: 'Sunita Devi',
    gestationalWeek: 32,
    referringFacility: 'Greenfield Sub-Divisional Hospital',
    receivingHospital: 'Lotus Maternal & Perinatal Institute',
    referralReason: 'Severe preeclampsia (BP 170/110) unresponsive to oral Labetalol. Needs continuous Magnesium Sulfate infusion & Maternal ICU.',
    status: 'bed_reserved',
    timestamp: '1 hour ago',
    priority: 'emergency_csection'
  },
  {
    id: 'ref-792',
    patientName: 'Taslima Bano',
    gestationalWeek: 38,
    referringFacility: 'St. Mary Community Unit',
    receivingHospital: 'District Mother & Child Specialty Hospital',
    referralReason: 'Postpartum hemorrhage following normal delivery in sub-center. 2 units O+ blood cross-matched and patient transferred via ALS ambulance.',
    status: 'received',
    timestamp: '3 hours ago',
    priority: 'blood_transfusion'
  }
];

export const VACCINATION_SCHEDULE_DATA = [
  {
    vaccine: 'Tetanus & Diphtheria (Td 1) or Tdap',
    recommendedTiming: 'Early 1st Trimester (As soon as pregnancy confirmed)',
    targetDisease: 'Maternal and Neonatal Tetanus',
    importance: 'Protects the mother and unborn child against fatal clostridial infections during delivery.',
    mandatory: true
  },
  {
    vaccine: 'Tetanus & Diphtheria (Td 2) Booster',
    recommendedTiming: '4 weeks after Td 1 (Weeks 16 - 24)',
    targetDisease: 'Neonatal Tetanus Reinforcement',
    importance: 'Ensures protective antibody titers persist through labor and first 6 months of newborn life.',
    mandatory: true
  },
  {
    vaccine: 'Tdap (Tetanus, Diphtheria, Acellular Pertussis)',
    recommendedTiming: 'Between Weeks 27 and 36 (Ideal: Week 28)',
    targetDisease: 'Pertussis (Whooping Cough)',
    importance: 'Transfers high levels of pertussis antibodies to the fetus to shield the infant before their 2-month vaccine.',
    mandatory: true
  },
  {
    vaccine: 'Inactivated Influenza (Flu Shot)',
    recommendedTiming: 'Any trimester during seasonal flu season',
    targetDisease: 'Maternal Severe Pneumonia & Fetal Growth Restriction',
    importance: 'Pregnancy increases the risk of hospitalization from influenza by four-fold.',
    mandatory: false
  },
  {
    vaccine: 'Anti-D Immunoglobulin (RhoGAM)',
    recommendedTiming: 'Week 28 (and within 72 hrs post-birth if baby is Rh+)',
    targetDisease: 'Rh Isoimmunization (Hemolytic Disease of Newborn)',
    importance: 'Crucial for Rh-negative mothers with Rh-positive partners to prevent antibody attack on baby red blood cells.',
    mandatory: true
  },
  {
    vaccine: 'Newborn Birth Dose: BCG, Oral Polio (OPV 0), Hepatitis B',
    recommendedTiming: 'Within first 24 hours after delivery',
    targetDisease: 'Tuberculosis, Poliomyelitis, Vertical Hepatitis B',
    importance: 'Immediate postnatal protection administered in the maternity recovery suite.',
    mandatory: true
  }
];

export const DEFAULT_PATIENT_USER: UserProfile = {
  id: 'usr-patient-1',
  name: 'Amina Sharma',
  email: 'amina.sharma@example.com',
  phone: '+1 (555) 349-8812',
  role: 'patient',
  gestationalWeek: 31,
  expectedDueDate: '2027-01-08',
  bloodGroup: 'B Positive (B+)',
  address: 'Green Meadows, House 14B, Village Mandi, East District',
  emergencyContactName: 'Vikram Sharma (Husband)',
  emergencyContactPhone: '+1 (555) 349-8813',
  emergencyContactRelation: 'Spouse',
  preferredHospitalId: 'hosp-1',
  highRiskFlags: ['Gestational Hypertension (Borderline)', 'Rh Positive'],
  gravidaPara: 'G2P1 (Second Pregnancy, 1 Living Child)',
  lastMenstrualPeriod: '2026-04-03'
};

export const DEFAULT_ADMIN_USER: UserProfile = {
  id: 'usr-admin-1',
  name: 'Dr. Rajesh Varma',
  email: 'dispatch.admin@maternalcareconnect.org',
  phone: '+1 (800) 456-9999',
  role: 'admin',
  address: 'Regional Maternal Emergency Dispatch Hub, Civil Hospital Complex'
};

export const PREGNANCY_RED_FLAGS = [
  {
    id: 'rf-1',
    title: 'Heavy Vaginal Bleeding',
    symptom: 'Bleeding like a heavy period, with or without severe abdominal pain',
    urgency: 'critical',
    immediateAction: 'Call 108 / Press SOS immediately. Do NOT insert tampons. Lie down on your left side.',
    potentialCauses: 'Placenta Previa, Placental Abruption, Early Cervical Dilatation',
    category: 'Obstetric Hemorrhage'
  },
  {
    id: 'rf-2',
    title: 'Severe Constant Belly / Lower Abdominal Pain',
    symptom: 'Continuous sharp pain that does not ease between contractions, rigid or tight abdomen',
    urgency: 'critical',
    immediateAction: 'Urgent emergency transport. Do not take painkiller pills without medical supervision.',
    potentialCauses: 'Placental Abruption, Uterine Rupture, Ectopic Pregnancy',
    category: 'Acute Abdomen'
  },
  {
    id: 'rf-3',
    title: 'Severe Headache with Blurred Vision & Aura',
    symptom: 'Throbbing frontal headache, spots before eyes, sudden swelling of face/hands, upper right abdominal pain',
    urgency: 'critical',
    immediateAction: 'Immediate hospital admission. Risk of maternal seizures (Eclampsia). Check BP at once.',
    potentialCauses: 'Severe Preeclampsia / HELLP Syndrome',
    category: 'Hypertensive Emergency'
  },
  {
    id: 'rf-4',
    title: 'Sudden Fluid Gush / Water Breaking (Before 37 Weeks)',
    symptom: 'Clear or greenish water trickling or gushing from the vagina without urine smell',
    urgency: 'high',
    immediateAction: 'Note the color of fluid. Contact hospital labor ward immediately and proceed to emergency.',
    potentialCauses: 'Preterm Premature Rupture of Membranes (PPROM), Cord Prolapse risk',
    category: 'Preterm Labor'
  },
  {
    id: 'rf-5',
    title: 'Significantly Decreased or Absent Baby Kicks',
    symptom: 'Fewer than 10 kicks or movements within a 2-hour quiet rest period in 3rd trimester',
    urgency: 'high',
    immediateAction: 'Drink a cold sugary beverage, lie on your left side for 1 hour. If no movement, go for emergency Non-Stress Test (NST).',
    potentialCauses: 'Fetal Distress, Placental Insufficiency, Umbilical Cord Compression',
    category: 'Fetal Wellbeing'
  },
  {
    id: 'rf-6',
    title: 'High Fever with Chills & Foul Discharge',
    symptom: 'Temperature over 38°C (100.4°F), rapid heart rate, foul-smelling vaginal discharge',
    urgency: 'high',
    immediateAction: 'Seek same-day medical attention. Requires blood cultures and maternal/fetal antibiotic evaluation.',
    potentialCauses: 'Chorioamnionitis, Sepsis, Urinary Tract Infection (Pyelonephritis)',
    category: 'Infection / Sepsis'
  }
];

export const INITIAL_HOSPITAL_REGISTRATIONS: HospitalRegistration[] = [
  {
    id: 'reg-101',
    name: 'Mother Teresa Rural Maternity & Neonatal Center',
    licenseNumber: 'CEA-MR-2026-9041',
    type: 'Community Health Center',
    address: 'Near Old Canal Road, Block 4, South Village Corridor',
    district: 'South Rural District',
    phone: '+1 (800) 666-4122',
    emergencyPhone: '+1 (800) 666-4199',
    ambulancePhone: '+1 (800) 666-4198',
    lat: 28.5350,
    lng: 77.2150,
    services: [
      'Normal Delivery 24/7',
      'Basic Emergency Obstetric Care (BEmONC)',
      'Newborn Resuscitation Bed',
      'Ambulance Station Point',
      'Blood Storage Refrigerator'
    ],
    emergencyCSection24x7: false,
    nicuLevel: 'Level I',
    bloodBankOnSite: false,
    freeGovtSubsidized: true,
    totalMaternityBeds: 25,
    availableMaternityBeds: 10,
    availableNicuBeds: 2,
    submittedAt: 'Today, 09:15 AM',
    status: 'pending',
    licenseDocumentName: 'clinical_establishment_license_2026.pdf',
    contactPersonName: 'Dr. Sarah Thomas',
    contactPersonRole: 'Medical Superintendent',
    contactPersonEmail: 'sarah.thomas@motherteresa.org'
  },
  {
    id: 'reg-102',
    name: 'Hope Specialized Mother & Child Hospital',
    licenseNumber: 'CEA-DL-2025-7832',
    type: 'Maternity Specialty Center',
    address: 'Main Health Expressway, Sector 21',
    district: 'North District',
    phone: '+1 (800) 555-8811',
    emergencyPhone: '+1 (800) 555-8899',
    ambulancePhone: '+1 (800) 555-8898',
    lat: 28.6550,
    lng: 77.2400,
    services: [
      '24/7 Emergency C-Section',
      'NICU Level III (Intensive)',
      'Blood Storage Unit & Component Therapy',
      'Maternal High-Dependency Unit (HDU)',
      'Normal Delivery Suites'
    ],
    emergencyCSection24x7: true,
    nicuLevel: 'Level III',
    bloodBankOnSite: true,
    freeGovtSubsidized: false,
    totalMaternityBeds: 50,
    availableMaternityBeds: 16,
    availableNicuBeds: 5,
    submittedAt: 'Yesterday, 04:30 PM',
    status: 'pending',
    licenseDocumentName: 'state_health_board_accreditation.pdf',
    contactPersonName: 'Dr. Vivek Malhotra',
    contactPersonRole: 'Director of Obstetrics',
    contactPersonEmail: 'v.malhotra@hopehospital.org'
  },
  {
    id: 'reg-103',
    name: 'Sunrise Community Health Post',
    licenseNumber: 'EXP-REG-2023-1102',
    type: 'Primary Health Center (24/7)',
    address: 'Village Chowk, West Bypass',
    district: 'West Rural Cluster',
    phone: '+1 (800) 444-1234',
    emergencyPhone: '+1 (800) 444-1299',
    ambulancePhone: '+1 (800) 444-1298',
    lat: 28.5100,
    lng: 77.1100,
    services: ['Normal Delivery 24/7'],
    emergencyCSection24x7: false,
    nicuLevel: 'None',
    bloodBankOnSite: false,
    freeGovtSubsidized: true,
    totalMaternityBeds: 8,
    availableMaternityBeds: 2,
    availableNicuBeds: 0,
    submittedAt: '3 days ago',
    status: 'rejected',
    reviewedAt: '2 days ago',
    rejectionReason: 'Clinical Establishment License expired in 2023. Mandatory neonatal resuscitation equipment missing.',
    contactPersonName: 'Mr. Arvind Joshi',
    contactPersonRole: 'Center Manager',
    contactPersonEmail: 'arvind.joshi@ruralhealth.org'
  }
];
