import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Hospital, 
  Doctor, 
  EmergencyRequest, 
  HealthReminder, 
  UserProfile, 
  Appointment, 
  EmergencyStatus,
  LocationCoordinates,
  MedicalRecord,
  VitalCheckLog,
  AmbulanceInfo,
  HospitalReferral,
  HealthUpdate,
  HospitalRegistration
} from '../types';
import { 
  INITIAL_HOSPITALS, 
  INITIAL_DOCTORS, 
  INITIAL_EMERGENCY_REQUESTS, 
  INITIAL_REMINDERS, 
  INITIAL_AMBULANCE_FLEET,
  SAMPLE_MEDICAL_RECORDS,
  SAMPLE_VITAL_LOGS,
  SAMPLE_HOSPITAL_REFERRALS,
  HEALTH_UPDATES,
  DEFAULT_PATIENT_USER,
  DEFAULT_ADMIN_USER,
  INITIAL_HOSPITAL_REGISTRATIONS
} from '../data/mockData';

interface AppContextType {
  currentUser: UserProfile;
  setCurrentUser: (user: UserProfile) => void;
  switchUserRole: (role: 'patient' | 'admin') => void;
  hospitals: Hospital[];
  setHospitals: React.Dispatch<React.SetStateAction<Hospital[]>>;
  doctors: Doctor[];
  setDoctors: React.Dispatch<React.SetStateAction<Doctor[]>>;
  emergencyRequests: EmergencyRequest[];
  activeEmergency: EmergencyRequest | null;
  appointments: Appointment[];
  reminders: HealthReminder[];
  medicalRecords: MedicalRecord[];
  vitalLogs: VitalCheckLog[];
  ambulanceFleet: AmbulanceInfo[];
  hospitalReferrals: HospitalReferral[];
  healthUpdates: HealthUpdate[];
  registeredPatients: UserProfile[];
  hospitalRegistrations: HospitalRegistration[];
  submitHospitalRegistration: (reg: Omit<HospitalRegistration, 'id' | 'submittedAt' | 'status'>) => HospitalRegistration;
  approveHospitalRegistration: (id: string, notes?: string) => void;
  rejectHospitalRegistration: (id: string, reason: string) => void;
  deleteHospital: (id: string) => void;
  editHospital: (id: string, updates: Partial<Hospital>) => void;
  isSosModalOpen: boolean;
  openSosModal: () => void;
  closeSosModal: () => void;
  submitEmergencyRequest: (req: Omit<EmergencyRequest, 'id' | 'timestamp' | 'status'>) => EmergencyRequest;
  updateEmergencyStatus: (
    id: string, 
    status: EmergencyStatus, 
    updates?: {
      assignedHospitalId?: string;
      assignedHospitalName?: string;
      dispatcherNotes?: string;
      etaMinutes?: number;
    }
  ) => void;
  bookAppointment: (apt: Omit<Appointment, 'id' | 'createdAt' | 'status'>) => Appointment;
  cancelAppointment: (id: string) => void;
  updateHospitalBeds: (id: string, availableBeds: number, nicuBeds: number) => void;
  updateHospitalDetails: (id: string, updates: Partial<Hospital>) => void;
  toggleReminder: (id: string) => void;
  addReminder: (rem: Omit<HealthReminder, 'id'>) => void;
  updateUserProfile: (profile: Partial<UserProfile>) => void;
  addMedicalRecord: (rec: Omit<MedicalRecord, 'id'>) => void;
  addVitalLog: (log: Omit<VitalCheckLog, 'id'>) => void;
  createReferral: (ref: Omit<HospitalReferral, 'id' | 'timestamp'>) => void;
  updateReferralStatus: (id: string, status: HospitalReferral['status']) => void;
  updateDoctorAvailability: (id: string, available: boolean) => void;
  updateAmbulanceStatus: (id: string, status: AmbulanceInfo['status'], locName?: string) => void;
  selectedFacilityForRoute: Hospital | null;
  setSelectedFacilityForRoute: (hospital: Hospital | null) => void;
  userLocation: LocationCoordinates;
  setUserLocation: (loc: LocationCoordinates) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Current user & role state
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('mcc_user');
    return saved ? JSON.parse(saved) : DEFAULT_PATIENT_USER;
  });

  // Hospitals
  const [hospitals, setHospitals] = useState<Hospital[]>(() => {
    const saved = localStorage.getItem('mcc_hospitals');
    return saved ? JSON.parse(saved) : INITIAL_HOSPITALS;
  });

  // Doctors
  const [doctors, setDoctors] = useState<Doctor[]>(() => {
    const saved = localStorage.getItem('mcc_doctors');
    return saved ? JSON.parse(saved) : INITIAL_DOCTORS;
  });

  // Emergency requests
  const [emergencyRequests, setEmergencyRequests] = useState<EmergencyRequest[]>(() => {
    const saved = localStorage.getItem('mcc_emergencies');
    return saved ? JSON.parse(saved) : INITIAL_EMERGENCY_REQUESTS;
  });

  // Active user emergency
  const [activeEmergencyId, setActiveEmergencyId] = useState<string | null>(() => {
    return localStorage.getItem('mcc_active_emergency_id') || null;
  });

  // Appointments
  const [appointments, setAppointments] = useState<Appointment[]>(() => {
    const saved = localStorage.getItem('mcc_appointments');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'apt-101',
        doctorId: 'doc-1',
        doctorName: 'Dr. Sunita Deshmukh',
        doctorSpecialization: 'Obstetrician & Gynecologist',
        doctorAvatar: 'https://images.unsplash.com/photo-1594824813689-dd4b82d02c89?auto=format&fit=crop&w=400&q=80',
        patientName: 'Amina Sharma',
        patientPhone: '+1 (555) 349-8812',
        date: '2026-11-12',
        timeSlot: '10:30 AM',
        consultType: 'video',
        gestationalWeek: 32,
        reason: 'Routine 32-week fetal growth review and blood pressure check',
        status: 'confirmed',
        createdAt: '2026-11-04T09:00:00Z',
        meetingLink: 'https://meet.maternalcareconnect.org/mcc-consult-101',
        consultationNotes: 'BP 118/76 mmHg. Fundal height 31 cm. Patient reports active fetal movements. Prescribed continuing IFA.',
        prescriptions: ['Ferrous Ascorbate 100mg + Folic Acid 1.5mg OD', 'Calcium Carbonate 500mg OD']
      },
      {
        id: 'apt-094',
        doctorId: 'doc-2',
        doctorName: 'Dr. Anita Roy-Chowdhury',
        doctorSpecialization: 'Maternal-Fetal Medicine (High Risk)',
        doctorAvatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=400&q=80',
        patientName: 'Amina Sharma',
        patientPhone: '+1 (555) 349-8812',
        date: '2026-10-18',
        timeSlot: '11:00 AM',
        consultType: 'in-person',
        gestationalWeek: 28,
        reason: 'Third trimester transition & high-risk preeclampsia evaluation',
        status: 'completed',
        createdAt: '2026-10-10T14:30:00Z',
        consultationNotes: 'Screening for gestational hypertension. Advised weekly home BP monitoring and fetal kick charts.',
        prescriptions: ['Labetalol 100mg (keep emergency supply if BP > 140/90)']
      }
    ];
  });

  // Health reminders
  const [reminders, setReminders] = useState<HealthReminder[]>(() => {
    const saved = localStorage.getItem('mcc_reminders');
    return saved ? JSON.parse(saved) : INITIAL_REMINDERS;
  });

  // Medical Records
  const [medicalRecords, setMedicalRecords] = useState<MedicalRecord[]>(() => {
    const saved = localStorage.getItem('mcc_medical_records');
    return saved ? JSON.parse(saved) : SAMPLE_MEDICAL_RECORDS;
  });

  // Vital Logs
  const [vitalLogs, setVitalLogs] = useState<VitalCheckLog[]>(() => {
    const saved = localStorage.getItem('mcc_vital_logs');
    return saved ? JSON.parse(saved) : SAMPLE_VITAL_LOGS;
  });

  // Ambulance Fleet
  const [ambulanceFleet, setAmbulanceFleet] = useState<AmbulanceInfo[]>(() => {
    const saved = localStorage.getItem('mcc_ambulances');
    return saved ? JSON.parse(saved) : INITIAL_AMBULANCE_FLEET;
  });

  // Hospital Referrals
  const [hospitalReferrals, setHospitalReferrals] = useState<HospitalReferral[]>(() => {
    const saved = localStorage.getItem('mcc_referrals');
    return saved ? JSON.parse(saved) : SAMPLE_HOSPITAL_REFERRALS;
  });

  // Health Updates
  const [healthUpdates] = useState<HealthUpdate[]>(HEALTH_UPDATES);

  // Registered Patients (for Admin hub management)
  const [registeredPatients] = useState<UserProfile[]>([
    DEFAULT_PATIENT_USER,
    {
      id: 'usr-patient-2',
      name: 'Pooja Verma',
      email: 'pooja.verma@example.org',
      phone: '+1 (555) 234-8901',
      role: 'patient',
      gestationalWeek: 36,
      expectedDueDate: '2026-12-04',
      bloodGroup: 'O Positive (O+)',
      address: 'Village Kheda, East Rural Sector',
      emergencyContactName: 'Deepak Verma',
      emergencyContactPhone: '+1 (555) 234-8902',
      highRiskFlags: ['Prior C-Section', 'Mild Anemia']
    },
    {
      id: 'usr-patient-3',
      name: 'Kavita Patel',
      email: 'kavita.patel@example.com',
      phone: '+1 (555) 456-1122',
      role: 'patient',
      gestationalWeek: 39,
      expectedDueDate: '2026-11-13',
      bloodGroup: 'A Positive (A+)',
      address: 'Shanti Enclave, Block B',
      emergencyContactName: 'Manish Patel',
      emergencyContactPhone: '+1 (555) 456-1123',
      highRiskFlags: ['Active Labor Candidate']
    },
    {
      id: 'usr-patient-4',
      name: 'Meera Devi',
      email: 'meera.devi@example.org',
      phone: '+1 (555) 987-6543',
      role: 'patient',
      gestationalWeek: 34,
      expectedDueDate: '2026-12-18',
      bloodGroup: 'AB Negative (AB-)',
      address: 'Near Old Bus Stand, North Corridor',
      emergencyContactName: 'Suraj Devi',
      emergencyContactPhone: '+1 (555) 987-6544',
      highRiskFlags: ['Preeclampsia High Risk', 'Rh Negative (RhoGAM given)']
    }
  ]);

  // Hospital Registrations (Pending verification, approved, or rejected)
  const [hospitalRegistrations, setHospitalRegistrations] = useState<HospitalRegistration[]>(() => {
    const saved = localStorage.getItem('mcc_hospital_registrations');
    return saved ? JSON.parse(saved) : INITIAL_HOSPITAL_REGISTRATIONS;
  });

  // User location (default: near central cluster)
  const [userLocation, setUserLocation] = useState<LocationCoordinates>({
    lat: 28.6139,
    lng: 77.2090,
    address: 'Green Meadows, Sector 14B, East Suburb',
    district: 'Central-East Corridor'
  });

  // Modal & routing helpers
  const [isSosModalOpen, setIsSosModalOpen] = useState(false);
  const [selectedFacilityForRoute, setSelectedFacilityForRoute] = useState<Hospital | null>(null);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('mcc_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('mcc_hospitals', JSON.stringify(hospitals));
  }, [hospitals]);

  useEffect(() => {
    localStorage.setItem('mcc_doctors', JSON.stringify(doctors));
  }, [doctors]);

  useEffect(() => {
    localStorage.setItem('mcc_emergencies', JSON.stringify(emergencyRequests));
  }, [emergencyRequests]);

  useEffect(() => {
    localStorage.setItem('mcc_appointments', JSON.stringify(appointments));
  }, [appointments]);

  useEffect(() => {
    localStorage.setItem('mcc_reminders', JSON.stringify(reminders));
  }, [reminders]);

  useEffect(() => {
    localStorage.setItem('mcc_medical_records', JSON.stringify(medicalRecords));
  }, [medicalRecords]);

  useEffect(() => {
    localStorage.setItem('mcc_vital_logs', JSON.stringify(vitalLogs));
  }, [vitalLogs]);

  useEffect(() => {
    localStorage.setItem('mcc_ambulances', JSON.stringify(ambulanceFleet));
  }, [ambulanceFleet]);

  useEffect(() => {
    localStorage.setItem('mcc_referrals', JSON.stringify(hospitalReferrals));
  }, [hospitalReferrals]);

  useEffect(() => {
    localStorage.setItem('mcc_hospital_registrations', JSON.stringify(hospitalRegistrations));
  }, [hospitalRegistrations]);

  useEffect(() => {
    if (activeEmergencyId) {
      localStorage.setItem('mcc_active_emergency_id', activeEmergencyId);
    } else {
      localStorage.removeItem('mcc_active_emergency_id');
    }
  }, [activeEmergencyId]);

  // Derived active emergency
  const activeEmergency = emergencyRequests.find(r => r.id === activeEmergencyId) || null;

  const openSosModal = () => setIsSosModalOpen(true);
  const closeSosModal = () => setIsSosModalOpen(false);

  const switchUserRole = (role: 'patient' | 'admin') => {
    if (role === 'admin') {
      setCurrentUser(DEFAULT_ADMIN_USER);
    } else {
      setCurrentUser(DEFAULT_PATIENT_USER);
    }
  };

  // Submit SOS emergency request
  const submitEmergencyRequest = (reqData: Omit<EmergencyRequest, 'id' | 'timestamp' | 'status'>): EmergencyRequest => {
    const newId = `sos-${Math.floor(1000 + Math.random() * 9000)}`;
    const nearestHosp = hospitals[0] || INITIAL_HOSPITALS[0];
    const assignedAmb = ambulanceFleet[0] || INITIAL_AMBULANCE_FLEET[0];

    const newRequest: EmergencyRequest = {
      ...reqData,
      id: newId,
      timestamp: 'Just now',
      status: 'submitted',
      assignedHospitalId: nearestHosp.id,
      assignedHospitalName: nearestHosp.name,
      assignedAmbulance: {
        ...assignedAmb,
        assignedRequestId: newId,
        assignedHospital: nearestHosp.name,
        etaMinutes: 10
      },
      dispatcherNotes: 'Digital SOS triggered. Telemetry transmitted to nearest 24/7 maternity trauma cell. Dispatched preliminary ALS team.'
    };

    setEmergencyRequests(prev => [newRequest, ...prev]);
    setActiveEmergencyId(newId);

    // Update fleet status
    setAmbulanceFleet(prev => prev.map(amb => amb.id === assignedAmb.id ? { ...amb, status: 'dispatched', etaMinutes: 10, assignedRequestId: newId } : amb));

    setTimeout(() => {
      setEmergencyRequests(prev => 
        prev.map(r => r.id === newId ? { ...r, status: 'triaged', dispatcherNotes: 'Triage officer reviewed case. Contacting nearest obstetric unit on-call doctor.' } : r)
      );
    }, 4000);

    setTimeout(() => {
      setEmergencyRequests(prev => 
        prev.map(r => r.id === newId ? { 
          ...r, 
          status: 'ambulance_dispatched', 
          dispatcherNotes: 'Ambulance is actively navigating to patient GPS coordinates. Sirens active.',
          assignedAmbulance: r.assignedAmbulance ? { ...r.assignedAmbulance, etaMinutes: 7 } : undefined
        } : r)
      );
    }, 9000);

    return newRequest;
  };

  const updateEmergencyStatus = (
    id: string, 
    status: EmergencyStatus, 
    updates?: {
      assignedHospitalId?: string;
      assignedHospitalName?: string;
      dispatcherNotes?: string;
      etaMinutes?: number;
    }
  ) => {
    setEmergencyRequests(prev => 
      prev.map(r => {
        if (r.id !== id) return r;
        return {
          ...r,
          status,
          ...(updates?.assignedHospitalId ? { assignedHospitalId: updates.assignedHospitalId } : {}),
          ...(updates?.assignedHospitalName ? { assignedHospitalName: updates.assignedHospitalName } : {}),
          ...(updates?.dispatcherNotes ? { dispatcherNotes: updates.dispatcherNotes } : {}),
          ...(updates?.etaMinutes !== undefined && r.assignedAmbulance 
            ? { assignedAmbulance: { ...r.assignedAmbulance, etaMinutes: updates.etaMinutes } } 
            : {})
        };
      })
    );
  };

  const bookAppointment = (aptData: Omit<Appointment, 'id' | 'createdAt' | 'status'>): Appointment => {
    const newApt: Appointment = {
      ...aptData,
      id: `apt-${Math.floor(100 + Math.random() * 900)}`,
      status: 'confirmed',
      createdAt: new Date().toISOString(),
      meetingLink: aptData.consultType === 'video' ? `https://meet.maternalcareconnect.org/mcc-consult-${Date.now()}` : undefined
    };

    setAppointments(prev => [newApt, ...prev]);
    return newApt;
  };

  const cancelAppointment = (id: string) => {
    setAppointments(prev => prev.map(a => a.id === id ? { ...a, status: 'cancelled' } : a));
  };

  const updateHospitalBeds = (id: string, availableBeds: number, nicuBeds: number) => {
    setHospitals(prev => prev.map(h => {
      if (h.id !== id) return h;
      return {
        ...h,
        availableMaternityBeds: availableBeds,
        availableNicuBeds: nicuBeds,
        verifiedDate: 'Just updated'
      };
    }));
  };

  const updateHospitalDetails = (id: string, updates: Partial<Hospital>) => {
    setHospitals(prev => prev.map(h => h.id === id ? { ...h, ...updates } : h));
  };

  const updateDoctorAvailability = (id: string, available: boolean) => {
    setDoctors(prev => prev.map(d => d.id === id ? { ...d, availableNow: available } : d));
  };

  const updateAmbulanceStatus = (id: string, status: AmbulanceInfo['status'], locName?: string) => {
    setAmbulanceFleet(prev => prev.map(a => a.id === id ? { ...a, status, ...(locName ? { currentLocationName: locName } : {}) } : a));
  };

  const toggleReminder = (id: string) => {
    setReminders(prev => prev.map(r => r.id === id ? { ...r, completed: !r.completed } : r));
  };

  const addReminder = (remData: Omit<HealthReminder, 'id'>) => {
    const newRem: HealthReminder = {
      ...remData,
      id: `rem-${Date.now()}`
    };
    setReminders(prev => [newRem, ...prev]);
  };

  const addMedicalRecord = (recData: Omit<MedicalRecord, 'id'>) => {
    const newRec: MedicalRecord = {
      ...recData,
      id: `rec-${Date.now()}`
    };
    setMedicalRecords(prev => [newRec, ...prev]);
  };

  const addVitalLog = (logData: Omit<VitalCheckLog, 'id'>) => {
    const newLog: VitalCheckLog = {
      ...logData,
      id: `vit-${Date.now()}`
    };
    setVitalLogs(prev => [newLog, ...prev]);
  };

  const createReferral = (refData: Omit<HospitalReferral, 'id' | 'timestamp'>) => {
    const newRef: HospitalReferral = {
      ...refData,
      id: `ref-${Math.floor(100 + Math.random() * 900)}`,
      timestamp: 'Just now'
    };
    setHospitalReferrals(prev => [newRef, ...prev]);
  };

  const updateReferralStatus = (id: string, status: HospitalReferral['status']) => {
    setHospitalReferrals(prev => prev.map(r => r.id === id ? { ...r, status } : r));
  };

  const updateUserProfile = (profileUpdate: Partial<UserProfile>) => {
    setCurrentUser(prev => ({
      ...prev,
      ...profileUpdate
    }));
  };

  // Submit Hospital Registration
  const submitHospitalRegistration = (
    regData: Omit<HospitalRegistration, 'id' | 'submittedAt' | 'status'>
  ): HospitalRegistration => {
    const newId = `reg-${Math.floor(100 + Math.random() * 900)}`;
    const newReg: HospitalRegistration = {
      ...regData,
      id: newId,
      submittedAt: 'Just now',
      status: 'pending'
    };
    setHospitalRegistrations(prev => [newReg, ...prev]);
    return newReg;
  };

  // Approve Hospital Registration and Automatically Update Hospital Finder
  const approveHospitalRegistration = (id: string, notes?: string) => {
    let regToApprove: HospitalRegistration | undefined;

    setHospitalRegistrations(prev =>
      prev.map(reg => {
        if (reg.id !== id) return reg;
        regToApprove = {
          ...reg,
          status: 'approved',
          reviewedAt: 'Just now',
          verificationNotes: notes || 'Verified and approved by Clinical Healthcare Authority'
        };
        return regToApprove;
      })
    );

    const target = regToApprove || hospitalRegistrations.find(r => r.id === id);
    if (!target) return;

    // Build the Hospital entry
    const newHospital: Hospital = {
      id: `hosp-${target.id}`,
      name: target.name,
      licenseNumber: target.licenseNumber,
      isVerified: true,
      registrationStatus: 'approved',
      type: target.type,
      address: target.address,
      district: target.district || 'Healthcare District',
      phone: target.phone,
      emergencyPhone: target.emergencyPhone || target.phone,
      ambulancePhone: target.ambulancePhone || target.phone,
      lat: target.lat || 28.6139,
      lng: target.lng || 77.2090,
      distanceKm: 3.5,
      travelTimeMinutes: 11,
      services: target.services.length > 0 ? target.services : ['Normal Delivery 24/7', 'Maternity Emergency Triage'],
      emergencyCSection24x7: target.emergencyCSection24x7,
      nicuLevel: target.nicuLevel,
      bloodBankOnSite: target.bloodBankOnSite,
      freeGovtSubsidized: target.freeGovtSubsidized,
      totalMaternityBeds: target.totalMaternityBeds,
      availableMaternityBeds: target.availableMaternityBeds,
      availableNicuBeds: target.availableNicuBeds,
      rating: 4.8,
      reviewsCount: 1,
      verifiedDate: 'Just Approved & Live',
      isOpen24x7: true
    };

    // Auto-update Hospital Finder list: replace if already exists by license or id, else prepend
    setHospitals(prev => {
      const idx = prev.findIndex(h => h.id === newHospital.id || (target.licenseNumber && h.licenseNumber === target.licenseNumber));
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = { ...copy[idx], ...newHospital };
        return copy;
      }
      return [newHospital, ...prev];
    });
  };

  // Reject Hospital Registration
  const rejectHospitalRegistration = (id: string, reason: string) => {
    setHospitalRegistrations(prev =>
      prev.map(reg => {
        if (reg.id !== id) return reg;
        return {
          ...reg,
          status: 'rejected',
          reviewedAt: 'Just now',
          rejectionReason: reason
        };
      })
    );
  };

  // Delete Hospital (automatically removes from Hospital Finder & interactive map)
  const deleteHospital = (id: string) => {
    setHospitals(prev => prev.filter(h => h.id !== id));
  };

  // Edit Hospital (automatically updates Hospital Finder & interactive map)
  const editHospital = (id: string, updates: Partial<Hospital>) => {
    setHospitals(prev =>
      prev.map(h => {
        if (h.id !== id) return h;
        return {
          ...h,
          ...updates,
          verifiedDate: 'Just updated'
        };
      })
    );
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        switchUserRole,
        hospitals,
        setHospitals,
        doctors,
        setDoctors,
        emergencyRequests,
        activeEmergency,
        appointments,
        reminders,
        medicalRecords,
        vitalLogs,
        ambulanceFleet,
        hospitalReferrals,
        healthUpdates,
        registeredPatients,
        hospitalRegistrations,
        submitHospitalRegistration,
        approveHospitalRegistration,
        rejectHospitalRegistration,
        deleteHospital,
        editHospital,
        isSosModalOpen,
        openSosModal,
        closeSosModal,
        submitEmergencyRequest,
        updateEmergencyStatus,
        bookAppointment,
        cancelAppointment,
        updateHospitalBeds,
        updateHospitalDetails,
        toggleReminder,
        addReminder,
        updateUserProfile,
        addMedicalRecord,
        addVitalLog,
        createReferral,
        updateReferralStatus,
        updateDoctorAvailability,
        updateAmbulanceStatus,
        selectedFacilityForRoute,
        setSelectedFacilityForRoute,
        userLocation,
        setUserLocation
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
