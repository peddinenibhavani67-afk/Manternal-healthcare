import React, { useState } from 'react';
import { 
  BookOpen, 
  Baby, 
  AlertTriangle, 
  Apple, 
  Calendar, 
  Calculator, 
  CheckCircle2, 
  AlertOctagon, 
  Syringe,
  Activity,
  Smile
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PREGNANCY_RED_FLAGS, VACCINATION_SCHEDULE_DATA } from '../data/mockData';

export const PregnancyCarePage: React.FC = () => {
  const { openSosModal } = useApp();

  // Section Tab
  const [activeCareTab, setActiveCareTab] = useState<'tips' | 'nutrition' | 'vaccines' | 'stages' | 'warnings' | 'postnatal'>('tips');

  // Due Date Calculator State
  const [lmpDate, setLmpDate] = useState('2026-04-01');
  const [calculatedEdd, setCalculatedEdd] = useState<string | null>(null);
  const [gestationalAgeWeeks, setGestationalAgeWeeks] = useState<number | null>(null);

  const calculateDueDate = () => {
    if (!lmpDate) return;
    const lmp = new Date(lmpDate);
    const edd = new Date(lmp.getTime() + 280 * 24 * 60 * 60 * 1000);
    setCalculatedEdd(edd.toDateString());

    const now = new Date();
    const diffTime = Math.abs(now.getTime() - lmp.getTime());
    const diffWeeks = Math.floor(diffTime / (1000 * 60 * 60 * 24 * 7));
    setGestationalAgeWeeks(Math.min(Math.max(diffWeeks, 1), 42));
  };

  const getBabySizeAnalogy = (weeks: number) => {
    if (weeks <= 8) return { item: 'Raspberry', length: '1.6 cm', weight: '1 g' };
    if (weeks <= 12) return { item: 'Lime', length: '5.4 cm', weight: '14 g' };
    if (weeks <= 16) return { item: 'Avocado', length: '11.6 cm', weight: '100 g' };
    if (weeks <= 20) return { item: 'Banana', length: '25.6 cm', weight: '300 g' };
    if (weeks <= 24) return { item: 'Corn on the cob', length: '30 cm', weight: '600 g' };
    if (weeks <= 28) return { item: 'Eggplant', length: '37 cm', weight: '1 kg' };
    if (weeks <= 32) return { item: 'Squash', length: '42 cm', weight: '1.7 kg' };
    if (weeks <= 36) return { item: 'Papaya', length: '47 cm', weight: '2.6 kg' };
    return { item: 'Watermelon', length: '50 cm', weight: '3.4 kg' };
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      
      {/* Page Title */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-bold uppercase tracking-wider mb-2">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Comprehensive Maternal Healthcare Education</span>
          </div>
          <h1 className="font-heading text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Pregnancy Care & Awareness Hub
          </h1>
          <p className="text-sm sm:text-base text-slate-600 mt-1 max-w-2xl">
            Evidence-based maternal advice covering pregnancy health tips, nutrition, vaccination schedules, pregnancy stages, danger signs, and postpartum mother & baby care.
          </p>
        </div>

        <button
          onClick={openSosModal}
          className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-md flex items-center gap-2 cursor-pointer self-start md:self-auto animate-emergency"
        >
          <AlertTriangle className="w-4 h-4" />
          <span>Experiencing Warning Signs?</span>
        </button>
      </div>

      {/* Main Navigation Sub-Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-3">
        <button
          onClick={() => setActiveCareTab('tips')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
            activeCareTab === 'tips' ? 'bg-rose-600 text-white shadow-xs' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>Pregnancy Health Tips</span>
        </button>

        <button
          onClick={() => setActiveCareTab('nutrition')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
            activeCareTab === 'nutrition' ? 'bg-rose-600 text-white shadow-xs' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Apple className="w-3.5 h-3.5" />
          <span>Nutrition Guidance</span>
        </button>

        <button
          onClick={() => setActiveCareTab('vaccines')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
            activeCareTab === 'vaccines' ? 'bg-rose-600 text-white shadow-xs' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Syringe className="w-3.5 h-3.5" />
          <span>Vaccination Schedule</span>
        </button>

        <button
          onClick={() => setActiveCareTab('stages')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
            activeCareTab === 'stages' ? 'bg-rose-600 text-white shadow-xs' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Baby className="w-3.5 h-3.5" />
          <span>Pregnancy Stages & EDD</span>
        </button>

        <button
          onClick={() => setActiveCareTab('warnings')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
            activeCareTab === 'warnings' ? 'bg-red-600 text-white shadow-xs' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <AlertOctagon className="w-3.5 h-3.5" />
          <span>Warning Signs Awareness</span>
        </button>

        <button
          onClick={() => setActiveCareTab('postnatal')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
            activeCareTab === 'postnatal' ? 'bg-rose-600 text-white shadow-xs' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Smile className="w-3.5 h-3.5" />
          <span>Mother & Baby Care (Postnatal)</span>
        </button>
      </div>

      {/* 1. PREGNANCY HEALTH TIPS */}
      {activeCareTab === 'tips' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
            <div>
              <h2 className="font-heading font-extrabold text-2xl text-slate-900">
                Essential Pregnancy Health Tips & Daily Habits
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Practical everyday habits to safeguard both mother and developing child.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-700">
              <div className="p-5 rounded-2xl border border-slate-100 bg-slate-50/70 space-y-2">
                <div className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-600"></span>
                  <span>Optimal Sleep Position: Left Side</span>
                </div>
                <p className="text-slate-600 leading-relaxed">
                  Sleeping on your left side prevents the heavy uterus from compressing the inferior vena cava. This maximizes oxygen and blood delivery to the placenta and assists maternal kidney excretion.
                </p>
              </div>

              <div className="p-5 rounded-2xl border border-slate-100 bg-slate-50/70 space-y-2">
                <div className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-pink-600"></span>
                  <span>Daily Kegel & Pelvic Floor Exercises</span>
                </div>
                <p className="text-slate-600 leading-relaxed">
                  Pelvic floor toning reduces urinary stress incontinence and prepares muscles for smooth normal vaginal delivery. Perform 10-15 contractions three times daily.
                </p>
              </div>

              <div className="p-5 rounded-2xl border border-slate-100 bg-slate-50/70 space-y-2">
                <div className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-sky-600"></span>
                  <span>Adequate Hydration & Electrolytes</span>
                </div>
                <p className="text-slate-600 leading-relaxed">
                  Drink 2.5 to 3 liters of fluids daily (water, coconut water, buttermilk). Good hydration maintains healthy amniotic fluid levels and reduces painful muscle cramps and urinary tract infections.
                </p>
              </div>

              <div className="p-5 rounded-2xl border border-slate-100 bg-slate-50/70 space-y-2">
                <div className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
                  <span>Oral Hygiene & Gum Health</span>
                </div>
                <p className="text-slate-600 leading-relaxed">
                  Pregnancy gingivitis caused by elevated progesterone can allow oral bacteria into the bloodstream, linked to preterm birth. Brush twice daily and attend regular dental cleanings.
                </p>
              </div>

              <div className="p-5 rounded-2xl border border-slate-100 bg-slate-50/70 space-y-2">
                <div className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-600"></span>
                  <span>Safe Physical Activity</span>
                </div>
                <p className="text-slate-600 leading-relaxed">
                  Moderate exercise like prenatal yoga, light swimming, and brisk 30-minute walks helps prevent excessive gestational weight gain and lowers risk of gestational diabetes and preeclampsia.
                </p>
              </div>

              <div className="p-5 rounded-2xl border border-slate-100 bg-slate-50/70 space-y-2">
                <div className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-purple-600"></span>
                  <span>Stress Reduction & Emotional Rest</span>
                </div>
                <p className="text-slate-600 leading-relaxed">
                  Chronic stress releases maternal cortisol, impacting fetal neurodevelopment. Practice deep breathing, avoid stressful environments, and seek partner or community midwife support.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. NUTRITION GUIDANCE */}
      {activeCareTab === 'nutrition' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
            <div>
              <h2 className="font-heading font-extrabold text-2xl text-slate-900">
                Maternal Nutrition & Diet Guidance
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Fueling fetal tissue growth and preventing maternal micronutrient deficiencies.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 text-xs">
              <div className="bg-rose-50/70 p-5 rounded-2xl border border-rose-100 space-y-2">
                <div className="font-bold text-rose-900 text-sm">Iron & Folic Acid</div>
                <p className="text-slate-600 leading-relaxed">
                  60mg elemental Iron + 400mcg Folic Acid daily. Prevents maternal anemia and neural tube defects. Take with citrus water for better absorption.
                </p>
                <div className="text-[11px] text-rose-800 font-semibold">Foods: Spinach, lentils, pomegranate, dates.</div>
              </div>

              <div className="bg-sky-50/70 p-5 rounded-2xl border border-sky-100 space-y-2">
                <div className="font-bold text-sky-900 text-sm">Calcium & Vitamin D</div>
                <p className="text-slate-600 leading-relaxed">
                  1,200mg Calcium daily. Builds strong fetal bones, teeth, and heart muscles. Keeps maternal blood pressure stable.
                </p>
                <div className="text-[11px] text-sky-800 font-semibold">Foods: Milk, curd, sesame seeds, fortified soya.</div>
              </div>

              <div className="bg-emerald-50/70 p-5 rounded-2xl border border-emerald-100 space-y-2">
                <div className="font-bold text-emerald-900 text-sm">Proteins & Fats (DHA)</div>
                <p className="text-slate-600 leading-relaxed">
                  75-100g protein daily. Crucial for rapid embryonic cell division and maternal uterine expansion.
                </p>
                <div className="text-[11px] text-emerald-800 font-semibold">Foods: Eggs, beans, paneer, walnuts, flaxseeds.</div>
              </div>

              <div className="bg-amber-50/70 p-5 rounded-2xl border border-amber-100 space-y-2">
                <div className="font-bold text-amber-900 text-sm">Foods Strictly to Avoid</div>
                <p className="text-slate-600 leading-relaxed">
                  Raw eggs, unpasteurized milk (Listeria risk), raw papaya (contains latex inducing contractions), high-mercury seafood, and excess caffeine.
                </p>
                <div className="text-[11px] text-amber-800 font-semibold">Avoid: Alcohol, tobacco, unwashed raw salads.</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. VACCINATION INFORMATION */}
      {activeCareTab === 'vaccines' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="font-heading font-extrabold text-2xl text-slate-900">
                  Maternal & Newborn Vaccination Schedule
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Protective immunizations transfer vital maternal antibodies across the placenta to shield newborns during their first months.
                </p>
              </div>
              <span className="text-xs bg-emerald-50 text-emerald-800 font-bold px-3 py-1.5 rounded-xl border border-emerald-200">
                100% Free at All Govt. Health Centers
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border border-slate-200 rounded-2xl overflow-hidden">
                <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="p-3.5">Vaccine</th>
                    <th className="p-3.5">Recommended Timing</th>
                    <th className="p-3.5">Protects Against</th>
                    <th className="p-3.5">Clinical Purpose</th>
                    <th className="p-3.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-600">
                  {VACCINATION_SCHEDULE_DATA.map((v, i) => (
                    <tr key={i} className="hover:bg-rose-50/30 transition">
                      <td className="p-3.5 font-bold text-slate-900">{v.vaccine}</td>
                      <td className="p-3.5 font-semibold text-rose-600">{v.recommendedTiming}</td>
                      <td className="p-3.5 text-slate-700">{v.targetDisease}</td>
                      <td className="p-3.5 leading-relaxed">{v.importance}</td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase ${
                          v.mandatory ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {v.mandatory ? 'Mandatory' : 'Recommended'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 4. PREGNANCY STAGES & DUE DATE CALCULATOR */}
      {activeCareTab === 'stages' && (
        <div className="space-y-8">
          {/* Due date calculator */}
          <div className="bg-gradient-to-br from-rose-50 via-white to-pink-50 border border-rose-200 rounded-3xl p-6 sm:p-8 shadow-sm">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-5 space-y-3">
                <div className="flex items-center gap-1.5 text-xs font-bold text-rose-600 uppercase tracking-wide">
                  <Calculator className="w-4 h-4" />
                  <span>Clinical EDD Calculator</span>
                </div>
                <h3 className="font-heading font-extrabold text-2xl text-slate-900">
                  Calculate Estimated Due Date (EDD)
                </h3>
                <p className="text-xs text-slate-600">
                  Enter the first day of your Last Menstrual Period (LMP) to determine your baby's delivery date and current stage.
                </p>
                <div className="space-y-2 pt-2">
                  <label className="block text-xs font-bold text-slate-700">LMP Date:</label>
                  <input
                    type="date"
                    value={lmpDate}
                    onChange={(e) => setLmpDate(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl text-xs bg-white"
                  />
                  <button
                    onClick={calculateDueDate}
                    className="w-full bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs py-2.5 rounded-xl transition cursor-pointer"
                  >
                    Calculate Delivery Date & Growth Stage
                  </button>
                </div>
              </div>

              <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-rose-100 shadow-xs">
                {calculatedEdd && gestationalAgeWeeks ? (
                  <div className="space-y-4 text-xs">
                    <div className="flex justify-between items-center pb-3 border-b">
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase font-bold">Estimated Due Date</span>
                        <div className="font-heading font-extrabold text-2xl text-rose-600">{calculatedEdd}</div>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 uppercase font-bold">Current Gestation</span>
                        <div className="font-heading font-extrabold text-2xl text-slate-900">Week {gestationalAgeWeeks}</div>
                      </div>
                    </div>

                    <div className="bg-rose-50 p-4 rounded-xl flex items-center gap-4">
                      <Baby className="w-8 h-8 text-rose-600 shrink-0" />
                      <div>
                        <div className="font-bold text-slate-900">
                          Baby size: Approximately like a {getBabySizeAnalogy(gestationalAgeWeeks).item}!
                        </div>
                        <div className="text-slate-500">
                          Length: ~{getBabySizeAnalogy(gestationalAgeWeeks).length} • Weight: ~{getBabySizeAnalogy(gestationalAgeWeeks).weight}
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-6 text-slate-400 text-xs">
                    Click calculate above to view baby growth stages and delivery timeline.
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Stages Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-700">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-3">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-rose-100 text-rose-800">
                Weeks 1 - 12
              </span>
              <h4 className="font-heading font-bold text-base text-slate-900">First Trimester (Embryogenesis)</h4>
              <p className="text-slate-500 leading-relaxed">
                Vital organ formation, neural tube closure, and heartbeat detection by 6 weeks. Folic acid and dating ultrasound are top priorities.
              </p>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-3">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-pink-100 text-pink-800">
                Weeks 13 - 28
              </span>
              <h4 className="font-heading font-bold text-base text-slate-900">Second Trimester (Rapid Growth)</h4>
              <p className="text-slate-500 leading-relaxed">
                Level II anomaly ultrasound scan (18-20 weeks), gestational diabetes screening (OGTT), and first maternal perception of baby movements.
              </p>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-3">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-red-100 text-red-800">
                Weeks 29 - 40
              </span>
              <h4 className="font-heading font-bold text-base text-slate-900">Third Trimester (Birth Prep)</h4>
              <p className="text-slate-500 leading-relaxed">
                Rapid fetal fat deposit, lungs maturing. Daily fetal kick counts, preeclampsia surveillance, and birth preparedness kit packing.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 5. WARNING SIGNS AWARENESS */}
      {activeCareTab === 'warnings' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
            <div>
              <span className="text-rose-600 text-xs font-bold uppercase tracking-wide">Emergency Warning Triage</span>
              <h2 className="font-heading font-extrabold text-2xl text-slate-900 mt-1">
                Danger Signs Awareness (Seek Emergency Care Immediately)
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Never wait for morning hours if any of these symptoms present themselves.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-xs">
              {PREGNANCY_RED_FLAGS.map((rf) => (
                <div key={rf.id} className="p-5 rounded-2xl border border-slate-200 bg-white space-y-3 shadow-xs flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                        rf.urgency === 'critical' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                      }`}>
                        {rf.urgency} Urgency
                      </span>
                      <AlertOctagon className={`w-4 h-4 ${rf.urgency === 'critical' ? 'text-red-600' : 'text-amber-500'}`} />
                    </div>
                    <div className="font-heading font-bold text-base text-slate-900">{rf.title}</div>
                    <p className="text-slate-600 mt-1">{rf.symptom}</p>
                    <div className="text-[11px] text-slate-400 mt-2">Possible: {rf.potentialCauses}</div>
                  </div>

                  <div className="p-3 rounded-xl bg-rose-50 text-rose-950 font-medium">
                    <strong>Action:</strong> {rf.immediateAction}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 6. MOTHER AND BABY CARE (POSTNATAL RECOVERY) */}
      {activeCareTab === 'postnatal' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
            <div>
              <h2 className="font-heading font-extrabold text-2xl text-slate-900">
                Mother & Baby Care (The Golden 42 Days Postpartum)
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                The postpartum puerperium requires dedicated maternal physical recovery, newborn feeding support, and vigilance for complications.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-700">
              <div className="p-5 rounded-2xl border border-rose-100 bg-rose-50/50 space-y-3">
                <div className="font-bold text-rose-900 text-sm">Postnatal Maternal Danger Signs</div>
                <ul className="space-y-1.5 text-slate-600">
                  <li>• Soaking more than 1 sanitary pad in an hour (PPH)</li>
                  <li>• High fever with chills & foul vaginal discharge</li>
                  <li>• Severe calf swelling or throbbing leg pain (DVT)</li>
                  <li>• Persistent severe headache with high BP readings</li>
                  <li>• Burning pain or red streaks on breast (Mastitis)</li>
                </ul>
              </div>

              <div className="p-5 rounded-2xl border border-sky-100 bg-sky-50/50 space-y-3">
                <div className="font-bold text-sky-900 text-sm">Newborn Critical Danger Signs</div>
                <ul className="space-y-1.5 text-slate-600">
                  <li>• Inability to suckle or latch to breast</li>
                  <li>• Extreme lethargy, limp body, or unresponsiveness</li>
                  <li>• Yellow discoloration of palms and soles (Jaundice)</li>
                  <li>• Rapid chest indrawing or grunting sounds</li>
                  <li>• Pus discharge or redness around umbilical stump</li>
                </ul>
              </div>

              <div className="p-5 rounded-2xl border border-purple-100 bg-purple-50/50 space-y-3">
                <div className="font-bold text-purple-900 text-sm">Postpartum Mental Health & Support</div>
                <p className="text-slate-600 leading-relaxed">
                  "Baby blues" (mild mood swings for 10-14 days) is normal. However, persistent despair, panic, inability to bond with baby, or thoughts of harm are symptoms of treatable <strong>Postpartum Depression</strong>. Never suffer in silence.
                </p>
                <div className="text-[11px] font-bold text-purple-700">
                  Call National Counseling: 1800-180-1104
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
