import React, { useState } from 'react';
import { 
  Building2, 
  FileText, 
  PhoneCall, 
  MapPin, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  UploadCloud, 
  Send, 
  ShieldCheck, 
  Activity, 
  HeartPulse, 
  Bed, 
  ArrowRight,
  ExternalLink,
  Info,
  Check,
  Compass,
  FileCheck
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { FacilityType, HospitalRegistration } from '../types';

interface HospitalRegistrationPageProps {
  setActiveTab: (tab: string) => void;
}

export const HospitalRegistrationPage: React.FC<HospitalRegistrationPageProps> = ({ setActiveTab }) => {
  const { 
    hospitalRegistrations, 
    submitHospitalRegistration,
    switchUserRole
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'register' | 'track'>('register');

  // Form state
  const [hospitalName, setHospitalName] = useState('');
  const [licenseNumber, setLicenseNumber] = useState('');
  const [facilityType, setFacilityType] = useState<FacilityType>('Maternity Specialty Center');
  const [address, setAddress] = useState('');
  const [district, setDistrict] = useState('Central District');
  const [lat, setLat] = useState<number>(28.6250);
  const [lng, setLng] = useState<number>(77.2150);
  const [phone, setPhone] = useState('');
  const [emergencyPhone, setEmergencyPhone] = useState('');
  const [ambulancePhone, setAmbulancePhone] = useState('');
  
  // Bed availability
  const [totalMaternityBeds, setTotalMaternityBeds] = useState<number>(30);
  const [availableMaternityBeds, setAvailableMaternityBeds] = useState<number>(8);
  const [availableNicuBeds, setAvailableNicuBeds] = useState<number>(2);
  const [nicuLevel, setNicuLevel] = useState<'Level I' | 'Level II' | 'Level III' | 'None'>('Level II');

  // Services
  const [emergencyCSection24x7, setEmergencyCSection24x7] = useState<boolean>(true);
  const [bloodBankOnSite, setBloodBankOnSite] = useState<boolean>(true);
  const [freeGovtSubsidized, setFreeGovtSubsidized] = useState<boolean>(false);
  const [selectedServices, setSelectedServices] = useState<string[]>([
    '24/7 Emergency C-Section',
    'Normal Delivery Suites',
    'Blood Storage Unit & Component Therapy',
    'Kangaroo Mother Care (KMC)'
  ]);

  // Contact Person
  const [contactPersonName, setContactPersonName] = useState('');
  const [contactPersonRole, setContactPersonRole] = useState('Medical Director / Superintendent');
  const [contactPersonEmail, setContactPersonEmail] = useState('');
  const [licenseDocumentName, setLicenseDocumentName] = useState('clinical_establishment_license_2026.pdf');

  // Submission feedback
  const [submittedRegId, setSubmittedRegId] = useState<string | null>(null);

  const availableServiceOptions = [
    '24/7 Emergency C-Section',
    'NICU Level III (Intensive)',
    'NICU Level II',
    'Normal Delivery Suites',
    'Blood Storage Unit & Component Therapy',
    'High-Risk Obstetric ICU',
    'Kangaroo Mother Care (KMC)',
    'Tele-Perinatal Referral Cell',
    'Portable Ultrasound & Fetal Doppler',
    'Postpartum Hemorrhage Rapid Response Kit',
    'Free Janani Shishu Scheme Delivery'
  ];

  const handleToggleService = (service: string) => {
    if (selectedServices.includes(service)) {
      setSelectedServices(prev => prev.filter(s => s !== service));
    } else {
      setSelectedServices(prev => [...prev, service]);
    }
  };

  const handleUseCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setLat(Number(pos.coords.latitude.toFixed(4)));
          setLng(Number(pos.coords.longitude.toFixed(4)));
          if (!address) {
            setAddress(`GPS Lat: ${pos.coords.latitude.toFixed(4)}, Lng: ${pos.coords.longitude.toFixed(4)}`);
          }
        },
        () => {
          // fallback default near city center
          setLat(28.6180);
          setLng(77.2100);
        }
      );
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!hospitalName.trim() || !licenseNumber.trim() || !address.trim() || !phone.trim()) {
      return;
    }

    const reg = submitHospitalRegistration({
      name: hospitalName.trim(),
      licenseNumber: licenseNumber.trim(),
      type: facilityType,
      address: address.trim(),
      district: district.trim(),
      phone: phone.trim(),
      emergencyPhone: emergencyPhone.trim() || phone.trim(),
      ambulancePhone: ambulancePhone.trim() || phone.trim(),
      lat,
      lng,
      services: selectedServices,
      emergencyCSection24x7,
      nicuLevel,
      bloodBankOnSite,
      freeGovtSubsidized,
      totalMaternityBeds: Number(totalMaternityBeds),
      availableMaternityBeds: Number(availableMaternityBeds),
      availableNicuBeds: Number(availableNicuBeds),
      licenseDocumentName,
      contactPersonName: contactPersonName.trim(),
      contactPersonRole: contactPersonRole.trim(),
      contactPersonEmail: contactPersonEmail.trim()
    });

    setSubmittedRegId(reg.id);
    setActiveSubTab('track');
  };

  const pendingCount = hospitalRegistrations.filter(r => r.status === 'pending').length;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Breadcrumb & Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-bold uppercase tracking-wider mb-2">
            <Building2 className="w-3.5 h-3.5" />
            <span>Maternity Healthcare Provider Onboarding</span>
          </div>
          <h1 className="font-heading text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Hospital Registration & Auto-Update System
          </h1>
          <p className="text-sm sm:text-base text-slate-600 mt-1 max-w-2xl">
            Register your maternity hospital or health facility. Once verified by our clinical triage board, your facility automatically publishes to the Hospital Finder map, live bed tracker, and emergency referral network.
          </p>
        </div>

        {/* Shortcuts */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveTab('hospitals')}
            className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 font-bold text-xs sm:text-sm flex items-center gap-1.5 transition cursor-pointer"
          >
            <Compass className="w-4 h-4 text-rose-600" />
            <span>Hospital Finder</span>
          </button>

          <button
            onClick={() => {
              switchUserRole('admin');
              setActiveTab('admin');
            }}
            className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-xs flex items-center gap-2 transition cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Admin Approvals Hub</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 gap-4 text-sm font-bold">
        <button
          onClick={() => setActiveSubTab('register')}
          className={`pb-3 border-b-2 transition flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'register'
              ? 'border-rose-600 text-rose-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>Register New Hospital</span>
        </button>

        <button
          onClick={() => setActiveSubTab('track')}
          className={`pb-3 border-b-2 transition flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'track'
              ? 'border-rose-600 text-rose-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileCheck className="w-4 h-4" />
          <span>View Submitted Registrations ({hospitalRegistrations.length})</span>
          {pendingCount > 0 && (
            <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full text-xs font-extrabold">
              {pendingCount} Pending
            </span>
          )}
        </button>
      </div>

      {/* SUB TAB 1: REGISTRATION FORM */}
      {activeSubTab === 'register' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Main Form (Left 8 cols) */}
          <div className="lg:col-span-8 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
            
            <div className="border-b border-slate-100 pb-4">
              <h2 className="font-heading font-extrabold text-xl text-slate-900">
                Hospital Information & Clinical Credentials
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Please enter official facility information as registered under the Clinical Establishments Act or State Health Authority.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6 text-xs">
              
              {/* Row 1: Hospital Name & License Number */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Hospital / Facility Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={hospitalName}
                    onChange={(e) => setHospitalName(e.target.value)}
                    placeholder="e.g. LifeCare Mother & Child Hospital"
                    className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Accreditation / License Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={licenseNumber}
                    onChange={(e) => setLicenseNumber(e.target.value)}
                    placeholder="e.g. CEA-REG-2026-8819"
                    className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">Clinical Establishment / Medical Council Registration</span>
                </div>
              </div>

              {/* Row 2: Facility Type & District */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Facility Classification <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={facilityType}
                    onChange={(e) => setFacilityType(e.target.value as FacilityType)}
                    className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none bg-white text-slate-700"
                  >
                    <option value="District Hospital">District Hospital (Comprehensive Care)</option>
                    <option value="Maternity Specialty Center">Maternity Specialty Center</option>
                    <option value="Sub-Divisional Hospital">Sub-Divisional Hospital</option>
                    <option value="Primary Health Center (24/7)">Primary Health Center (PHC 24/7)</option>
                    <option value="Community Health Center">Community Health Center</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Administrative District <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none bg-white text-slate-700"
                  >
                    <option value="Central District">Central District</option>
                    <option value="North District">North District</option>
                    <option value="East Rural District">East Rural District</option>
                    <option value="South Rural District">South Rural District</option>
                    <option value="North-West District">North-West District</option>
                    <option value="West Rural Cluster">West Rural Cluster</option>
                  </select>
                </div>
              </div>

              {/* Row 3: Physical Address & Coordinates */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Full Hospital Physical Address <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="e.g. Sector 18, Bypass Road, Opposite City Park, Landmark: Near Metro Pillar 42"
                  className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1 text-[11px]">Latitude (GPS)</label>
                  <input
                    type="number"
                    step="0.0001"
                    value={lat}
                    onChange={(e) => setLat(Number(e.target.value))}
                    className="w-full px-3 py-1.5 border rounded-lg bg-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1 text-[11px]">Longitude (GPS)</label>
                  <input
                    type="number"
                    step="0.0001"
                    value={lng}
                    onChange={(e) => setLng(Number(e.target.value))}
                    className="w-full px-3 py-1.5 border rounded-lg bg-white text-xs"
                  />
                </div>
                <div className="flex items-end">
                  <button
                    type="button"
                    onClick={handleUseCurrentLocation}
                    className="w-full py-1.5 px-3 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg text-slate-700 font-bold text-xs flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <MapPin className="w-3.5 h-3.5 text-rose-600" />
                    <span>Auto-Detect GPS</span>
                  </button>
                </div>
              </div>

              {/* Row 4: Contact Numbers */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <span className="font-bold text-slate-800 text-sm block">
                  Facility Contact & Emergency Lines
                </span>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">
                      General Reception Phone <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+1 (800) 222-3301"
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-bold mb-1">
                      24/7 Maternity ER Line <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      required
                      value={emergencyPhone}
                      onChange={(e) => setEmergencyPhone(e.target.value)}
                      placeholder="+1 (800) 222-3399"
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-bold mb-1">
                      Ambulance Dispatch Desk
                    </label>
                    <input
                      type="tel"
                      value={ambulancePhone}
                      onChange={(e) => setAmbulancePhone(e.target.value)}
                      placeholder="+1 (800) 222-3398"
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Row 5: Maternity Beds & NICU */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <span className="font-bold text-slate-800 text-sm block">
                  Maternity Bed Capacity & Neonatal Incubators
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">
                      Total Maternity Beds <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="500"
                      required
                      value={totalMaternityBeds}
                      onChange={(e) => setTotalMaternityBeds(Number(e.target.value))}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-bold mb-1">
                      Available Maternity Beds <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      min="0"
                      max={totalMaternityBeds}
                      required
                      value={availableMaternityBeds}
                      onChange={(e) => setAvailableMaternityBeds(Number(e.target.value))}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-bold mb-1">
                      Available NICU Beds <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="50"
                      required
                      value={availableNicuBeds}
                      onChange={(e) => setAvailableNicuBeds(Number(e.target.value))}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-bold mb-1">NICU Tier / Level</label>
                    <select
                      value={nicuLevel}
                      onChange={(e) => setNicuLevel(e.target.value as any)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm bg-white"
                    >
                      <option value="Level III">Level III (Intensive Sub-specialty)</option>
                      <option value="Level II">Level II (Special Care Nursery)</option>
                      <option value="Level I">Level I (Basic Newborn Resuscitation)</option>
                      <option value="None">None (Transfer Required)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Row 6: Available Maternity Services (Checkboxes) */}
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 text-sm">
                    Available Maternity Services & Emergency Capabilities
                  </span>
                  <span className="text-slate-400 text-[11px]">Select all active services</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {availableServiceOptions.map((srv) => {
                    const isChecked = selectedServices.includes(srv);
                    return (
                      <button
                        type="button"
                        key={srv}
                        onClick={() => handleToggleService(srv)}
                        className={`text-left p-3 rounded-xl border transition flex items-center justify-between cursor-pointer ${
                          isChecked
                            ? 'bg-rose-50 border-rose-400 text-rose-900 font-bold ring-1 ring-rose-300'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <span className="text-xs">{srv}</span>
                        <div className={`w-4 h-4 rounded-md flex items-center justify-center shrink-0 ml-2 ${
                          isChecked ? 'bg-rose-600 text-white' : 'border border-slate-300'
                        }`}>
                          {isChecked && <Check className="w-3 h-3" />}
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Key Flags */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                  <label className="flex items-center gap-2 p-2.5 border rounded-xl cursor-pointer bg-slate-50">
                    <input
                      type="checkbox"
                      checked={emergencyCSection24x7}
                      onChange={(e) => setEmergencyCSection24x7(e.target.checked)}
                      className="rounded text-rose-600 focus:ring-rose-500"
                    />
                    <span className="text-xs font-semibold text-slate-800">24/7 C-Section OT Ready</span>
                  </label>

                  <label className="flex items-center gap-2 p-2.5 border rounded-xl cursor-pointer bg-slate-50">
                    <input
                      type="checkbox"
                      checked={bloodBankOnSite}
                      onChange={(e) => setBloodBankOnSite(e.target.checked)}
                      className="rounded text-rose-600 focus:ring-rose-500"
                    />
                    <span className="text-xs font-semibold text-slate-800">Blood Bank / Storage On-Site</span>
                  </label>

                  <label className="flex items-center gap-2 p-2.5 border rounded-xl cursor-pointer bg-slate-50">
                    <input
                      type="checkbox"
                      checked={freeGovtSubsidized}
                      onChange={(e) => setFreeGovtSubsidized(e.target.checked)}
                      className="rounded text-rose-600 focus:ring-rose-500"
                    />
                    <span className="text-xs font-semibold text-slate-800">Free / Govt Scheme Delivery</span>
                  </label>
                </div>
              </div>

              {/* Row 7: Contact Person & Document Upload */}
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <span className="font-bold text-slate-800 text-sm block">
                  Authorizing Contact Person & License Upload
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">Contact Person Name</label>
                    <input
                      type="text"
                      value={contactPersonName}
                      onChange={(e) => setContactPersonName(e.target.value)}
                      placeholder="e.g. Dr. Rajeshwari Rao"
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-bold mb-1">Designation / Role</label>
                    <input
                      type="text"
                      value={contactPersonRole}
                      onChange={(e) => setContactPersonRole(e.target.value)}
                      placeholder="e.g. Medical Superintendent"
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-bold mb-1">Official Email</label>
                    <input
                      type="email"
                      value={contactPersonEmail}
                      onChange={(e) => setContactPersonEmail(e.target.value)}
                      placeholder="admin@hospital.org"
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm"
                    />
                  </div>
                </div>

                {/* Upload attachment simulation */}
                <div className="p-4 bg-slate-50 rounded-2xl border border-dashed border-slate-300 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="font-bold text-slate-800 block text-xs">Accreditation Document (PDF)</span>
                      <span className="text-[11px] text-slate-500 font-mono">{licenseDocumentName}</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      const sampleDocs = [
                        'clinical_establishment_license_2026.pdf',
                        'maternal_emergency_care_certification.pdf',
                        'state_health_board_valid_permit.pdf'
                      ];
                      const next = sampleDocs[(sampleDocs.indexOf(licenseDocumentName) + 1) % sampleDocs.length];
                      setLicenseDocumentName(next);
                    }}
                    className="px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 rounded-xl font-bold text-slate-700 text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <UploadCloud className="w-3.5 h-3.5 text-rose-600" />
                    <span>Change Proof File</span>
                  </button>
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-[11px] text-slate-500">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 inline mr-1" />
                  Credentials will be reviewed by Regional Triage Admin. Real-time updates occur immediately upon approval.
                </div>

                <button
                  type="submit"
                  className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-700 hover:to-pink-700 text-white font-extrabold text-sm rounded-xl shadow-lg shadow-rose-600/30 flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit Hospital Registration</span>
                </button>
              </div>

            </form>

          </div>

          {/* Right Info & Auto-Update Explainer (4 cols) */}
          <div className="lg:col-span-4 space-y-5">
            
            <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white p-6 rounded-3xl shadow-md space-y-4">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
                <Activity className="w-5 h-5" />
              </div>

              <h3 className="font-heading font-extrabold text-lg text-white">
                How Hospital Auto-Update Works
              </h3>

              <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
                <div className="flex gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">1</div>
                  <p><strong>Submit Credentials:</strong> Enter hospital name, license number, emergency numbers, and maternity beds.</p>
                </div>

                <div className="flex gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">2</div>
                  <p><strong>Clinical Admin Verification:</strong> The triage desk verifies your establishment license and emergency readiness.</p>
                </div>

                <div className="flex gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">3</div>
                  <p><strong>Automatic Finder Update:</strong> The moment your registration is approved, your facility instantly appears on the Hospital Finder map, directory cards, and referral targets!</p>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-700/60 flex items-center justify-between text-xs">
                <span className="text-slate-400">Want to test approval now?</span>
                <button
                  onClick={() => {
                    switchUserRole('admin');
                    setActiveTab('admin');
                  }}
                  className="text-rose-400 font-bold hover:underline flex items-center gap-1"
                >
                  <span>Switch to Admin</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Regulatory Compliance Notice */}
            <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200 text-xs text-amber-900 space-y-1.5">
              <div className="font-bold flex items-center gap-1.5 text-amber-900">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Regulatory Standards Requirement</span>
              </div>
              <p className="text-[11px] leading-relaxed text-amber-800">
                Facilities must hold an active Clinical Establishments Act license and have at least 1 certified midwife or obstetrician on 24-hour call to participate in emergency referral transfers.
              </p>
            </div>

          </div>

        </div>
      )}

      {/* SUB TAB 2: TRACK SUBMITTED REGISTRATIONS & VERIFICATION STATUS */}
      {activeSubTab === 'track' && (
        <div className="space-y-6">
          
          {submittedRegId && (
            <div className="bg-emerald-50 border border-emerald-200 rounded-3xl p-6 text-emerald-900 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-heading font-extrabold text-base text-emerald-950">
                    Registration Submitted Successfully! Reference ID: #{submittedRegId}
                  </h3>
                  <p className="text-xs text-emerald-800 mt-0.5">
                    Your facility credentials have been recorded. You can view the pending approval below or switch to the Admin Hub to verify and approve it immediately.
                  </p>
                </div>
              </div>

              <button
                onClick={() => {
                  switchUserRole('admin');
                  setActiveTab('admin');
                }}
                className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs shrink-0 self-start sm:self-auto cursor-pointer"
              >
                Open Admin Hub to Approve Now
              </button>
            </div>
          )}

          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h2 className="font-heading font-extrabold text-xl text-slate-900">
                  Registered Healthcare Facilities & Approval Status
                </h2>
                <p className="text-xs text-slate-500">
                  Track the lifecycle of hospital applications, license verification records, and live Hospital Finder publishing.
                </p>
              </div>

              <button
                onClick={() => setActiveSubTab('register')}
                className="bg-rose-50 text-rose-700 hover:bg-rose-100 font-bold text-xs px-3.5 py-2 rounded-xl transition cursor-pointer self-start sm:self-auto"
              >
                + Register Another Facility
              </button>
            </div>

            <div className="space-y-4">
              {hospitalRegistrations.map((reg) => (
                <div
                  key={reg.id}
                  className={`p-5 rounded-2xl border transition-all space-y-3 ${
                    reg.status === 'approved'
                      ? 'border-emerald-200 bg-emerald-50/20'
                      : reg.status === 'rejected'
                      ? 'border-red-200 bg-red-50/20'
                      : 'border-amber-200 bg-amber-50/20'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-heading font-extrabold text-base text-slate-900">
                          {reg.name}
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-bold">
                          Lic: {reg.licenseNumber}
                        </span>
                        <span className="text-[10px] font-bold uppercase bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">
                          {reg.type}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 mt-1 flex items-center gap-2 flex-wrap">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-slate-400" />
                          {reg.address} ({reg.district})
                        </span>
                        <span>• Submitted: {reg.submittedAt}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`px-3 py-1 rounded-full text-xs font-extrabold uppercase tracking-wide flex items-center gap-1.5 ${
                        reg.status === 'approved'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : reg.status === 'rejected'
                          ? 'bg-red-100 text-red-800 border border-red-300'
                          : 'bg-amber-100 text-amber-800 border border-amber-300 animate-pulse'
                      }`}>
                        {reg.status === 'approved' && <CheckCircle2 className="w-3.5 h-3.5" />}
                        {reg.status === 'rejected' && <AlertCircle className="w-3.5 h-3.5" />}
                        {reg.status === 'pending' && <Clock className="w-3.5 h-3.5" />}
                        <span>Status: {reg.status}</span>
                      </span>
                    </div>
                  </div>

                  {/* Badges & Beds info */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div className="p-2.5 rounded-xl bg-white border border-slate-200">
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">Maternity Beds</span>
                      <span className="font-extrabold text-slate-900 text-sm">{reg.availableMaternityBeds}</span>
                      <span className="text-slate-500 text-[11px]"> / {reg.totalMaternityBeds} available</span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-white border border-slate-200">
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">NICU Incubators</span>
                      <span className="font-extrabold text-slate-900 text-sm">{reg.availableNicuBeds}</span>
                      <span className="text-slate-500 text-[11px]"> ({reg.nicuLevel})</span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-white border border-slate-200">
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">C-Section 24/7</span>
                      <span className={`font-bold text-xs ${reg.emergencyCSection24x7 ? 'text-red-700' : 'text-slate-600'}`}>
                        {reg.emergencyCSection24x7 ? '✅ 24/7 Surgical OT' : 'Normal Delivery'}
                      </span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-white border border-slate-200">
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">Emergency ER Line</span>
                      <a href={`tel:${reg.emergencyPhone}`} className="text-rose-600 font-bold hover:underline">
                        {reg.emergencyPhone}
                      </a>
                    </div>
                  </div>

                  {/* Services list */}
                  <div className="flex flex-wrap gap-1 text-[11px]">
                    {reg.services.map((s, idx) => (
                      <span key={idx} className="bg-white border border-slate-200 px-2 py-0.5 rounded-md text-slate-700 font-medium">
                        {s}
                      </span>
                    ))}
                  </div>

                  {/* Verification / Rejection Notes */}
                  {reg.status === 'approved' && (
                    <div className="p-3 bg-emerald-100/60 rounded-xl border border-emerald-200 text-xs text-emerald-900 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                        <span>
                          <strong>Approved & Published:</strong> {reg.verificationNotes || 'License verified. Facility published to interactive map & directory.'}
                        </span>
                      </div>
                      <button
                        onClick={() => setActiveTab('hospitals')}
                        className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs px-3 py-1.5 rounded-lg flex items-center gap-1 shrink-0 self-start sm:self-auto cursor-pointer"
                      >
                        <Compass className="w-3.5 h-3.5" />
                        <span>View on Hospital Finder</span>
                      </button>
                    </div>
                  )}

                  {reg.status === 'rejected' && (
                    <div className="p-3 bg-red-100/60 rounded-xl border border-red-200 text-xs text-red-900 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-red-700 shrink-0" />
                      <span>
                        <strong>Rejection Reason:</strong> {reg.rejectionReason || 'Credentials could not be verified with the medical council.'}
                      </span>
                    </div>
                  )}

                  {reg.status === 'pending' && (
                    <div className="p-3 bg-amber-100/60 rounded-xl border border-amber-200 text-xs text-amber-900 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-amber-700 shrink-0" />
                        <span>
                          <strong>Under Review:</strong> Clinical establishment license verification in progress by the triage coordinator.
                        </span>
                      </div>
                      <button
                        onClick={() => {
                          switchUserRole('admin');
                          setActiveTab('admin');
                        }}
                        className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs px-3 py-1.5 rounded-lg flex items-center gap-1 shrink-0 self-start sm:self-auto cursor-pointer"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>Go to Admin Hub to Review</span>
                      </button>
                    </div>
                  )}

                </div>
              ))}
            </div>

          </div>

        </div>
      )}

    </div>
  );
};
