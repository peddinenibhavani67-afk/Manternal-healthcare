import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Ambulance, 
  Hospital as HospitalIcon, 
  Stethoscope, 
  Users, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Edit3, 
  PhoneCall, 
  Activity, 
  Save, 
  X,
  Filter,
  Check,
  RefreshCw,
  Plus,
  FileBarChart,
  BarChart3,
  MapPin,
  TrendingUp,
  Download,
  Building2,
  Trash2,
  ExternalLink,
  FileText,
  XCircle,
  AlertCircle,
  ShieldCheck
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { EmergencyRequest, EmergencyStatus, Hospital, Doctor, AmbulanceInfo, UserProfile, HospitalRegistration } from '../types';

export const AdminDashboard: React.FC = () => {
  const { 
    emergencyRequests, 
    updateEmergencyStatus, 
    hospitals, 
    updateHospitalBeds,
    updateHospitalDetails,
    doctors,
    setDoctors,
    updateDoctorAvailability,
    ambulanceFleet,
    updateAmbulanceStatus,
    registeredPatients,
    switchUserRole,
    hospitalRegistrations,
    approveHospitalRegistration,
    rejectHospitalRegistration,
    deleteHospital,
    editHospital
  } = useApp();

  // Active admin module tab
  const [adminSection, setAdminSection] = useState<
    'emergency_requests' | 'ambulance_tracking' | 'hospitals_beds' | 'hospital_approvals' | 'doctors' | 'patients' | 'reports'
  >('emergency_requests');

  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [regFilter, setRegFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');

  // Action toast banner
  const [actionBanner, setActionBanner] = useState<string | null>(null);

  // Hospital Verification & Rejection modals
  const [selectedVerifyReg, setSelectedVerifyReg] = useState<HospitalRegistration | null>(null);
  const [verifyNotesInput, setVerifyNotesInput] = useState<string>('');
  const [selectedRejectReg, setSelectedRejectReg] = useState<HospitalRegistration | null>(null);
  const [rejectReasonInput, setRejectReasonInput] = useState<string>('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Edit hospital state
  const [editingHospitalId, setEditingHospitalId] = useState<string | null>(null);
  const [editHospitalName, setEditHospitalName] = useState<string>('');
  const [editHospitalAddress, setEditHospitalAddress] = useState<string>('');
  const [editMaternityBeds, setEditMaternityBeds] = useState<number>(0);
  const [editNicuBeds, setEditNicuBeds] = useState<number>(0);
  const [editEmergencyPhone, setEditEmergencyPhone] = useState<string>('');
  const [editAmbulancePhone, setEditAmbulancePhone] = useState<string>('');
  const [editCSectionReady, setEditCSectionReady] = useState<boolean>(true);

  // Add doctor modal
  const [showAddDoctorModal, setShowAddDoctorModal] = useState(false);
  const [newDocName, setNewDocName] = useState('');
  const [newDocSpec, setNewDocSpec] = useState<Doctor['specialization']>('Obstetrician & Gynecologist');
  const [newDocHospital, setNewDocHospital] = useState(hospitals[0]?.name || 'District Mother & Child Specialty Hospital');
  const [newDocExp, setNewDocExp] = useState(10);
  const [newDocQual, setNewDocQual] = useState('MD (OBGYN), DGO');

  // Triage modal
  const [triageRequestId, setTriageRequestId] = useState<string | null>(null);
  const [triageNote, setTriageNote] = useState<string>('');
  const [triageHospitalId, setTriageHospitalId] = useState<string>('');

  // Patient search filter
  const [patientSearch, setPatientSearch] = useState('');

  // KPI Calculations
  const activeEmergencies = emergencyRequests.filter(
    r => r.status === 'submitted' || r.status === 'triaged' || r.status === 'ambulance_dispatched'
  );
  const totalMaternityBeds = hospitals.reduce((acc, h) => acc + h.totalMaternityBeds, 0);
  const totalAvailableBeds = hospitals.reduce((acc, h) => acc + h.availableMaternityBeds, 0);
  const totalAvailableNicu = hospitals.reduce((acc, h) => acc + h.availableNicuBeds, 0);
  const activeAmbulances = ambulanceFleet.filter(a => a.status === 'dispatched').length;

  const filteredRequests = emergencyRequests.filter(req => {
    if (statusFilter === 'all') return true;
    return req.status === statusFilter;
  });

  const filteredPatients = registeredPatients.filter(p => {
    if (!patientSearch.trim()) return true;
    const q = patientSearch.toLowerCase();
    return p.name.toLowerCase().includes(q) || p.phone.includes(q) || (p.highRiskFlags && p.highRiskFlags.some(f => f.toLowerCase().includes(q)));
  });

  const handleStartEditHospital = (hosp: Hospital) => {
    setEditingHospitalId(hosp.id);
    setEditHospitalName(hosp.name);
    setEditHospitalAddress(hosp.address);
    setEditMaternityBeds(hosp.availableMaternityBeds);
    setEditNicuBeds(hosp.availableNicuBeds);
    setEditEmergencyPhone(hosp.emergencyPhone);
    setEditAmbulancePhone(hosp.ambulancePhone);
    setEditCSectionReady(hosp.emergencyCSection24x7);
  };

  const handleSaveHospital = (id: string) => {
    editHospital(id, {
      name: editHospitalName.trim() || undefined,
      address: editHospitalAddress.trim() || undefined,
      availableMaternityBeds: Number(editMaternityBeds),
      availableNicuBeds: Number(editNicuBeds),
      emergencyPhone: editEmergencyPhone.trim(),
      ambulancePhone: editAmbulancePhone.trim(),
      emergencyCSection24x7: editCSectionReady,
      verifiedDate: 'Just updated'
    });
    setEditingHospitalId(null);
    setActionBanner('Hospital details updated successfully! Changes immediately live on Hospital Finder.');
    setTimeout(() => setActionBanner(null), 5000);
  };

  const handleDeleteHospitalConfirm = (id: string) => {
    deleteHospital(id);
    setDeleteConfirmId(null);
    setActionBanner('Hospital successfully removed from the platform and automatically removed from the Hospital Finder.');
    setTimeout(() => setActionBanner(null), 5000);
  };

  const handleApproveRegistration = (reg: HospitalRegistration) => {
    approveHospitalRegistration(reg.id, verifyNotesInput || 'Verified license and facility emergency readiness.');
    setSelectedVerifyReg(null);
    setVerifyNotesInput('');
    setActionBanner(`✅ "${reg.name}" has been approved! It has been automatically published to the Hospital Finder map, directory, and emergency referral network.`);
    setTimeout(() => setActionBanner(null), 6000);
  };

  const handleRejectRegistration = (reg: HospitalRegistration) => {
    if (!rejectReasonInput.trim()) return;
    rejectHospitalRegistration(reg.id, rejectReasonInput.trim());
    setSelectedRejectReg(null);
    setRejectReasonInput('');
    setActionBanner(`Registration for "${reg.name}" marked as rejected.`);
    setTimeout(() => setActionBanner(null), 5000);
  };

  const handleAddDoctorSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocName.trim()) return;

    const newDoc: Doctor = {
      id: `doc-${Date.now()}`,
      name: newDocName.trim(),
      title: 'Consultant Obstetrician',
      specialization: newDocSpec,
      hospitalId: hospitals[0]?.id || 'hosp-1',
      hospitalName: newDocHospital,
      experienceYears: Number(newDocExp),
      qualification: newDocQual,
      languages: ['English', 'Hindi'],
      rating: 4.9,
      reviewsCount: 1,
      availableNow: true,
      nextAvailableSlot: 'Available Now',
      consultationFee: 0,
      avatarUrl: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=400&q=80',
      bio: 'Verified healthcare provider onboarded to regional maternal telemedicine triage network.',
      supportedModes: ['video', 'in-person', 'emergency-call']
    };

    setDoctors(prev => [newDoc, ...prev]);
    setShowAddDoctorModal(false);
    setNewDocName('');
  };

  const handleOpenTriage = (req: EmergencyRequest) => {
    setTriageRequestId(req.id);
    setTriageNote(req.dispatcherNotes || '');
    setTriageHospitalId(req.assignedHospitalId || hospitals[0]?.id || '');
  };

  const handleSaveTriage = (id: string) => {
    const selectedHosp = hospitals.find(h => h.id === triageHospitalId);
    updateEmergencyStatus(id, 'ambulance_dispatched', {
      assignedHospitalId: triageHospitalId,
      assignedHospitalName: selectedHosp?.name,
      dispatcherNotes: triageNote.trim() || undefined,
      etaMinutes: 8
    });
    setTriageRequestId(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 text-white text-xs font-bold uppercase tracking-wider mb-1">
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
            <span>Emergency Operations Center & Admin Command</span>
          </div>
          <h1 className="font-heading text-3xl font-extrabold text-slate-900">
            Maternal Emergency Dispatch & Administration
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Monitor emergency requests, track ambulance fleets, manage hospital bed availability, supervise on-call doctors, and inspect audit reports.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => switchUserRole('patient')}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
          >
            Switch to Patient View
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold mb-2">
            <span>ACTIVE EMERGENCY REQUESTS</span>
            <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping"></span>
          </div>
          <div className="font-heading font-extrabold text-3xl text-red-600">
            {activeEmergencies.length}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {emergencyRequests.filter(r => r.status === 'submitted').length} awaiting triage review
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold mb-2">
            <span>AMBULANCE FLEET IN TRANSIT</span>
            <Ambulance className="w-4 h-4 text-rose-600" />
          </div>
          <div className="font-heading font-extrabold text-3xl text-slate-900">
            {activeAmbulances} <span className="text-sm font-medium text-slate-400">/ {ambulanceFleet.length} vehicles</span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {ambulanceFleet.filter(a => a.status === 'available').length} vehicles available on standby
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold mb-2">
            <span>AVAILABLE MATERNITY BEDS</span>
            <HospitalIcon className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="font-heading font-extrabold text-3xl text-emerald-700">
            {totalAvailableBeds} <span className="text-sm font-medium text-slate-400">/ {totalMaternityBeds} total</span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {totalAvailableNicu} NICU incubators open
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold mb-2">
            <span>ON-CALL OBSTETRICIANS</span>
            <Stethoscope className="w-4 h-4 text-sky-600" />
          </div>
          <div className="font-heading font-extrabold text-3xl text-slate-900">
            {doctors.filter(d => d.availableNow).length} <span className="text-sm font-medium text-slate-400">/ {doctors.length} On Duty</span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Ready for tele-consultation
          </p>
        </div>
      </div>

      {/* Main Admin Section Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setAdminSection('emergency_requests')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            adminSection === 'emergency_requests' ? 'bg-rose-600 text-white shadow-xs' : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
          }`}
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          <span>Monitor Emergency Requests ({emergencyRequests.length})</span>
        </button>

        <button
          onClick={() => setAdminSection('ambulance_tracking')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            adminSection === 'ambulance_tracking' ? 'bg-rose-600 text-white shadow-xs' : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
          }`}
        >
          <Ambulance className="w-3.5 h-3.5" />
          <span>Track Ambulance Services ({ambulanceFleet.length})</span>
        </button>

        <button
          onClick={() => setAdminSection('hospitals_beds')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            adminSection === 'hospitals_beds' ? 'bg-rose-600 text-white shadow-xs' : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
          }`}
        >
          <HospitalIcon className="w-3.5 h-3.5" />
          <span>Live Hospitals & Beds ({hospitals.length})</span>
        </button>

        <button
          onClick={() => setAdminSection('hospital_approvals')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            adminSection === 'hospital_approvals' ? 'bg-rose-600 text-white shadow-xs' : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Hospital Registrations & Auto-Update ({hospitalRegistrations.length})</span>
          {hospitalRegistrations.filter(r => r.status === 'pending').length > 0 && (
            <span className="bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded-full text-[10px] font-extrabold animate-pulse">
              {hospitalRegistrations.filter(r => r.status === 'pending').length} Pending
            </span>
          )}
        </button>

        <button
          onClick={() => setAdminSection('doctors')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            adminSection === 'doctors' ? 'bg-rose-600 text-white shadow-xs' : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
          }`}
        >
          <Stethoscope className="w-3.5 h-3.5" />
          <span>Manage Doctor Information ({doctors.length})</span>
        </button>

        <button
          onClick={() => setAdminSection('patients')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            adminSection === 'patients' ? 'bg-rose-600 text-white shadow-xs' : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Manage Patient Records ({registeredPatients.length})</span>
        </button>

        <button
          onClick={() => setAdminSection('reports')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            adminSection === 'reports' ? 'bg-rose-600 text-white shadow-xs' : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
          }`}
        >
          <FileBarChart className="w-3.5 h-3.5" />
          <span>View Emergency Reports</span>
        </button>
      </div>

      {/* Real-time Notification Banner */}
      {actionBanner && (
        <div className="bg-emerald-600 text-white px-5 py-3.5 rounded-2xl shadow-lg text-xs font-bold flex items-center justify-between gap-3 animate-fade-in border-2 border-emerald-400">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-200 shrink-0" />
            <span className="text-sm font-semibold">{actionBanner}</span>
          </div>
          <button 
            onClick={() => setActionBanner(null)} 
            className="p-1 text-emerald-200 hover:text-white rounded-lg hover:bg-emerald-700 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 1. MONITOR EMERGENCY REQUESTS */}
      {adminSection === 'emergency_requests' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="text-xs text-slate-500">Filter by Status:</div>
            <div className="flex flex-wrap gap-1.5 text-xs">
              {['all', 'submitted', 'triaged', 'ambulance_dispatched', 'reached_hospital', 'resolved'].map(status => (
                <button
                  key={status}
                  onClick={() => setStatusFilter(status)}
                  className={`px-3 py-1.5 rounded-lg font-semibold capitalize transition cursor-pointer ${
                    statusFilter === status ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {status.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            {filteredRequests.map((req) => (
              <div key={req.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <span className={`w-3 h-3 rounded-full ${
                      req.status === 'submitted' ? 'bg-amber-500 animate-ping' : req.status === 'ambulance_dispatched' ? 'bg-red-600 animate-pulse' : 'bg-emerald-500'
                    }`} />
                    <div>
                      <div className="font-heading font-extrabold text-base text-slate-900">
                        {req.patientName} • Gestation {req.gestationalWeek} Weeks
                      </div>
                      <div className="text-xs text-slate-500">
                        ID: <strong>#{req.id}</strong> • Phone: <a href={`tel:${req.patientPhone}`} className="text-rose-600 font-bold hover:underline">{req.patientPhone}</a> • Logged {req.timestamp}
                      </div>
                    </div>
                  </div>

                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wide ${
                    req.status === 'submitted' ? 'bg-amber-100 text-amber-800' : req.status === 'ambulance_dispatched' ? 'bg-red-100 text-red-800' : 'bg-emerald-100 text-emerald-800'
                  }`}>
                    {req.status.replace('_', ' ')}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                  <div>
                    <span className="text-slate-400 uppercase font-bold text-[10px]">Emergency Danger Sign</span>
                    <div className="font-bold text-red-700 mt-0.5">{req.emergencyType}</div>
                    <div className="text-slate-500 mt-1">Symptoms: {req.symptoms.join(', ')}</div>
                  </div>

                  <div>
                    <span className="text-slate-400 uppercase font-bold text-[10px]">Pickup Location & Landmark</span>
                    <div className="font-bold text-slate-800 mt-0.5">{req.location.address}</div>
                    {req.location.landmark && <div className="text-slate-500">Landmark: {req.location.landmark}</div>}
                  </div>

                  <div>
                    <span className="text-slate-400 uppercase font-bold text-[10px]">Assigned Transport & Hospital</span>
                    {req.assignedAmbulance ? (
                      <div className="mt-0.5 space-y-0.5">
                        <div className="font-bold text-slate-800">{req.assignedAmbulance.vehicleNo}</div>
                        <div className="text-slate-600">Driver: {req.assignedAmbulance.driverName} ({req.assignedAmbulance.driverPhone})</div>
                        <div className="text-red-600 font-extrabold">ETA: ~{req.assignedAmbulance.etaMinutes} mins</div>
                      </div>
                    ) : (
                      <div className="text-slate-400 mt-0.5">No ambulance assigned</div>
                    )}
                    <div className="text-emerald-700 font-semibold mt-1">Dest: {req.assignedHospitalName || 'Pending'}</div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="text-slate-500 italic text-[11px]">
                    Dispatcher Log: {req.dispatcherNotes || 'Standard obstetric triage.'}
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      onClick={() => handleOpenTriage(req)}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-lg transition"
                    >
                      Assign Hospital / Notes
                    </button>

                    {req.status !== 'ambulance_dispatched' && req.status !== 'reached_hospital' && req.status !== 'resolved' && (
                      <button
                        onClick={() => updateEmergencyStatus(req.id, 'ambulance_dispatched', { etaMinutes: 8 })}
                        className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg transition"
                      >
                        Dispatch Ambulance
                      </button>
                    )}

                    {req.status === 'ambulance_dispatched' && (
                      <button
                        onClick={() => updateEmergencyStatus(req.id, 'reached_hospital', { etaMinutes: 0 })}
                        className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-lg transition"
                      >
                        Mark Reached Hospital
                      </button>
                    )}

                    {req.status !== 'resolved' && (
                      <button
                        onClick={() => updateEmergencyStatus(req.id, 'resolved')}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg transition"
                      >
                        Mark Case Resolved
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. TRACK AMBULANCE SERVICES */}
      {adminSection === 'ambulance_tracking' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-heading font-extrabold text-xl text-slate-900">
                Ambulance Services & Rapid Response Fleet
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Live vehicle tracking, driver contact, active dispatch assignment, and operational status.
              </p>
            </div>
            <span className="text-xs bg-rose-50 text-rose-800 font-bold px-3 py-1.5 rounded-xl border border-rose-200">
              {ambulanceFleet.filter(a => a.status === 'available').length} Available for Immediate Dispatch
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {ambulanceFleet.map((amb) => (
              <div key={amb.id} className="p-5 rounded-2xl border border-slate-200 bg-white space-y-3 shadow-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Ambulance className="w-5 h-5 text-rose-600" />
                    <span className="font-bold text-slate-900 text-sm">{amb.vehicleNo}</span>
                  </div>
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                    amb.status === 'dispatched' ? 'bg-red-100 text-red-700 animate-pulse' : amb.status === 'available' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {amb.status}
                  </span>
                </div>

                <div className="text-xs space-y-1 text-slate-600">
                  <div>Type: <strong>{amb.type}</strong></div>
                  <div>Driver / Paramedic: <strong>{amb.driverName}</strong> (<a href={`tel:${amb.driverPhone}`} className="text-rose-600 underline font-semibold">{amb.driverPhone}</a>)</div>
                  <div>Current Station: <span className="text-slate-800 font-medium">{amb.currentLocationName}</span></div>
                  {amb.assignedRequestId && (
                    <div className="text-red-700 font-bold">Assigned to: #{amb.assignedRequestId} • ETA: ~{amb.etaMinutes} mins</div>
                  )}
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-400 text-[11px]">Toggle fleet status:</span>
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => updateAmbulanceStatus(amb.id, 'available')}
                      className={`px-2.5 py-1 rounded-lg font-bold text-[11px] ${amb.status === 'available' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'}`}
                    >
                      Available
                    </button>
                    <button
                      onClick={() => updateAmbulanceStatus(amb.id, 'dispatched')}
                      className={`px-2.5 py-1 rounded-lg font-bold text-[11px] ${amb.status === 'dispatched' ? 'bg-red-600 text-white' : 'bg-slate-100 text-slate-600'}`}
                    >
                      Dispatched
                    </button>
                    <button
                      onClick={() => updateAmbulanceStatus(amb.id, 'at_hospital')}
                      className={`px-2.5 py-1 rounded-lg font-bold text-[11px] ${amb.status === 'at_hospital' ? 'bg-sky-600 text-white' : 'bg-slate-100 text-slate-600'}`}
                    >
                      At Hospital
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. MANAGE HOSPITALS & MONITOR BED AVAILABILITY */}
      {adminSection === 'hospitals_beds' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-6">
          <div>
            <h3 className="font-heading font-extrabold text-xl text-slate-900">
              Manage Hospital Details & Monitor Bed Availability
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Update hospital emergency phone numbers, ambulance desks, available maternity beds, and 24/7 C-Section surgical theater readiness.
            </p>
          </div>

          <div className="divide-y divide-slate-100">
            {hospitals.map((hosp) => {
              const isEditing = editingHospitalId === hosp.id;
              return (
                <div key={hosp.id} className="py-4 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-heading font-bold text-base text-slate-900">{hosp.name}</h4>
                        <span className="text-[10px] font-bold uppercase bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full">
                          {hosp.type}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">{hosp.address} • {hosp.district}</p>
                    </div>

                    {!isEditing ? (
                      <div className="flex items-center gap-2 self-start sm:self-auto">
                        <button
                          onClick={() => handleStartEditHospital(hosp)}
                          className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Edit Details & Beds</span>
                        </button>
                        <button
                          onClick={() => setDeleteConfirmId(hosp.id)}
                          className="px-2.5 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer"
                          title="Delete facility and auto-remove from Hospital Finder"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">Delete</span>
                        </button>
                      </div>
                    ) : (
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleSaveHospital(hosp.id)}
                          className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer"
                        >
                          <Save className="w-3.5 h-3.5" />
                          <span>Save & Publish</span>
                        </button>
                        <button
                          onClick={() => setEditingHospitalId(null)}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs rounded-xl cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    )}
                  </div>

                  {isEditing ? (
                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3 text-xs">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-slate-700 font-bold mb-1">Hospital Name</label>
                          <input
                            type="text"
                            value={editHospitalName}
                            onChange={(e) => setEditHospitalName(e.target.value)}
                            className="w-full px-3 py-1.5 border rounded-lg bg-white"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-700 font-bold mb-1">Address & District</label>
                          <input
                            type="text"
                            value={editHospitalAddress}
                            onChange={(e) => setEditHospitalAddress(e.target.value)}
                            className="w-full px-3 py-1.5 border rounded-lg bg-white"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                        <div>
                          <label className="block text-slate-700 font-bold mb-1">Available Maternity Beds</label>
                          <input
                            type="number"
                            min="0"
                            max={hosp.totalMaternityBeds}
                            value={editMaternityBeds}
                            onChange={(e) => setEditMaternityBeds(Number(editMaternityBeds) || 0)}
                            className="w-full px-3 py-1.5 border rounded-lg bg-white"
                          />
                        </div>

                        <div>
                          <label className="block text-slate-700 font-bold mb-1">Available NICU Beds</label>
                          <input
                            type="number"
                            min="0"
                            max="30"
                            value={editNicuBeds}
                            onChange={(e) => setEditNicuBeds(Number(e.target.value))}
                            className="w-full px-3 py-1.5 border rounded-lg bg-white"
                          />
                        </div>

                        <div>
                          <label className="block text-slate-700 font-bold mb-1">Direct ER Phone</label>
                          <input
                            type="tel"
                            value={editEmergencyPhone}
                            onChange={(e) => setEditEmergencyPhone(e.target.value)}
                            className="w-full px-3 py-1.5 border rounded-lg bg-white"
                          />
                        </div>

                        <div>
                          <label className="block text-slate-700 font-bold mb-1">24/7 C-Section Ready</label>
                          <select
                            value={editCSectionReady ? 'yes' : 'no'}
                            onChange={(e) => setEditCSectionReady(e.target.value === 'yes')}
                            className="w-full px-3 py-1.5 border rounded-lg bg-white"
                          >
                            <option value="yes">Yes (Staffed OT 24/7)</option>
                            <option value="no">No (Normal Delivery Only)</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs text-slate-600">
                      <div className="border border-slate-100 p-2.5 rounded-xl bg-slate-50/50">
                        <span className="text-slate-400 text-[10px] uppercase font-bold block">Available Maternity Beds</span>
                        <span className="font-extrabold text-emerald-700 text-sm">{hosp.availableMaternityBeds}</span>
                        <span className="text-slate-400 text-[11px]"> / {hosp.totalMaternityBeds} beds</span>
                      </div>

                      <div className="border border-slate-100 p-2.5 rounded-xl bg-slate-50/50">
                        <span className="text-slate-400 text-[10px] uppercase font-bold block">NICU Incubators</span>
                        <span className="font-extrabold text-sky-700 text-sm">{hosp.availableNicuBeds}</span>
                        <span className="text-slate-400 text-[11px]"> beds ({hosp.nicuLevel})</span>
                      </div>

                      <div className="border border-slate-100 p-2.5 rounded-xl bg-slate-50/50">
                        <span className="text-slate-400 text-[10px] uppercase font-bold block">C-Section Readiness</span>
                        <span className={`font-bold text-xs ${hosp.emergencyCSection24x7 ? 'text-red-700' : 'text-slate-600'}`}>
                          {hosp.emergencyCSection24x7 ? '✅ 24/7 Surgical OT' : 'Normal Delivery'}
                        </span>
                      </div>

                      <div className="border border-slate-100 p-2.5 rounded-xl bg-slate-50/50">
                        <span className="text-slate-400 text-[10px] uppercase font-bold block">Emergency ER Line</span>
                        <a href={`tel:${hosp.emergencyPhone}`} className="font-bold text-rose-600 hover:underline">
                          {hosp.emergencyPhone}
                        </a>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 3B. HOSPITAL REGISTRATIONS & AUTO-UPDATE (VERIFY, APPROVE/REJECT, EDIT/DELETE) */}
      {adminSection === 'hospital_approvals' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-bold uppercase tracking-wider mb-1">
                <Building2 className="w-3.5 h-3.5" />
                <span>Hospital Credential Verification & Auto-Publisher</span>
              </div>
              <h3 className="font-heading font-extrabold text-xl text-slate-900">
                Hospital Registrations & Auto-Update Engine
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Review submitted hospital registrations, inspect clinical establishment licenses, approve or reject facilities, and automatically update the live Hospital Finder.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs font-bold flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-600" />
                <span>{hospitalRegistrations.filter(r => r.status === 'pending').length} Awaiting Verification</span>
              </span>
            </div>
          </div>

          {/* Quick Filter Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-600">
              <span>Filter Registrations:</span>
              {(['all', 'pending', 'approved', 'rejected'] as const).map((status) => (
                <button
                  key={status}
                  onClick={() => setRegFilter(status)}
                  className={`px-3 py-1.5 rounded-xl capitalize transition cursor-pointer ${
                    regFilter === status
                      ? 'bg-slate-900 text-white font-extrabold shadow-xs'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  {status} ({hospitalRegistrations.filter(r => status === 'all' || r.status === status).length})
                </button>
              ))}
            </div>

            <div className="text-[11px] text-slate-400">
              * Approving or deleting instantly updates the Hospital Finder map, directory cards, and referral targets.
            </div>
          </div>

          {/* Registrations List */}
          <div className="space-y-4">
            {hospitalRegistrations
              .filter(r => regFilter === 'all' || r.status === regFilter)
              .map((reg) => (
                <div
                  key={reg.id}
                  className={`p-5 rounded-2xl border transition-all space-y-4 ${
                    reg.status === 'approved'
                      ? 'border-emerald-200 bg-emerald-50/20'
                      : reg.status === 'rejected'
                      ? 'border-red-200 bg-red-50/20'
                      : 'border-amber-200 bg-amber-50/30'
                  }`}
                >
                  {/* Top line: Name, License, District, Status */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-heading font-extrabold text-base text-slate-900">
                          {reg.name}
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-900 text-white font-bold">
                          Lic: {reg.licenseNumber}
                        </span>
                        <span className="text-[10px] font-bold uppercase bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full">
                          {reg.type}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{reg.address} • {reg.district} • Submitted {reg.submittedAt}</span>
                      </p>
                    </div>

                    <span className={`px-3 py-1 rounded-full text-xs font-extrabold uppercase tracking-wide flex items-center gap-1.5 self-start sm:self-auto ${
                      reg.status === 'approved'
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : reg.status === 'rejected'
                        ? 'bg-red-100 text-red-800 border border-red-300'
                        : 'bg-amber-100 text-amber-800 border border-amber-300 animate-pulse'
                    }`}>
                      {reg.status === 'approved' && <CheckCircle2 className="w-3.5 h-3.5" />}
                      {reg.status === 'rejected' && <AlertCircle className="w-3.5 h-3.5" />}
                      {reg.status === 'pending' && <Clock className="w-3.5 h-3.5" />}
                      <span>{reg.status}</span>
                    </span>
                  </div>

                  {/* 4 Details Columns */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                    
                    {/* Contacts */}
                    <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1">
                      <span className="text-slate-400 font-bold uppercase text-[10px] block">Contact Numbers</span>
                      <div>Gen: <a href={`tel:${reg.phone}`} className="font-bold text-slate-800 hover:underline">{reg.phone}</a></div>
                      <div>ER 24/7: <a href={`tel:${reg.emergencyPhone}`} className="font-bold text-rose-600 hover:underline">{reg.emergencyPhone}</a></div>
                      <div>Amb: <span className="font-semibold text-slate-700">{reg.ambulancePhone}</span></div>
                    </div>

                    {/* Beds */}
                    <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1">
                      <span className="text-slate-400 font-bold uppercase text-[10px] block">Maternity & NICU Beds</span>
                      <div>Maternity: <strong className="text-emerald-700">{reg.availableMaternityBeds}</strong> / {reg.totalMaternityBeds} available</div>
                      <div>NICU: <strong className="text-sky-700">{reg.availableNicuBeds}</strong> beds ({reg.nicuLevel})</div>
                      <div className="text-[11px] text-slate-500">C-Section: {reg.emergencyCSection24x7 ? '✅ 24/7 OT' : 'Normal Delivery'}</div>
                    </div>

                    {/* Attached License Document */}
                    <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1.5">
                      <span className="text-slate-400 font-bold uppercase text-[10px] block">License Proof Attached</span>
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-rose-600 shrink-0" />
                        <span className="font-mono text-[11px] truncate text-slate-800">{reg.licenseDocumentName || 'license_document.pdf'}</span>
                      </div>
                      <div className="text-[10px] text-emerald-700 font-semibold">
                        ✓ Digital signature valid
                      </div>
                    </div>

                    {/* Authorizing Contact Person */}
                    <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1">
                      <span className="text-slate-400 font-bold uppercase text-[10px] block">Authorized Representative</span>
                      <div className="font-bold text-slate-800">{reg.contactPersonName || 'Medical Director'}</div>
                      <div className="text-slate-500 text-[11px]">{reg.contactPersonRole || 'Superintendent'}</div>
                      <div className="text-slate-500 text-[11px] truncate">{reg.contactPersonEmail || 'contact@hospital.org'}</div>
                    </div>

                  </div>

                  {/* Services pills */}
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold uppercase text-slate-400">Declared Maternity Services:</span>
                    <div className="flex flex-wrap gap-1 text-[11px]">
                      {reg.services.map((srv, i) => (
                        <span key={i} className="bg-white border border-slate-200 text-slate-700 px-2 py-0.5 rounded-md font-medium">
                          {srv}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Status Banner & Action Buttons */}
                  <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    
                    <div>
                      {reg.status === 'pending' && (
                        <span className="text-xs text-amber-800 font-medium">
                          Pending admin review. Verify license to automatically push into Hospital Finder.
                        </span>
                      )}
                      {reg.status === 'approved' && (
                        <span className="text-xs text-emerald-800 font-bold flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          <span>Live on Hospital Finder. {reg.verificationNotes || 'License verified.'}</span>
                        </span>
                      )}
                      {reg.status === 'rejected' && (
                        <span className="text-xs text-red-800 font-medium">
                          Rejected: <strong>{reg.rejectionReason}</strong>
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 flex-wrap">
                      {reg.status === 'pending' && (
                        <>
                          <button
                            onClick={() => {
                              setSelectedVerifyReg(reg);
                              setVerifyNotesInput(`Verified establishment license ${reg.licenseNumber}. 24/7 C-Section and beds approved.`);
                            }}
                            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer"
                          >
                            <ShieldCheck className="w-4 h-4" />
                            <span>Verify & Approve Hospital</span>
                          </button>

                          <button
                            onClick={() => {
                              setSelectedRejectReg(reg);
                              setRejectReasonInput('Clinical establishment license expired or could not be verified with state registry.');
                            }}
                            className="px-3.5 py-2 bg-red-100 hover:bg-red-200 text-red-800 font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>
                        </>
                      )}

                      {reg.status === 'approved' && (
                        <>
                          <button
                            onClick={() => {
                              const matchingHosp = hospitals.find(h => h.id === `hosp-${reg.id}` || h.licenseNumber === reg.licenseNumber);
                              if (matchingHosp) {
                                handleStartEditHospital(matchingHosp);
                                setAdminSection('hospitals_beds');
                              } else {
                                handleApproveRegistration(reg);
                              }
                            }}
                            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Edit Hospital</span>
                          </button>

                          <button
                            onClick={() => {
                              const matchingHosp = hospitals.find(h => h.id === `hosp-${reg.id}` || h.licenseNumber === reg.licenseNumber);
                              if (matchingHosp) {
                                setDeleteConfirmId(matchingHosp.id);
                              }
                            }}
                            className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Delete from Finder</span>
                          </button>
                        </>
                      )}

                      {reg.status === 'rejected' && (
                        <button
                          onClick={() => {
                            setSelectedVerifyReg(reg);
                            setVerifyNotesInput('Re-verified after appeal. Credentials now valid.');
                          }}
                          className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl cursor-pointer"
                        >
                          Re-examine & Approve
                        </button>
                      )}
                    </div>

                  </div>

                </div>
              ))}
          </div>
        </div>
      )}

      {/* 4. MANAGE DOCTOR INFORMATION */}
      {adminSection === 'doctors' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-heading font-extrabold text-xl text-slate-900">
                Manage Doctor Information & On-Call Availability
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Toggle doctor availability for instant tele-triage consultations and update clinical credentials.
              </p>
            </div>

            <button
              onClick={() => setShowAddDoctorModal(true)}
              className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Doctor</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {doctors.map((doc) => (
              <div key={doc.id} className="p-4 rounded-2xl border border-slate-200 flex items-start gap-3 bg-white">
                <img src={doc.avatarUrl} alt={doc.name} className="w-14 h-14 rounded-xl object-cover" />
                <div className="flex-1 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-slate-900 text-sm">{doc.name}</h4>
                    <button
                      onClick={() => updateDoctorAvailability(doc.id, !doc.availableNow)}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase transition ${
                        doc.availableNow ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {doc.availableNow ? '● On Call' : '○ Off Duty'}
                    </button>
                  </div>
                  <div className="text-rose-600 font-semibold">{doc.specialization}</div>
                  <div className="text-slate-500">{doc.hospitalName}</div>
                  <div className="text-slate-400 text-[11px]">{doc.qualification} • {doc.experienceYears}+ Yrs Exp</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. MANAGE PATIENT RECORDS */}
      {adminSection === 'patients' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-heading font-extrabold text-xl text-slate-900">
                Registered Patient Care Records
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Registry of registered expectant mothers, current gestational age, blood group, and high-risk flags.
              </p>
            </div>

            <input
              type="text"
              value={patientSearch}
              onChange={(e) => setPatientSearch(e.target.value)}
              placeholder="Search patients by name, phone, or high risk..."
              className="px-3.5 py-2 border border-slate-300 rounded-xl text-xs w-full sm:w-64"
            />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-200 rounded-2xl overflow-hidden">
              <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="p-3.5">Patient Name</th>
                  <th className="p-3.5">Contact Phone</th>
                  <th className="p-3.5">Gestation / EDD</th>
                  <th className="p-3.5">Blood Group</th>
                  <th className="p-3.5">High-Risk Pregnancy Alerts</th>
                  <th className="p-3.5">Emergency Contact</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-600">
                {filteredPatients.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50 transition">
                    <td className="p-3.5 font-bold text-slate-900">{p.name}</td>
                    <td className="p-3.5 text-rose-600 font-semibold">{p.phone}</td>
                    <td className="p-3.5">Week {p.gestationalWeek || 30} • {p.expectedDueDate}</td>
                    <td className="p-3.5 font-bold">{p.bloodGroup}</td>
                    <td className="p-3.5">
                      {p.highRiskFlags?.map((f, i) => (
                        <span key={i} className="inline-block bg-red-50 text-red-700 border border-red-200 px-1.5 py-0.5 rounded text-[10px] font-bold mr-1 mb-0.5">
                          {f}
                        </span>
                      ))}
                    </td>
                    <td className="p-3.5">{p.emergencyContactName} ({p.emergencyContactPhone})</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 6. VIEW EMERGENCY REPORTS */}
      {adminSection === 'reports' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-heading font-extrabold text-2xl text-slate-900">
                  Regional Maternal Emergency Reports & Analytics
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Incident metrics, emergency triage dispatch times, rural vs urban coverage, and resolution audit.
                </p>
              </div>

              <button
                onClick={() => alert('Exporting full Maternal Incident Audit Report (CSV/PDF)...')}
                className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs flex items-center gap-2 self-start sm:self-auto cursor-pointer"
              >
                <Download className="w-4 h-4 text-rose-400" />
                <span>Export Audit Report</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
              <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50 space-y-2">
                <span className="text-slate-400 uppercase font-bold text-[10px]">Average Ambulance Dispatch Time</span>
                <div className="font-heading font-extrabold text-3xl text-slate-900">11.4 Mins</div>
                <p className="text-slate-500 leading-relaxed">
                  Target is &lt; 15 minutes in rural corridors. 94.2% of calls reached within target window.
                </p>
              </div>

              <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50 space-y-2">
                <span className="text-slate-400 uppercase font-bold text-[10px]">Most Prevalent Emergency Symptoms</span>
                <div className="font-heading font-extrabold text-xl text-rose-600">Obstetric Hemorrhage & Preeclampsia</div>
                <p className="text-slate-500 leading-relaxed">
                  Accounts for 62% of high-severity SOS alerts. Prompt Mag Sulfate & Blood matching initiated.
                </p>
              </div>

              <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50 space-y-2">
                <span className="text-slate-400 uppercase font-bold text-[10px]">Case Resolution Rate</span>
                <div className="font-heading font-extrabold text-3xl text-emerald-700">99.1%</div>
                <p className="text-slate-500 leading-relaxed">
                  Zero delays due to unavailable beds through real-time inter-hospital referral reservations.
                </p>
              </div>
            </div>

            {/* Audit Log Table */}
            <div className="space-y-3 pt-4 border-t border-slate-100">
              <h4 className="font-heading font-bold text-base text-slate-900">
                Recent Incident Audit Log
              </h4>
              <div className="divide-y divide-slate-100 text-xs">
                {emergencyRequests.map((req) => (
                  <div key={req.id} className="py-2.5 flex items-center justify-between text-slate-600">
                    <div>
                      <span className="font-bold text-slate-900">Incident #{req.id}</span> • {req.patientName} ({req.emergencyType})
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-slate-400">{req.timestamp}</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-100 text-slate-700">
                        {req.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Triage / Hospital Assignment Modal */}
      {triageRequestId && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 space-y-4">
            <h3 className="font-heading font-extrabold text-xl text-slate-900">
              Clinical Triage & Facility Referral
            </h3>
            <div className="text-xs text-slate-500">
              Assign target hospital and communicate with the receiving obstetric trauma team.
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-bold mb-1">Select Target Receiving Hospital</label>
                <select
                  value={triageHospitalId}
                  onChange={(e) => setTriageHospitalId(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white"
                >
                  {hospitals.map(h => (
                    <option key={h.id} value={h.id}>
                      {h.name} ({h.availableMaternityBeds} beds available, {h.emergencyCSection24x7 ? '24/7 C-Section' : 'Normal'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Dispatcher Clinical Notes / Handover Instructions</label>
                <textarea
                  rows={3}
                  value={triageNote}
                  onChange={(e) => setTriageNote(e.target.value)}
                  placeholder="e.g. 34 weeks gestation with severe headache. Preeclampsia protocol initiated. Bed reserved in Labor Ward Room 2."
                  className="w-full px-3 py-2 border rounded-xl resize-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setTriageRequestId(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => handleSaveTriage(triageRequestId)}
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow-xs"
                >
                  Confirm & Dispatch
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Doctor Modal */}
      {showAddDoctorModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 space-y-4">
            <h3 className="font-heading font-extrabold text-xl text-slate-900">
              Add Verified Doctor / Healthcare Professional
            </h3>
            <form onSubmit={handleAddDoctorSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-bold mb-1">Doctor Name *</label>
                <input
                  type="text"
                  required
                  value={newDocName}
                  onChange={(e) => setNewDocName(e.target.value)}
                  placeholder="e.g. Dr. Priya Sengupta"
                  className="w-full px-3 py-2 border rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Specialization *</label>
                  <select
                    value={newDocSpec}
                    onChange={(e) => setNewDocSpec(e.target.value as any)}
                    className="w-full px-3 py-2 border rounded-xl bg-white"
                  >
                    <option value="Obstetrician & Gynecologist">Obstetrician & Gynecologist</option>
                    <option value="Maternal-Fetal Medicine (High Risk)">Maternal-Fetal Medicine (High Risk)</option>
                    <option value="Certified Nurse Midwife">Certified Nurse Midwife</option>
                    <option value="Lactation & Postnatal Consultant">Lactation & Postnatal Consultant</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Affiliated Hospital</label>
                  <select
                    value={newDocHospital}
                    onChange={(e) => setNewDocHospital(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl bg-white"
                  >
                    {hospitals.map(h => (
                      <option key={h.id} value={h.name}>{h.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Experience (Years)</label>
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={newDocExp}
                    onChange={(e) => setNewDocExp(Number(e.target.value))}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Medical Qualifications</label>
                  <input
                    type="text"
                    value={newDocQual}
                    onChange={(e) => setNewDocQual(e.target.value)}
                    placeholder="MD (OBGYN), MRCOG"
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddDoctorModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow-xs"
                >
                  Save & Onboard Doctor
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Verify & Approve Hospital Modal */}
      {selectedVerifyReg && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-heading font-extrabold text-xl text-slate-900">
                  Verify Hospital Credentials & Approve
                </h3>
                <p className="text-xs text-slate-500">
                  Validating license against state medical registry. Approving will publish the facility to Hospital Finder.
                </p>
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Hospital:</span>
                <strong className="text-slate-900">{selectedVerifyReg.name}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">License Number:</span>
                <span className="font-mono font-bold text-slate-800">{selectedVerifyReg.licenseNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Classification:</span>
                <span className="font-semibold">{selectedVerifyReg.type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Address:</span>
                <span className="text-right text-slate-700 max-w-[240px] truncate">{selectedVerifyReg.address}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Maternity Beds:</span>
                <span>{selectedVerifyReg.availableMaternityBeds} available / {selectedVerifyReg.totalMaternityBeds} total</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">NICU Capacity:</span>
                <span>{selectedVerifyReg.availableNicuBeds} beds ({selectedVerifyReg.nicuLevel})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">24/7 C-Section OT:</span>
                <span className="font-bold text-emerald-700">{selectedVerifyReg.emergencyCSection24x7 ? 'Yes (Verified)' : 'No'}</span>
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1 text-xs">
                Clinical Auditor Verification Notes / Approval Certificate
              </label>
              <textarea
                rows={3}
                value={verifyNotesInput}
                onChange={(e) => setVerifyNotesInput(e.target.value)}
                placeholder="e.g. License verified against state register. 24/7 OT and blood component support confirmed."
                className="w-full px-3 py-2 border rounded-xl text-xs resize-none"
              />
            </div>

            <div className="pt-2 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setSelectedVerifyReg(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleApproveRegistration(selectedVerifyReg)}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Approve & Publish to Hospital Finder</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject Modal */}
      {selectedRejectReg && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-red-100 text-red-700 flex items-center justify-center shrink-0">
                <XCircle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-heading font-extrabold text-xl text-slate-900">
                  Reject Hospital Application
                </h3>
                <p className="text-xs text-slate-500">
                  Please provide a clinical or regulatory justification for denying facility onboarding.
                </p>
              </div>
            </div>

            <div className="text-xs text-slate-700 font-semibold">
              Hospital: <strong className="text-slate-900">{selectedRejectReg.name}</strong> ({selectedRejectReg.licenseNumber})
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1 text-xs">
                Official Rejection Reason *
              </label>
              <textarea
                rows={3}
                required
                value={rejectReasonInput}
                onChange={(e) => setRejectReasonInput(e.target.value)}
                placeholder="e.g. Clinical Establishment Act license expired. Missing mandatory newborn resuscitation equipment."
                className="w-full px-3 py-2 border rounded-xl text-xs resize-none"
              />
            </div>

            <div className="pt-2 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setSelectedRejectReg(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleRejectRegistration(selectedRejectReg)}
                className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-xs"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-red-100 text-red-700 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-heading font-extrabold text-lg text-slate-900">
                  Delete Facility from Platform?
                </h3>
                <p className="text-xs text-slate-500">
                  This will immediately remove the hospital from the Hospital Finder interactive map, bed directory, and referral options.
                </p>
              </div>
            </div>

            <div className="pt-2 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleDeleteHospitalConfirm(deleteConfirmId)}
                className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white font-extrabold rounded-xl shadow-xs"
              >
                Confirm & Remove Facility
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
