import React, { useState } from 'react';
import { 
  User, 
  Heart, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  Ambulance, 
  Plus, 
  Edit3, 
  PhoneCall, 
  Video, 
  ShieldCheck, 
  Sparkles,
  MapPin,
  Baby,
  Activity,
  FileText,
  History,
  Download,
  Eye,
  Pill,
  Timer
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { HealthReminder, UserProfile, MedicalRecord, VitalCheckLog } from '../types';

export const UserDashboard: React.FC = () => {
  const { 
    currentUser, 
    updateUserProfile, 
    appointments, 
    cancelAppointment, 
    emergencyRequests, 
    reminders, 
    toggleReminder, 
    addReminder,
    openSosModal,
    medicalRecords,
    addMedicalRecord,
    vitalLogs,
    addVitalLog
  } = useApp();

  // Active dashboard view tab
  const [activeDashTab, setActiveDashTab] = useState<'overview' | 'appointments' | 'records' | 'vitals' | 'emergency'>('overview');

  // Edit profile state
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editName, setEditName] = useState(currentUser.name);
  const [editPhone, setEditPhone] = useState(currentUser.phone);
  const [editWeek, setEditWeek] = useState(currentUser.gestationalWeek || 31);
  const [editBloodGroup, setEditBloodGroup] = useState(currentUser.bloodGroup || 'B Positive (B+)');
  const [editContactName, setEditContactName] = useState(currentUser.emergencyContactName || '');
  const [editContactPhone, setEditContactPhone] = useState(currentUser.emergencyContactPhone || '');
  const [editAddress, setEditAddress] = useState(currentUser.address || '');
  const [editGravidaPara, setEditGravidaPara] = useState(currentUser.gravidaPara || 'G2P1');
  const [editEdd, setEditEdd] = useState(currentUser.expectedDueDate || '2027-01-08');

  // New Vital Check state
  const [showLogVitalModal, setShowLogVitalModal] = useState(false);
  const [vitalSystolic, setVitalSystolic] = useState(120);
  const [vitalDiastolic, setVitalDiastolic] = useState(78);
  const [vitalKickCount, setVitalKickCount] = useState(10);
  const [vitalWeight, setVitalWeight] = useState(64.5);
  const [vitalSugar, setVitalSugar] = useState(95);
  const [vitalNotes, setVitalNotes] = useState('');

  // Selected Medical Record for modal view
  const [viewingRecord, setViewingRecord] = useState<MedicalRecord | null>(null);

  // New Medical Record upload modal
  const [showUploadRecordModal, setShowUploadRecordModal] = useState(false);
  const [newRecTitle, setNewRecTitle] = useState('');
  const [newRecCategory, setNewRecCategory] = useState<MedicalRecord['category']>('ultrasound');
  const [newRecDate, setNewRecDate] = useState('2026-11-06');
  const [newRecFacility, setNewRecFacility] = useState('District Mother & Child Specialty Hospital');
  const [newRecDoctor, setNewRecDoctor] = useState('Dr. Sunita Deshmukh');
  const [newRecSummary, setNewRecSummary] = useState('');

  // Active video call simulator
  const [activeCallRoom, setActiveCallRoom] = useState<string | null>(null);

  // Fetal kick quick counter
  const [currentSessionKicks, setCurrentSessionKicks] = useState(12);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({
      name: editName,
      phone: editPhone,
      gestationalWeek: Number(editWeek),
      bloodGroup: editBloodGroup,
      emergencyContactName: editContactName,
      emergencyContactPhone: editContactPhone,
      address: editAddress,
      gravidaPara: editGravidaPara,
      expectedDueDate: editEdd
    });
    setIsEditingProfile(false);
  };

  const handleSaveVital = (e: React.FormEvent) => {
    e.preventDefault();
    addVitalLog({
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      gestationalWeek: currentUser.gestationalWeek || 31,
      bloodPressureSystolic: Number(vitalSystolic),
      bloodPressureDiastolic: Number(vitalDiastolic),
      fetalKickCount: Number(vitalKickCount),
      weightKg: Number(vitalWeight),
      bloodSugarMgDl: vitalSugar ? Number(vitalSugar) : undefined,
      notes: vitalNotes.trim() || undefined
    });
    setShowLogVitalModal(false);
    setVitalNotes('');
  };

  const handleCreateMedicalRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRecTitle.trim()) return;

    addMedicalRecord({
      patientId: currentUser.id,
      title: newRecTitle.trim(),
      category: newRecCategory,
      date: newRecDate,
      facility: newRecFacility,
      doctor: newRecDoctor,
      summary: newRecSummary.trim() || 'Verified diagnostic report uploaded by patient/clinic.',
      keyValues: {
        'Status': 'Verified Valid',
        'Uploaded On': new Date().toLocaleDateString()
      }
    });

    setShowUploadRecordModal(false);
    setNewRecTitle('');
    setNewRecSummary('');
  };

  // Filter emergency requests for current patient
  const userEmergencyHistory = emergencyRequests.filter(
    r => r.patientName.toLowerCase().includes(currentUser.name.toLowerCase().split(' ')[0]) || r.patientPhone === currentUser.phone
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Banner & Quick Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-bold uppercase tracking-wider mb-1">
            <User className="w-3.5 h-3.5" />
            <span>Maternal Patient Passport & Records</span>
          </div>
          <h1 className="font-heading text-3xl font-extrabold text-slate-900">
            Welcome, {currentUser.name}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Week {currentUser.gestationalWeek || 31} of Pregnancy • Expected Due Date: {currentUser.expectedDueDate || '2027-01-08'} • {currentUser.gravidaPara || 'G2P1'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setIsEditingProfile(true)}
            className="px-4 py-2 border border-slate-300 hover:border-slate-400 bg-white text-slate-700 font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition cursor-pointer"
          >
            <Edit3 className="w-3.5 h-3.5 text-slate-500" />
            <span>Edit Profile</span>
          </button>

          <button
            onClick={() => setShowLogVitalModal(true)}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition cursor-pointer"
          >
            <Activity className="w-3.5 h-3.5 text-rose-400" />
            <span>Log Health Vitals</span>
          </button>

          <button
            onClick={openSosModal}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs rounded-xl shadow-md flex items-center gap-1.5 transition cursor-pointer animate-emergency"
          >
            <Ambulance className="w-3.5 h-3.5" />
            <span>Emergency SOS</span>
          </button>
        </div>
      </div>

      {/* Maternal Passport Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-rose-500 to-pink-600 text-white p-5 rounded-2xl shadow-sm">
          <div className="flex items-center justify-between text-xs text-rose-100 font-semibold mb-2">
            <span>Pregnancy Details</span>
            <Baby className="w-4 h-4" />
          </div>
          <div className="font-heading font-extrabold text-3xl">
            Week {currentUser.gestationalWeek || 31}
          </div>
          <p className="text-xs text-rose-100 mt-1">
            EDD: <strong>{currentUser.expectedDueDate || '2027-01-08'}</strong> • 3rd Trimester
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold mb-2">
            <span>Blood Group & Vitals</span>
            <Activity className="w-4 h-4 text-rose-600" />
          </div>
          <div className="font-heading font-extrabold text-2xl text-slate-900">
            {currentUser.bloodGroup || 'B+'}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Last BP: <strong>{vitalLogs[0]?.bloodPressureSystolic || 118}/{vitalLogs[0]?.bloodPressureDiastolic || 76} mmHg</strong> (Normal)
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold mb-2">
            <span>Primary Emergency Contact</span>
            <PhoneCall className="w-4 h-4 text-sky-600" />
          </div>
          <div className="font-heading font-bold text-base text-slate-900 truncate">
            {currentUser.emergencyContactName || 'Vikram Sharma'}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {currentUser.emergencyContactPhone || '+1 (555) 349-8813'} ({currentUser.emergencyContactRelation || 'Spouse'})
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold mb-2">
            <span>High-Risk Flags</span>
            <ShieldCheck className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xs font-bold text-slate-900 space-y-1">
            {currentUser.highRiskFlags?.map((f, i) => (
              <span key={i} className="inline-block bg-amber-50 text-amber-800 border border-amber-200 px-2 py-0.5 rounded mr-1">
                {f}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Sub Navigation Tabs */}
      <div className="flex border-b border-slate-200 gap-4 text-sm font-bold">
        <button
          onClick={() => setActiveDashTab('overview')}
          className={`pb-3 border-b-2 transition flex items-center gap-1.5 ${
            activeDashTab === 'overview' ? 'border-rose-600 text-rose-600' : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <User className="w-4 h-4" />
          <span>Profile & Reminders</span>
        </button>

        <button
          onClick={() => setActiveDashTab('vitals')}
          className={`pb-3 border-b-2 transition flex items-center gap-1.5 ${
            activeDashTab === 'vitals' ? 'border-rose-600 text-rose-600' : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Health Check Updates ({vitalLogs.length})</span>
        </button>

        <button
          onClick={() => setActiveDashTab('records')}
          className={`pb-3 border-b-2 transition flex items-center gap-1.5 ${
            activeDashTab === 'records' ? 'border-rose-600 text-rose-600' : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Medical Records ({medicalRecords.length})</span>
        </button>

        <button
          onClick={() => setActiveDashTab('appointments')}
          className={`pb-3 border-b-2 transition flex items-center gap-1.5 ${
            activeDashTab === 'appointments' ? 'border-rose-600 text-rose-600' : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Appointment History ({appointments.length})</span>
        </button>

        <button
          onClick={() => setActiveDashTab('emergency')}
          className={`pb-3 border-b-2 transition flex items-center gap-1.5 ${
            activeDashTab === 'emergency' ? 'border-rose-600 text-rose-600' : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Ambulance className="w-4 h-4" />
          <span>Emergency Request Status ({userEmergencyHistory.length})</span>
        </button>
      </div>

      {/* TAB 1: OVERVIEW & PERSONAL PROFILE */}
      {activeDashTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-7 space-y-6">
            
            {/* Detailed Profile Summary Card */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-heading font-extrabold text-lg text-slate-900">
                  Personal Pregnancy Profile Details
                </h3>
                <button
                  onClick={() => setIsEditingProfile(true)}
                  className="text-xs font-bold text-rose-600 hover:underline"
                >
                  Edit Profile
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Patient Name</span>
                  <span className="font-bold text-slate-800 text-sm">{currentUser.name}</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Phone Number</span>
                  <span className="font-bold text-slate-800 text-sm">{currentUser.phone}</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Gravida / Para</span>
                  <span className="font-bold text-slate-800 text-sm">{currentUser.gravidaPara || 'G2P1'}</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Current Gestation</span>
                  <span className="font-bold text-rose-600 text-sm">Week {currentUser.gestationalWeek || 31}</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Expected Due Date</span>
                  <span className="font-bold text-slate-800 text-sm">{currentUser.expectedDueDate || '2027-01-08'}</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Blood Group</span>
                  <span className="font-bold text-slate-800 text-sm">{currentUser.bloodGroup || 'B+'}</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 text-xs">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Registered Home Address:</span>
                <span className="font-medium text-slate-700">{currentUser.address || 'Green Meadows, House 14B, Village Mandi'}</span>
              </div>
            </div>

            {/* Antenatal Reminders checklist */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
              <h3 className="font-heading font-extrabold text-lg text-slate-900">
                Antenatal Checkup & Care Reminders
              </h3>
              <div className="space-y-2.5">
                {reminders.map((rem) => (
                  <div
                    key={rem.id}
                    onClick={() => toggleReminder(rem.id)}
                    className={`p-3.5 rounded-2xl border transition flex items-start gap-3 cursor-pointer ${
                      rem.completed ? 'bg-emerald-50/50 border-emerald-200 opacity-80' : 'bg-white border-slate-200 hover:border-rose-200'
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-md border mt-0.5 flex items-center justify-center shrink-0 ${
                      rem.completed ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-slate-300 bg-white'
                    }`}>
                      {rem.completed && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className={`text-xs font-bold ${rem.completed ? 'line-through text-slate-500' : 'text-slate-900'}`}>
                          {rem.title}
                        </span>
                        <span className="text-[10px] font-semibold text-slate-400">{rem.dueDate}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">{rem.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* Right column: Quick Kick Counter widget */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-gradient-to-br from-rose-500 via-rose-600 to-pink-600 text-white rounded-3xl p-6 shadow-md space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-extrabold tracking-wider text-rose-100">Daily Fetal Kick Counter</span>
                <Timer className="w-4 h-4 text-rose-200" />
              </div>
              <div>
                <div className="font-heading font-extrabold text-4xl">{currentSessionKicks} Kicks</div>
                <p className="text-xs text-rose-100 mt-1">Recorded in current 2-hour session (Goal: &ge; 10 kicks)</p>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => setCurrentSessionKicks(prev => prev + 1)}
                  className="flex-1 bg-white text-rose-700 hover:bg-rose-50 font-extrabold text-xs py-2.5 rounded-xl transition shadow-xs"
                >
                  + Record Baby Kick
                </button>
                <button
                  onClick={() => setCurrentSessionKicks(0)}
                  className="px-3 bg-white/20 hover:bg-white/30 text-white font-bold text-xs rounded-xl"
                >
                  Reset
                </button>
              </div>
            </div>

            {/* Quick emergency hotline help */}
            <div className="bg-slate-900 text-white rounded-3xl p-6 space-y-3">
              <h4 className="font-heading font-bold text-base">Direct Emergency Lines</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                If kicks are fewer than 10 in 2 hours or if you experience abdominal cramping, dial immediately:
              </p>
              <div className="space-y-2 pt-1">
                <a href="tel:108" className="w-full py-2 px-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center justify-between">
                  <span>Call 108 Emergency Ambulance</span>
                  <PhoneCall className="w-3.5 h-3.5" />
                </a>
                <a href="tel:102" className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-300 font-bold text-xs flex items-center justify-between border border-slate-700">
                  <span>Call 102 Maternal Van</span>
                  <PhoneCall className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: HEALTH CHECK UPDATES (VITALS TRACKING) */}
      {activeDashTab === 'vitals' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-heading font-extrabold text-2xl text-slate-900">
                  Health Check Updates & Vital Telemetry
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Track blood pressure, fetal kick counts, weight, and blood sugar readings over gestational weeks.
                </p>
              </div>

              <button
                onClick={() => setShowLogVitalModal(true)}
                className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs flex items-center gap-2 self-start sm:self-auto cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Log New Health Reading</span>
              </button>
            </div>

            <div className="divide-y divide-slate-100">
              {vitalLogs.map((vital) => {
                const isBpElevated = vital.bloodPressureSystolic >= 140 || vital.bloodPressureDiastolic >= 90;
                return (
                  <div key={vital.id} className="py-4 space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <span className={`w-3 h-3 rounded-full ${isBpElevated ? 'bg-red-500' : 'bg-emerald-500'}`} />
                        <div>
                          <span className="font-bold text-slate-900 text-sm">
                            {vital.date} at {vital.time} • Week {vital.gestationalWeek}
                          </span>
                        </div>
                      </div>

                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        isBpElevated ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {isBpElevated ? 'Elevated BP Alert' : 'Vitals Normal'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                        <span className="text-slate-400 text-[10px] uppercase font-bold block">Blood Pressure</span>
                        <span className={`font-extrabold text-sm ${isBpElevated ? 'text-red-600' : 'text-slate-800'}`}>
                          {vital.bloodPressureSystolic}/{vital.bloodPressureDiastolic} mmHg
                        </span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                        <span className="text-slate-400 text-[10px] uppercase font-bold block">Fetal Kicks (2h)</span>
                        <span className="font-extrabold text-slate-800 text-sm">{vital.fetalKickCount} kicks</span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                        <span className="text-slate-400 text-[10px] uppercase font-bold block">Maternal Weight</span>
                        <span className="font-extrabold text-slate-800 text-sm">{vital.weightKg} kg</span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                        <span className="text-slate-400 text-[10px] uppercase font-bold block">Blood Sugar</span>
                        <span className="font-extrabold text-slate-800 text-sm">{vital.bloodSugarMgDl ? `${vital.bloodSugarMgDl} mg/dL` : 'Not recorded'}</span>
                      </div>
                    </div>

                    {vital.notes && (
                      <p className="text-xs text-slate-500 italic bg-white p-2 rounded-lg border border-slate-100">
                        "{vital.notes}"
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: MEDICAL RECORDS */}
      {activeDashTab === 'records' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-heading font-extrabold text-2xl text-slate-900">
                  Maternal Medical Records & Diagnostics
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Ultrasound reports, complete blood counts (Hb), OGTT glucose scans, and clinical prescriptions.
                </p>
              </div>

              <button
                onClick={() => setShowUploadRecordModal(true)}
                className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs flex items-center gap-2 self-start sm:self-auto cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Upload Medical Report</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {medicalRecords.map((rec) => (
                <div
                  key={rec.id}
                  className="p-5 rounded-2xl border border-slate-200 bg-white hover:border-rose-200 transition space-y-3 shadow-xs flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-rose-50 text-rose-700">
                        {rec.category.replace('_', ' ')}
                      </span>
                      <span className="text-slate-400 font-semibold">{rec.date}</span>
                    </div>

                    <h4 className="font-heading font-bold text-base text-slate-900">{rec.title}</h4>
                    <div className="text-xs text-slate-500 mt-0.5">{rec.facility} • {rec.doctor}</div>
                    <p className="text-xs text-slate-600 mt-2 leading-relaxed line-clamp-2">{rec.summary}</p>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                    <button
                      onClick={() => setViewingRecord(rec)}
                      className="text-xs font-bold text-rose-600 hover:text-rose-700 flex items-center gap-1"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View Full Report</span>
                    </button>
                    <span className="text-[11px] text-slate-400">Ref: #{rec.id}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: APPOINTMENT HISTORY */}
      {activeDashTab === 'appointments' && (
        <div className="space-y-4">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h3 className="font-heading font-extrabold text-xl text-slate-900">
              Doctor Appointment History
            </h3>
            <div className="divide-y divide-slate-100">
              {appointments.map((apt) => (
                <div key={apt.id} className="py-4 space-y-2.5 text-xs">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        apt.status === 'confirmed' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {apt.status}
                      </span>
                      <h4 className="font-bold text-slate-900 text-sm mt-1">{apt.doctorName}</h4>
                      <p className="text-rose-600 font-semibold">{apt.doctorSpecialization}</p>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-slate-800">{apt.date}</div>
                      <div className="text-slate-400">{apt.timeSlot}</div>
                    </div>
                  </div>
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <strong>Reason:</strong> {apt.reason}
                  </div>
                  {apt.consultationNotes && (
                    <div className="text-slate-600 italic">
                      Notes: {apt.consultationNotes}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: EMERGENCY REQUEST STATUS */}
      {activeDashTab === 'emergency' && (
        <div className="space-y-4">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-heading font-extrabold text-xl text-slate-900">
                Emergency Request Status & Logs
              </h3>
              <button
                onClick={openSosModal}
                className="px-3 py-1.5 bg-red-600 text-white font-bold text-xs rounded-xl"
              >
                New Emergency Request
              </button>
            </div>

            {userEmergencyHistory.length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xs">
                No active or previous emergency alerts.
              </div>
            ) : (
              <div className="space-y-3">
                {userEmergencyHistory.map((req) => (
                  <div key={req.id} className="p-4 rounded-2xl border border-rose-100 bg-rose-50/40 space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-red-700">Dispatch #{req.id}</span>
                      <span className="bg-red-100 text-red-800 font-semibold px-2 py-0.5 rounded-full uppercase text-[10px]">
                        {req.status.replace('_', ' ')}
                      </span>
                    </div>
                    <div className="font-semibold text-slate-800">{req.emergencyType}</div>
                    <div className="text-slate-500">Address: {req.location.address}</div>
                    {req.assignedAmbulance && (
                      <div className="bg-white p-2.5 rounded-xl border border-rose-200 space-y-1">
                        <div className="flex justify-between font-bold">
                          <span>Ambulance: {req.assignedAmbulance.vehicleNo}</span>
                          <span className="text-red-600">ETA ~{req.assignedAmbulance.etaMinutes} mins</span>
                        </div>
                        <div className="text-slate-600">Driver: {req.assignedAmbulance.driverName} ({req.assignedAmbulance.driverPhone})</div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Record Viewer Modal */}
      {viewingRecord && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-xl bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 space-y-4 text-xs">
            <div className="flex items-start justify-between pb-3 border-b">
              <div>
                <span className="text-[10px] font-bold uppercase text-rose-600 tracking-wider">
                  {viewingRecord.category.replace('_', ' ')}
                </span>
                <h3 className="font-heading font-extrabold text-lg text-slate-900">{viewingRecord.title}</h3>
                <div className="text-slate-500">{viewingRecord.facility} • {viewingRecord.doctor} • {viewingRecord.date}</div>
              </div>
              <button onClick={() => setViewingRecord(null)} className="p-1 text-slate-400 hover:text-slate-800">
                ✕
              </button>
            </div>

            <div>
              <span className="font-bold text-slate-800 block mb-1">Clinical Findings & Summary:</span>
              <p className="p-3 bg-slate-50 rounded-xl border text-slate-700 leading-relaxed">
                {viewingRecord.summary}
              </p>
            </div>

            {viewingRecord.keyValues && (
              <div>
                <span className="font-bold text-slate-800 block mb-1">Key Diagnostic Values:</span>
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(viewingRecord.keyValues).map(([k, v]) => (
                    <div key={k} className="p-2 bg-slate-50 rounded-lg border">
                      <span className="text-slate-400 text-[10px] block font-semibold">{k}</span>
                      <span className="font-bold text-slate-800">{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="pt-2 flex justify-end gap-2 border-t">
              <button
                onClick={() => setViewingRecord(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Log Vital Modal */}
      {showLogVitalModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 space-y-4">
            <h3 className="font-heading font-extrabold text-xl text-slate-900">
              Log Health Check Vitals
            </h3>
            <form onSubmit={handleSaveVital} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Systolic BP (mmHg) *</label>
                  <input
                    type="number"
                    min="80"
                    max="220"
                    required
                    value={vitalSystolic}
                    onChange={(e) => setVitalSystolic(Number(e.target.value))}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Diastolic BP (mmHg) *</label>
                  <input
                    type="number"
                    min="50"
                    max="140"
                    required
                    value={vitalDiastolic}
                    onChange={(e) => setVitalDiastolic(Number(e.target.value))}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Fetal Kicks (2h) *</label>
                  <input
                    type="number"
                    min="0"
                    max="50"
                    required
                    value={vitalKickCount}
                    onChange={(e) => setVitalKickCount(Number(e.target.value))}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Maternal Weight (kg) *</label>
                  <input
                    type="number"
                    step="0.1"
                    min="35"
                    max="150"
                    required
                    value={vitalWeight}
                    onChange={(e) => setVitalWeight(Number(e.target.value))}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Blood Sugar (mg/dL - Optional)</label>
                <input
                  type="number"
                  value={vitalSugar}
                  onChange={(e) => setVitalSugar(Number(e.target.value))}
                  className="w-full px-3 py-2 border rounded-xl"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Notes / Physical Symptoms</label>
                <textarea
                  rows={2}
                  value={vitalNotes}
                  onChange={(e) => setVitalNotes(e.target.value)}
                  placeholder="e.g. Mild headache, took extra rest, good active baby kicks..."
                  className="w-full px-3 py-2 border rounded-xl resize-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowLogVitalModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl"
                >
                  Record Vitals
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Upload Record Modal */}
      {showUploadRecordModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 space-y-4">
            <h3 className="font-heading font-extrabold text-xl text-slate-900">
              Upload Medical Report / Diagnostic Record
            </h3>
            <form onSubmit={handleCreateMedicalRecord} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-bold mb-1">Report Title *</label>
                <input
                  type="text"
                  required
                  value={newRecTitle}
                  onChange={(e) => setNewRecTitle(e.target.value)}
                  placeholder="e.g. 32-Week Doppler Growth Ultrasound"
                  className="w-full px-3 py-2 border rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Category *</label>
                  <select
                    value={newRecCategory}
                    onChange={(e) => setNewRecCategory(e.target.value as any)}
                    className="w-full px-3 py-2 border rounded-xl bg-white"
                  >
                    <option value="ultrasound">Ultrasound Scan</option>
                    <option value="lab_report">Lab Test / Blood Work</option>
                    <option value="prescription">Doctor Prescription</option>
                    <option value="discharge_summary">Discharge Summary</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Date *</label>
                  <input
                    type="date"
                    required
                    value={newRecDate}
                    onChange={(e) => setNewRecDate(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Health Facility</label>
                  <input
                    type="text"
                    value={newRecFacility}
                    onChange={(e) => setNewRecFacility(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Doctor / Radiologist</label>
                  <input
                    type="text"
                    value={newRecDoctor}
                    onChange={(e) => setNewRecDoctor(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Summary / Clinical Diagnosis</label>
                <textarea
                  rows={3}
                  value={newRecSummary}
                  onChange={(e) => setNewRecSummary(e.target.value)}
                  placeholder="e.g. Normal fetal growth parameters, cephalic presentation, clear fluid index..."
                  className="w-full px-3 py-2 border rounded-xl resize-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowUploadRecordModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl"
                >
                  Save Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Profile Modal */}
      {isEditingProfile && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 space-y-4">
            <h3 className="font-heading font-extrabold text-xl text-slate-900">
              Edit Maternal Health Profile
            </h3>
            <form onSubmit={handleSaveProfile} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-bold mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Phone Number</label>
                  <input
                    type="tel"
                    required
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Gestational Week</label>
                  <input
                    type="number"
                    min="4"
                    max="44"
                    value={editWeek}
                    onChange={(e) => setEditWeek(Number(e.target.value))}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Expected Due Date (EDD)</label>
                  <input
                    type="date"
                    value={editEdd}
                    onChange={(e) => setEditEdd(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Gravida / Para</label>
                  <input
                    type="text"
                    value={editGravidaPara}
                    onChange={(e) => setEditGravidaPara(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Blood Group</label>
                  <select
                    value={editBloodGroup}
                    onChange={(e) => setEditBloodGroup(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl bg-white"
                  >
                    <option value="A Positive (A+)">A Positive (A+)</option>
                    <option value="A Negative (A-)">A Negative (A-)</option>
                    <option value="B Positive (B+)">B Positive (B+)</option>
                    <option value="B Negative (B-)">B Negative (B-)</option>
                    <option value="O Positive (O+)">O Positive (O+)</option>
                    <option value="O Negative (O-)">O Negative (O-)</option>
                    <option value="AB Positive (AB+)">AB Positive (AB+)</option>
                    <option value="AB Negative (AB-)">AB Negative (AB-)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Emergency Contact Phone</label>
                  <input
                    type="tel"
                    value={editContactPhone}
                    onChange={(e) => setEditContactPhone(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Emergency Contact Name & Relation</label>
                <input
                  type="text"
                  value={editContactName}
                  onChange={(e) => setEditContactName(e.target.value)}
                  placeholder="e.g. Vikram Sharma (Husband)"
                  className="w-full px-3 py-2 border rounded-xl"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Home Address / Location</label>
                <input
                  type="text"
                  value={editAddress}
                  onChange={(e) => setEditAddress(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditingProfile(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow-xs"
                >
                  Save Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
