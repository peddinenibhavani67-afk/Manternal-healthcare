import React, { useState } from 'react';
import { 
  Stethoscope, 
  Video, 
  Calendar, 
  Clock, 
  MapPin, 
  Star, 
  CheckCircle2, 
  PhoneCall, 
  Search, 
  Filter, 
  X, 
  MessageSquare, 
  ShieldCheck, 
  User, 
  ArrowRight,
  Sparkles,
  AlertTriangle,
  History,
  FileText,
  Pill,
  BookOpen,
  ChevronDown
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Doctor, DoctorSpecialization, Appointment } from '../types';

export const DoctorConsultationPage: React.FC = () => {
  const { doctors, currentUser, appointments, bookAppointment, openSosModal } = useApp();

  const [activeTab, setActiveTab] = useState<'directory' | 'history' | 'guidance'>('directory');

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpecialization, setSelectedSpecialization] = useState<string>('all');
  const [selectedMode, setSelectedMode] = useState<string>('all');
  const [availableNowOnly, setAvailableNowOnly] = useState(false);

  // Booking Modal State
  const [bookingDoctor, setBookingDoctor] = useState<Doctor | null>(null);
  const [consultType, setConsultType] = useState<'video' | 'in-person' | 'emergency-call'>('video');
  const [selectedDate, setSelectedDate] = useState('2026-11-09');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState('11:00 AM');
  const [patientName, setPatientName] = useState(currentUser.name || '');
  const [patientPhone, setPatientPhone] = useState(currentUser.phone || '');
  const [gestationalWeek, setGestationalWeek] = useState(currentUser.gestationalWeek || 31);
  const [reason, setReason] = useState('Second/Third trimester routine review & fetal kick assessment');
  const [bookingSuccessApt, setBookingSuccessApt] = useState<Appointment | null>(null);

  // Active video call simulator
  const [activeVideoCallApt, setActiveVideoCallApt] = useState<Appointment | null>(null);

  // Filter doctors
  const filteredDoctors = doctors.filter(doc => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = doc.name.toLowerCase().includes(q);
      const matchSpec = doc.specialization.toLowerCase().includes(q);
      const matchHosp = doc.hospitalName.toLowerCase().includes(q);
      if (!matchName && !matchSpec && !matchHosp) return false;
    }

    if (selectedSpecialization !== 'all' && doc.specialization !== selectedSpecialization) {
      return false;
    }

    if (selectedMode !== 'all' && !doc.supportedModes.includes(selectedMode as any)) {
      return false;
    }

    if (availableNowOnly && !doc.availableNow) {
      return false;
    }

    return true;
  });

  const handleOpenBooking = (doc: Doctor) => {
    setBookingDoctor(doc);
    setBookingSuccessApt(null);
    setPatientName(currentUser.name || '');
    setPatientPhone(currentUser.phone || '');
    setGestationalWeek(currentUser.gestationalWeek || 31);
  };

  const handleConfirmBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingDoctor) return;

    const apt = bookAppointment({
      doctorId: bookingDoctor.id,
      doctorName: bookingDoctor.name,
      doctorSpecialization: bookingDoctor.specialization,
      doctorAvatar: bookingDoctor.avatarUrl,
      patientName: patientName.trim() || 'Patient',
      patientPhone: patientPhone.trim(),
      date: selectedDate,
      timeSlot: selectedTimeSlot,
      consultType,
      gestationalWeek: Number(gestationalWeek) || 30,
      reason: reason.trim(),
      consultationNotes: 'Pending physician session.',
      prescriptions: []
    });

    setBookingSuccessApt(apt);
  };

  // Clinical Guidance Accordion items
  const guidanceTopics = [
    {
      title: 'Managing Blood Pressure & Preeclampsia Screenings',
      category: 'High-Risk Guidance',
      content: 'Blood pressure above 140/90 mmHg after 20 weeks requires immediate medical evaluation. Monitor for upper right abdominal pain, persistent headaches unresponsive to fluids, and sudden swelling of face/hands.'
    },
    {
      title: 'Fetal Kick Count Protocol (Daily Habit after 28 Weeks)',
      category: 'Fetal Wellbeing',
      content: 'Choose a quiet hour after a light meal. Lie on your left side. Count distinct movements (kicks, flutters, rolls). You should experience at least 10 movements within a 2-hour window. If kicks drop noticeably, contact on-call doctor immediately.'
    },
    {
      title: 'Gestational Diabetes Mellitus (GDM) Management',
      category: 'Metabolic Health',
      content: 'Maintain a complex-carbohydrate, high-fiber diet with low glycemic index. Regular 20-minute post-meal walks help stabilize insulin resistance. Monitor fasting (<92 mg/dL) and 2-hr post-meal blood sugar (<120 mg/dL).'
    },
    {
      title: 'Labor Pain vs Braxton Hicks False Contractions',
      category: 'Labor Preparedness',
      content: 'Braxton Hicks are irregular, painless or mildly tight, and stop when you walk or change posture. True labor contractions occur at regular intervals (every 3 to 5 minutes), grow steadily stronger, last 45-60 seconds, and do not stop when lying down.'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-bold uppercase tracking-wider mb-2">
            <Stethoscope className="w-3.5 h-3.5" />
            <span>Telemedicine & Clinical Obstetric Network</span>
          </div>
          <h1 className="font-heading text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Consult Doctors & Healthcare Professionals
          </h1>
          <p className="text-sm sm:text-base text-slate-600 mt-1 max-w-2xl">
            Online doctor consultations, appointment booking, specialist availability, pregnancy guidance, and past medical consultation records.
          </p>
        </div>

        <button
          onClick={openSosModal}
          className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-md flex items-center gap-2 cursor-pointer self-start md:self-auto animate-emergency"
        >
          <AlertTriangle className="w-4 h-4" />
          <span>Acute Emergency Triage</span>
        </button>
      </div>

      {/* Main Tabs */}
      <div className="flex border-b border-slate-200 gap-4 text-sm font-bold">
        <button
          onClick={() => setActiveTab('directory')}
          className={`pb-3 border-b-2 transition flex items-center gap-2 ${
            activeTab === 'directory'
              ? 'border-rose-600 text-rose-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Stethoscope className="w-4 h-4" />
          <span>Doctor Availability & Online Consultation ({doctors.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('history')}
          className={`pb-3 border-b-2 transition flex items-center gap-2 ${
            activeTab === 'history'
              ? 'border-rose-600 text-rose-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Medical Consultation History ({appointments.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('guidance')}
          className={`pb-3 border-b-2 transition flex items-center gap-2 ${
            activeTab === 'guidance'
              ? 'border-rose-600 text-rose-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Pregnancy-Related Guidance</span>
        </button>
      </div>

      {/* TAB 1: DOCTORS DIRECTORY & BOOKING */}
      {activeTab === 'directory' && (
        <div className="space-y-6">
          {/* Filter and Search Bar */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
              
              {/* Search */}
              <div className="md:col-span-5 relative">
                <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by doctor name, hospital, or specialty..."
                  className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                />
              </div>

              {/* Specialization */}
              <div className="md:col-span-4">
                <select
                  value={selectedSpecialization}
                  onChange={(e) => setSelectedSpecialization(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none bg-white text-slate-700"
                >
                  <option value="all">All Specialties</option>
                  <option value="Obstetrician & Gynecologist">Obstetrician & Gynecologist</option>
                  <option value="Maternal-Fetal Medicine (High Risk)">Maternal-Fetal Medicine (High Risk)</option>
                  <option value="Certified Nurse Midwife">Certified Nurse Midwife</option>
                  <option value="Lactation & Postnatal Consultant">Lactation & Postnatal Consultant</option>
                </select>
              </div>

              {/* Consultation Mode */}
              <div className="md:col-span-3">
                <select
                  value={selectedMode}
                  onChange={(e) => setSelectedMode(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none bg-white text-slate-700"
                >
                  <option value="all">All Consult Modes</option>
                  <option value="video">Tele-Video Consultation</option>
                  <option value="in-person">In-Clinic Visit</option>
                  <option value="emergency-call">Emergency Telephone Triage</option>
                </select>
              </div>
            </div>

            {/* Quick toggle chips */}
            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 text-xs">
              <button
                onClick={() => setAvailableNowOnly(!availableNowOnly)}
                className={`px-3 py-1.5 rounded-lg font-semibold border transition cursor-pointer flex items-center gap-1.5 ${
                  availableNowOnly
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-800 ring-1 ring-emerald-400'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                <span>Available Now for Consultation</span>
              </button>
              <span className="text-slate-400 text-xs ml-auto">
                Showing <strong>{filteredDoctors.length}</strong> verified practitioners
              </span>
            </div>
          </div>

          {/* Doctor Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDoctors.map((doc) => (
              <div
                key={doc.id}
                className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs hover:border-rose-200 hover:shadow-md transition-all flex flex-col justify-between space-y-4"
              >
                <div>
                  {/* Doctor Avatar & Badges */}
                  <div className="flex items-start gap-4">
                    <div className="relative">
                      <img
                        src={doc.avatarUrl}
                        alt={doc.name}
                        className="w-18 h-18 rounded-2xl object-cover border-2 border-rose-100 shadow-sm"
                      />
                      {doc.availableNow && (
                        <span 
                          className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-white" 
                          title="Available Now"
                        />
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1 text-amber-500 text-xs font-bold mb-0.5">
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                        <span>{doc.rating}</span>
                        <span className="text-slate-400 font-normal">({doc.reviewsCount} reviews)</span>
                      </div>
                      <h3 className="font-heading font-bold text-lg text-slate-900 leading-tight">
                        {doc.name}
                      </h3>
                      <p className="text-xs font-semibold text-rose-600 mt-0.5">
                        {doc.specialization}
                      </p>
                      <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                        {doc.qualification}
                      </p>
                    </div>
                  </div>

                  {/* Hospital & Availability */}
                  <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-600 space-y-1.5">
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{doc.hospitalName}</span>
                    </div>
                    <div className="flex items-center justify-between text-[11px]">
                      <span>Experience: <strong>{doc.experienceYears}+ Years</strong></span>
                      <span className={`font-semibold ${doc.availableNow ? 'text-emerald-700' : 'text-slate-500'}`}>
                        {doc.nextAvailableSlot}
                      </span>
                    </div>
                  </div>

                  {/* Bio summary */}
                  <p className="mt-3 text-xs text-slate-600 line-clamp-3 leading-relaxed">
                    {doc.bio}
                  </p>

                  {/* Consultation Modes */}
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {doc.supportedModes.map(mode => (
                      <span key={mode} className="text-[10px] font-semibold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md capitalize">
                        {mode === 'video' ? '📹 Online Video' : mode === 'in-person' ? '🏥 In-Clinic' : '📞 Phone Triage'}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Bottom Booking & Fee section */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
                  <div>
                    <div className="text-[10px] uppercase font-bold text-slate-400">Consultation Fee</div>
                    <div className="font-heading font-extrabold text-base text-slate-900">
                      {doc.consultationFee === 0 ? (
                        <span className="text-emerald-600 font-bold">100% Free / Govt.</span>
                      ) : (
                        <span>${doc.consultationFee}</span>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => handleOpenBooking(doc)}
                    className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Book Appointment</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: MEDICAL CONSULTATION HISTORY */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div>
              <h3 className="font-heading font-extrabold text-xl text-slate-900">
                Patient Consultation History & Clinical Summaries
              </h3>
              <p className="text-xs text-slate-500">
                Complete record of previous obstetric telemedicine consultations, clinical notes, and physician prescriptions.
              </p>
            </div>

            <div className="divide-y divide-slate-100">
              {appointments.map((apt) => (
                <div key={apt.id} className="py-4 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center font-bold text-xs shrink-0">
                        {apt.consultType === 'video' ? <Video className="w-5 h-5" /> : <MapPin className="w-5 h-5" />}
                      </div>
                      <div>
                        <div className="font-heading font-bold text-base text-slate-900">
                          {apt.doctorName} • <span className="text-xs text-rose-600 font-semibold">{apt.doctorSpecialization}</span>
                        </div>
                        <div className="text-xs text-slate-500">
                          Date: {apt.date} at {apt.timeSlot} • Mode: <strong className="capitalize">{apt.consultType}</strong>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase ${
                        apt.status === 'confirmed' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {apt.status}
                      </span>
                      {apt.consultType === 'video' && apt.status === 'confirmed' && (
                        <button
                          onClick={() => setActiveVideoCallApt(apt)}
                          className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl flex items-center gap-1"
                        >
                          <Video className="w-3.5 h-3.5" />
                          <span>Join Video Consult</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {apt.consultationNotes && (
                    <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 text-xs text-slate-700 space-y-1">
                      <div className="font-bold text-slate-900 flex items-center gap-1.5">
                        <FileText className="w-3.5 h-3.5 text-rose-600" />
                        <span>Doctor Clinical Consultation Notes:</span>
                      </div>
                      <p className="leading-relaxed text-slate-600">{apt.consultationNotes}</p>
                    </div>
                  )}

                  {apt.prescriptions && apt.prescriptions.length > 0 && (
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <span className="font-bold text-slate-700 flex items-center gap-1">
                        <Pill className="w-3.5 h-3.5 text-rose-600" />
                        <span>Prescriptions:</span>
                      </span>
                      {apt.prescriptions.map((p, idx) => (
                        <span key={idx} className="bg-rose-50 text-rose-800 border border-rose-200 px-2 py-0.5 rounded-md font-semibold text-[11px]">
                          {p}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: PREGNANCY-RELATED GUIDANCE */}
      {activeTab === 'guidance' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 space-y-4">
            <div>
              <h3 className="font-heading font-extrabold text-2xl text-slate-900">
                Pregnancy-Related Clinical Guidance & FAQs
              </h3>
              <p className="text-xs text-slate-500">
                Evidence-based maternal advice vetted by senior obstetricians and maternal-fetal medicine specialists.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {guidanceTopics.map((g, i) => (
                <div key={i} className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-2">
                  <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-rose-100 text-rose-800">
                    {g.category}
                  </span>
                  <h4 className="font-heading font-bold text-base text-slate-900 mt-1">
                    {g.title}
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {g.content}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Appointment Booking Modal */}
      {bookingDoctor && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-rose-200 overflow-hidden my-6">
            
            <div className="bg-gradient-to-r from-rose-600 to-pink-600 text-white p-5 flex items-start justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={bookingDoctor.avatarUrl}
                  alt={bookingDoctor.name}
                  className="w-12 h-12 rounded-xl object-cover border-2 border-white/30"
                />
                <div>
                  <h3 className="font-heading font-extrabold text-lg">
                    Book Consultation with {bookingDoctor.name}
                  </h3>
                  <p className="text-xs text-rose-100">{bookingDoctor.specialization} • {bookingDoctor.hospitalName}</p>
                </div>
              </div>
              <button
                onClick={() => setBookingDoctor(null)}
                className="text-white/80 hover:text-white p-1 rounded-lg"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6">
              {bookingSuccessApt ? (
                <div className="text-center py-6 space-y-4">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-md">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>
                  <div>
                    <h3 className="font-heading font-extrabold text-2xl text-slate-900">
                      Appointment Confirmed!
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">
                      Confirmation reference: <strong>#{bookingSuccessApt.id}</strong>
                    </p>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-left text-xs space-y-2 max-w-md mx-auto">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Doctor:</span>
                      <span className="font-bold text-slate-800">{bookingSuccessApt.doctorName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Date & Time:</span>
                      <span className="font-bold text-slate-800">{bookingSuccessApt.date} at {bookingSuccessApt.timeSlot}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Mode:</span>
                      <span className="font-bold text-rose-600 capitalize">{bookingSuccessApt.consultType} Consultation</span>
                    </div>
                    {bookingSuccessApt.meetingLink && (
                      <div className="pt-2 border-t border-slate-200">
                        <span className="text-slate-500 block mb-1">Encrypted Video Room:</span>
                        <a 
                          href={bookingSuccessApt.meetingLink} 
                          target="_blank" 
                          rel="noreferrer" 
                          className="text-rose-600 font-bold hover:underline break-all"
                        >
                          {bookingSuccessApt.meetingLink}
                        </a>
                      </div>
                    )}
                  </div>

                  <div className="pt-4 flex justify-center gap-3">
                    <button
                      onClick={() => setBookingDoctor(null)}
                      className="px-6 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-xs transition"
                    >
                      Done & Back to Directory
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleConfirmBooking} className="space-y-4">
                  {/* Select Mode */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      Select Consultation Mode
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        type="button"
                        onClick={() => setConsultType('video')}
                        className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center justify-center gap-1 cursor-pointer ${
                          consultType === 'video'
                            ? 'bg-rose-50 border-rose-500 text-rose-700 ring-1 ring-rose-400'
                            : 'bg-white border-slate-200 text-slate-600'
                        }`}
                      >
                        <Video className="w-4 h-4" />
                        <span>Online Video</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setConsultType('in-person')}
                        className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center justify-center gap-1 cursor-pointer ${
                          consultType === 'in-person'
                            ? 'bg-rose-50 border-rose-500 text-rose-700 ring-1 ring-rose-400'
                            : 'bg-white border-slate-200 text-slate-600'
                        }`}
                      >
                        <MapPin className="w-4 h-4" />
                        <span>In-Clinic</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setConsultType('emergency-call')}
                        className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center justify-center gap-1 cursor-pointer ${
                          consultType === 'emergency-call'
                            ? 'bg-rose-50 border-rose-500 text-rose-700 ring-1 ring-rose-400'
                            : 'bg-white border-slate-200 text-slate-600'
                        }`}
                      >
                        <PhoneCall className="w-4 h-4" />
                        <span>Phone Triage</span>
                      </button>
                    </div>
                  </div>

                  {/* Date and Time */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Select Date *</label>
                      <input
                        type="date"
                        required
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Time Slot *</label>
                      <select
                        value={selectedTimeSlot}
                        onChange={(e) => setSelectedTimeSlot(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none bg-white text-slate-700"
                      >
                        <option value="09:30 AM">09:30 AM - 10:00 AM</option>
                        <option value="11:00 AM">11:00 AM - 11:30 AM</option>
                        <option value="02:30 PM">02:30 PM - 03:00 PM</option>
                        <option value="04:00 PM">04:00 PM - 04:30 PM</option>
                        <option value="06:00 PM">06:00 PM - 06:30 PM</option>
                      </select>
                    </div>
                  </div>

                  {/* Patient Info */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Patient Name *</label>
                      <input
                        type="text"
                        required
                        value={patientName}
                        onChange={(e) => setPatientName(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Phone Number *</label>
                      <input
                        type="tel"
                        required
                        value={patientPhone}
                        onChange={(e) => setPatientPhone(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Current Gestational Week</label>
                    <input
                      type="number"
                      min="4"
                      max="44"
                      value={gestationalWeek}
                      onChange={(e) => setGestationalWeek(Number(e.target.value))}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Reason for Consultation / Symptoms</label>
                    <textarea
                      rows={2}
                      value={reason}
                      onChange={(e) => setReason(e.target.value)}
                      placeholder="e.g. Mild swelling in feet, second trimester ultrasound review..."
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none resize-none"
                    />
                  </div>

                  <div className="pt-2 flex items-center justify-end gap-3">
                    <button
                      type="button"
                      onClick={() => setBookingDoctor(null)}
                      className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-xs transition"
                    >
                      Confirm Booking
                    </button>
                  </div>
                </form>
              )}
            </div>

          </div>
        </div>
      )}

      {/* Simulated Live Video Consultation Room */}
      {activeVideoCallApt && (
        <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col items-center justify-between p-4 sm:p-6 text-white animate-in fade-in">
          <div className="w-full max-w-4xl flex items-center justify-between pb-4 border-b border-white/10">
            <div className="flex items-center gap-3">
              <span className="w-3 h-3 rounded-full bg-emerald-500 animate-ping"></span>
              <div>
                <div className="font-bold text-sm">Online Doctor Video Room: {activeVideoCallApt.doctorName}</div>
                <div className="text-xs text-slate-400">Encrypted Consultation Session • Session #{activeVideoCallApt.id}</div>
              </div>
            </div>
            <button
              onClick={() => setActiveVideoCallApt(null)}
              className="bg-red-600 hover:bg-red-700 px-4 py-1.5 rounded-xl text-xs font-bold transition"
            >
              End Call
            </button>
          </div>

          <div className="w-full max-w-4xl flex-1 flex flex-col md:flex-row items-center justify-center gap-6 my-6">
            <div className="w-full md:w-2/3 h-72 sm:h-96 rounded-3xl bg-slate-800 border border-slate-700 relative overflow-hidden flex items-center justify-center">
              <img
                src={activeVideoCallApt.doctorAvatar || 'https://images.unsplash.com/photo-1594824813689-dd4b82d02c89?auto=format&fit=crop&w=800&q=80'}
                alt="Doctor consultation"
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-4 left-4 bg-slate-900/80 backdrop-blur-xs px-3 py-1 rounded-xl text-xs font-bold">
                {activeVideoCallApt.doctorName} ({activeVideoCallApt.doctorSpecialization})
              </div>
            </div>

            <div className="w-full md:w-1/3 h-48 sm:h-96 rounded-3xl bg-slate-900 border border-slate-800 p-4 flex flex-col justify-between">
              <div>
                <div className="text-xs text-rose-400 font-bold uppercase mb-2">Patient Profile Telemetry</div>
                <div className="text-xs space-y-2 text-slate-300">
                  <div className="flex justify-between border-b border-slate-800 pb-1">
                    <span>Patient:</span>
                    <span className="text-white font-semibold">{currentUser.name}</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-800 pb-1">
                    <span>Gestation:</span>
                    <span className="text-white font-semibold">Week {activeVideoCallApt.gestationalWeek}</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-800 pb-1">
                    <span>Reason:</span>
                    <span className="text-white font-semibold truncate max-w-[150px]">{activeVideoCallApt.reason}</span>
                  </div>
                </div>
              </div>

              <div className="bg-slate-800/80 p-3 rounded-2xl text-[11px] text-slate-400">
                Doctor Note: "Patient in 3rd trimester. Listening to fetal heartbeat report and assessing edema symptoms."
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setActiveVideoCallApt(null)}
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-full font-bold text-xs flex items-center gap-2 shadow-lg"
            >
              <PhoneCall className="w-4 h-4 rotate-135" />
              <span>Leave Online Consultation</span>
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
