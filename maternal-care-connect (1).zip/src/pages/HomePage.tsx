import React, { useState } from 'react';
import { 
  Ambulance, 
  MapPin, 
  Stethoscope, 
  HeartHandshake, 
  Clock, 
  ShieldCheck, 
  PhoneCall, 
  AlertOctagon, 
  Calendar, 
  ArrowRight, 
  CheckCircle2, 
  Sparkles,
  Users,
  Compass,
  Baby,
  Bell,
  Heart,
  FileText,
  Activity,
  ChevronRight,
  ExternalLink
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { EMERGENCY_HOTLINES, PREGNANCY_RED_FLAGS } from '../data/mockData';

interface HomePageProps {
  setActiveTab: (tab: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ setActiveTab }) => {
  const { openSosModal, hospitals, healthUpdates } = useApp();
  const [selectedUpdate, setSelectedUpdate] = useState<string | null>(null);

  const quickServices = [
    {
      id: 'emergency',
      title: 'Emergency Help (SOS)',
      desc: 'GPS-enabled emergency ambulance request with live tracking & hospital alert.',
      icon: Ambulance,
      color: 'from-red-600 to-rose-600',
      badge: 'Immediate Action'
    },
    {
      id: 'hospitals',
      title: 'Find Hospitals & Beds',
      desc: 'Locate 24/7 C-Section facilities, NICUs, and verified available beds.',
      icon: MapPin,
      color: 'from-rose-500 to-pink-500',
      badge: 'Live Capacity'
    },
    {
      id: 'doctors',
      title: 'Consult Qualified Doctors',
      desc: 'Book tele-video consultations or in-person visits with verified obstetricians.',
      icon: Stethoscope,
      color: 'from-pink-600 to-rose-700',
      badge: 'Tele-Health'
    },
    {
      id: 'care',
      title: 'Pregnancy Care & Awareness',
      desc: 'Trimester guides, nutrition plans, vaccine schedule, and danger signs checker.',
      icon: Baby,
      color: 'from-rose-600 to-red-600',
      badge: 'Maternal Guide'
    },
    {
      id: 'dashboard',
      title: 'My Maternal Passport',
      desc: 'Track pregnancy vitals, medical records, appointments, and kick counters.',
      icon: Activity,
      color: 'from-slate-800 to-slate-900',
      badge: 'Patient Hub'
    }
  ];

  return (
    <div className="space-y-16 pb-16">
      
      {/* 1. HERO & WEBSITE INTRODUCTION */}
      <section className="relative overflow-hidden bg-gradient-to-b from-rose-50/90 via-white to-slate-50 border-b border-rose-100">
        <div className="absolute top-0 right-0 -mr-24 -mt-24 w-96 h-96 rounded-full bg-rose-200/40 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-24 -mb-24 w-80 h-80 rounded-full bg-sky-200/30 blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-16 relative">
          
          {/* Important Health Updates Alert Bar at Top */}
          <div className="mb-8 bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-amber-500/10 border border-amber-300/60 rounded-2xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5">
              <span className="p-1 rounded-lg bg-amber-500 text-white shrink-0">
                <Bell className="w-3.5 h-3.5" />
              </span>
              <div className="text-slate-800">
                <strong className="text-amber-900 font-bold uppercase tracking-wide mr-1.5">[Important Health Update]:</strong>
                <span>{healthUpdates[0].title}</span>
              </div>
            </div>
            <a 
              href="#health-updates" 
              className="text-rose-700 font-extrabold hover:underline whitespace-nowrap self-end sm:self-auto"
            >
              Read Official Bulletins &rarr;
            </a>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column: Website Introduction & Purpose */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-rose-100 text-rose-800 text-xs font-bold tracking-wide">
                <span className="w-2 h-2 rounded-full bg-rose-600 animate-pulse"></span>
                <span>WEBSITE INTRODUCTION & MISSION</span>
              </div>

              <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.15]">
                Every Mother Deserves <br className="hidden sm:inline" />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-rose-600 via-pink-600 to-rose-700">
                  Safe and Timely Care.
                </span>
              </h1>

              {/* Website Introduction Narrative */}
              <div className="space-y-3 text-slate-600 text-sm sm:text-base leading-relaxed max-w-2xl">
                <p>
                  <strong>Maternal Care Connect</strong> is a dedicated healthcare coordination network engineered to bridge the critical emergency gap. In rural and peri-urban regions, delays in recognizing symptoms, finding available ambulances, and reaching hospitals with staffed surgical teams cause preventable maternal complications.
                </p>
                <p className="text-xs sm:text-sm text-slate-500">
                  Our platform connects expectant mothers, rural midwives, emergency ambulance fleets, and 24/7 maternity hospitals into <strong>one unified digital lifeline</strong>.
                </p>
              </div>

              {/* Primary Call to Actions */}
              <div className="pt-2 flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start">
                <button
                  onClick={openSosModal}
                  className="w-full sm:w-auto px-7 py-4 bg-gradient-to-r from-red-600 via-rose-600 to-red-600 hover:from-red-700 hover:to-rose-700 text-white font-extrabold text-base rounded-2xl shadow-xl shadow-rose-600/30 flex items-center justify-center gap-3 transform active:scale-95 transition-all animate-emergency cursor-pointer"
                >
                  <Ambulance className="w-6 h-6" />
                  <span>EMERGENCY HELP (SOS)</span>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('hospitals');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="w-full sm:w-auto px-7 py-4 bg-white hover:bg-slate-50 text-slate-800 font-bold text-base rounded-2xl border-2 border-slate-200 hover:border-rose-300 shadow-sm flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <MapPin className="w-5 h-5 text-rose-600" />
                  <span>Find Nearby Hospitals</span>
                </button>
              </div>

              {/* Key Trust Statistics */}
              <div className="pt-4 grid grid-cols-3 gap-3 border-t border-slate-200/80 text-left">
                <div>
                  <div className="font-heading font-extrabold text-xl text-slate-900">24/7</div>
                  <div className="text-xs text-slate-500 font-medium">Emergency Triage</div>
                </div>
                <div>
                  <div className="font-heading font-extrabold text-xl text-slate-900">100%</div>
                  <div className="text-xs text-slate-500 font-medium">Cashless Govt. Care</div>
                </div>
                <div>
                  <div className="font-heading font-extrabold text-xl text-slate-900">&lt; 15m</div>
                  <div className="text-xs text-slate-500 font-medium">Target Response Time</div>
                </div>
              </div>

            </div>

            {/* Right Column: Visual Maternal Healthcare Overview */}
            <div className="lg:col-span-5">
              <div className="relative mx-auto max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-rose-100">
                <div className="absolute -top-3 -right-3 bg-rose-600 text-white text-[11px] font-extrabold px-3 py-1 rounded-full shadow-md uppercase tracking-wide">
                  Live Response Network
                </div>

                <div className="relative h-56 rounded-2xl overflow-hidden mb-6 bg-slate-100">
                  <img 
                    src="https://images.unsplash.com/photo-1544717302-de2939b7ef71?auto=format&fit=crop&w=800&q=80" 
                    alt="Caring maternal healthcare specialist holding mother's hands" 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex items-end p-4">
                    <div className="text-white">
                      <div className="text-xs font-semibold text-rose-300 uppercase">Universal Access</div>
                      <div className="font-heading font-bold text-sm">Safe Motherhood for Every Community</div>
                    </div>
                  </div>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                    <span className="text-slate-500 font-medium">Nearby Verified Facilities:</span>
                    <span className="font-bold text-slate-900">{hospitals.length} hospitals</span>
                  </div>

                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                    <span className="text-slate-500 font-medium">Total Open Maternity Beds:</span>
                    <span className="font-bold text-emerald-600">
                      {hospitals.reduce((acc, h) => acc + h.availableMaternityBeds, 0)} available now
                    </span>
                  </div>

                  <div className="bg-rose-50 rounded-xl p-3 text-rose-900 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <PhoneCall className="w-4 h-4 text-rose-600" />
                      <span className="font-bold">National Helplines:</span>
                    </div>
                    <span className="font-extrabold text-sm text-rose-700">108 / 102</span>
                  </div>
                </div>

              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 2. QUICK ACCESS TO SERVICES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-rose-600 text-xs font-extrabold uppercase tracking-widest">
            One-Stop Healthcare Ecosystem
          </span>
          <h2 className="font-heading text-3xl font-extrabold text-slate-900 mt-1">
            Quick Access to Services
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-2">
            Instant digital access to critical emergency transport, hospital beds, and clinical expertise.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {quickServices.map((srv) => {
            const Icon = srv.icon;
            return (
              <div
                key={srv.id}
                onClick={() => {
                  setActiveTab(srv.id);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="group bg-white rounded-3xl p-6 border border-slate-200 hover:border-rose-300 shadow-xs hover:shadow-xl transition-all cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${srv.color} text-white flex items-center justify-center shadow-md group-hover:scale-110 transition-transform`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-1 rounded-full bg-slate-100 text-slate-700">
                      {srv.badge}
                    </span>
                  </div>

                  <h3 className="font-heading font-extrabold text-lg text-slate-900 group-hover:text-rose-600 transition">
                    {srv.title}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                    {srv.desc}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-rose-600">
                  <span>Access Service</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. MATERNAL HEALTH INFORMATION & THE 3 DELAYS MODEL */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            
            <div className="lg:col-span-5 space-y-4">
              <span className="text-rose-400 text-xs font-extrabold uppercase tracking-wider">
                Maternal Health Information
              </span>
              <h2 className="font-heading text-3xl sm:text-4xl font-extrabold">
                Why Maternal Emergencies Require Rapid Coordination
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Global health studies demonstrate that over <strong>75% of maternal deaths</strong> stem from preventable complications like severe postpartum hemorrhage, preeclampsia, puerperal sepsis, and obstructed labor.
              </p>
              <div className="p-4 bg-slate-800 rounded-2xl border border-slate-700 text-xs space-y-2">
                <div className="font-bold text-rose-300 flex items-center gap-1.5">
                  <Heart className="w-4 h-4" />
                  <span>The Golden Hour in Obstetric Care</span>
                </div>
                <p className="text-slate-400 leading-relaxed">
                  Intervention within the first 60 minutes of acute symptoms—such as heavy bleeding or severe eclamptic convulsions—is the single greatest predictor of maternal and newborn survival.
                </p>
              </div>
            </div>

            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="bg-slate-800/80 p-5 rounded-2xl border border-slate-700 space-y-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 font-extrabold flex items-center justify-center">
                  01
                </div>
                <div className="font-heading font-bold text-sm text-white">Delay in Seeking Care</div>
                <p className="text-slate-400 leading-relaxed">
                  Hesitation due to unrecognized danger signs. MCC solves this with 24/7 symptom red-flags and free tele-triage.
                </p>
              </div>

              <div className="bg-slate-800/80 p-5 rounded-2xl border border-slate-700 space-y-3">
                <div className="w-9 h-9 rounded-xl bg-rose-500/20 text-rose-400 font-extrabold flex items-center justify-center">
                  02
                </div>
                <div className="font-heading font-bold text-sm text-white">Delay in Reaching Facility</div>
                <p className="text-slate-400 leading-relaxed">
                  Road distances and scarce transport. MCC solves this with GPS-tagged SOS dispatch for Basic and Advanced ambulances.
                </p>
              </div>

              <div className="bg-slate-800/80 p-5 rounded-2xl border border-slate-700 space-y-3">
                <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 font-extrabold flex items-center justify-center">
                  03
                </div>
                <div className="font-heading font-bold text-sm text-white">Delay in Receiving Treatment</div>
                <p className="text-slate-400 leading-relaxed">
                  Arriving at facilities lacking blood or C-section surgeons. MCC solves this with live bed & NICU availability tracking.
                </p>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 4. EMERGENCY CONTACT NUMBERS (DIRECT SPEED DIAL DIRECTORY) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white rounded-3xl p-6 sm:p-8 shadow-xl">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-6">
            <div>
              <span className="text-rose-200 text-xs font-extrabold uppercase tracking-wider">
                Direct Emergency Call Lines
              </span>
              <h3 className="font-heading text-2xl sm:text-3xl font-extrabold mt-1">
                Emergency Contact Numbers & Helplines
              </h3>
              <p className="text-xs sm:text-sm text-rose-100 mt-1">
                Dial immediately from any phone without requiring mobile data or credit balance.
              </p>
            </div>

            <button
              onClick={openSosModal}
              className="bg-white text-red-700 hover:bg-rose-50 px-6 py-3 rounded-2xl font-extrabold text-sm shadow-lg flex items-center gap-2 shrink-0 animate-emergency"
            >
              <Ambulance className="w-5 h-5 text-red-600" />
              <span>TRIGGER DIGITAL SOS</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {EMERGENCY_HOTLINES.map((hotline, idx) => (
              <div key={idx} className="bg-white/10 hover:bg-white/15 border border-white/20 rounded-2xl p-4 flex flex-col justify-between transition">
                <div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[10px] font-bold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded text-white">
                      {hotline.badge}
                    </span>
                    <PhoneCall className="w-4 h-4 text-rose-200" />
                  </div>
                  <div className="font-heading font-extrabold text-3xl text-white mt-2">
                    {hotline.number}
                  </div>
                  <div className="font-bold text-xs text-rose-100 mt-1">
                    {hotline.title}
                  </div>
                  <p className="text-[11px] text-rose-200/90 mt-1 line-clamp-2">
                    {hotline.desc}
                  </p>
                </div>
                <a
                  href={`tel:${hotline.number.replace(/[^0-9]/g, '')}`}
                  className="mt-4 w-full py-2 bg-white hover:bg-rose-50 text-red-700 font-extrabold text-xs rounded-xl text-center shadow-sm transition block"
                >
                  Speed Dial {hotline.number}
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. IMPORTANT HEALTH UPDATES & ADVISORIES */}
      <section id="health-updates" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-extrabold uppercase text-rose-600 tracking-wider">
              <Bell className="w-3.5 h-3.5" />
              <span>Official Maternal Health Advisories</span>
            </div>
            <h2 className="font-heading text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              Important Health Updates & Camps
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Verified announcements on maternal immunization campaigns, free rural ultrasound camps, and seasonal advisories.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {healthUpdates.map((upd) => (
            <div
              key={upd.id}
              className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs hover:border-rose-200 transition space-y-3 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-rose-50 text-rose-700 border border-rose-200">
                    {upd.badge}
                  </span>
                  <span className="text-slate-400 font-medium text-[11px]">
                    {upd.date}
                  </span>
                </div>

                <h3 className="font-heading font-bold text-base text-slate-900">
                  {upd.title}
                </h3>

                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {upd.summary}
                </p>

                {selectedUpdate === upd.id && (
                  <div className="mt-3 p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700 leading-relaxed animate-in fade-in">
                    <p>{upd.details}</p>
                    <div className="mt-2 text-[10px] text-slate-400 font-semibold uppercase">
                      Issued by: {upd.source}
                    </div>
                  </div>
                )}
              </div>

              <div className="pt-2 flex items-center justify-between text-xs">
                <button
                  type="button"
                  onClick={() => setSelectedUpdate(selectedUpdate === upd.id ? null : upd.id)}
                  className="text-rose-600 font-bold hover:underline"
                >
                  {selectedUpdate === upd.id ? 'Hide Details' : 'Read Full Advisory &rarr;'}
                </button>
                <span className="text-[11px] text-slate-400">{upd.source}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Warning signs snapshot */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <span className="text-rose-600 text-xs font-bold uppercase tracking-wide">Emergency Vigilance</span>
              <h3 className="font-heading font-extrabold text-2xl text-slate-900 mt-1">
                Recognize the 6 Pregnancy Red Flags
              </h3>
            </div>
            <button
              onClick={() => {
                setActiveTab('care');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="text-xs font-bold text-rose-600 hover:text-rose-700 flex items-center gap-1"
            >
              <span>View Full Danger Signs Guide</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            {PREGNANCY_RED_FLAGS.map((rf) => (
              <div key={rf.id} className="p-4 rounded-2xl border border-slate-100 bg-slate-50/60 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900">{rf.title}</span>
                  <AlertOctagon className="w-4 h-4 text-red-500 shrink-0" />
                </div>
                <p className="text-slate-500 text-[11px]">{rf.symptom}</p>
                <div className="text-rose-700 font-semibold text-[11px] pt-1 border-t border-slate-200">
                  {rf.immediateAction}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

    </div>
  );
};
