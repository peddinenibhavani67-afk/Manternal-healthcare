import React, { useState } from 'react';
import { 
  HospitalMap 
} from '../components/HospitalMap';
import { 
  Hospital as HospitalIcon, 
  MapPin, 
  PhoneCall, 
  Navigation, 
  CheckCircle2, 
  AlertCircle, 
  Search, 
  Filter, 
  Ambulance, 
  ShieldCheck, 
  Compass, 
  Layers,
  HeartPulse,
  Activity,
  ArrowRight,
  Send,
  Building,
  Plus
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Hospital, FacilityType, HospitalReferral } from '../types';

export const FindHospitalsPage: React.FC<{ setActiveTab?: (tab: string) => void }> = ({ setActiveTab }) => {
  const { 
    hospitals, 
    userLocation, 
    selectedFacilityForRoute, 
    setSelectedFacilityForRoute,
    openSosModal,
    hospitalReferrals,
    createReferral
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [filterCSectionOnly, setFilterCSectionOnly] = useState(false);
  const [filterBloodBankOnly, setFilterBloodBankOnly] = useState(false);
  const [filterGovtOnly, setFilterGovtOnly] = useState(false);

  // Tab: Facilities Directory vs Emergency Hospital Referrals
  const [activeSection, setActiveSection] = useState<'hospitals' | 'referrals'>('hospitals');

  // Referral Modal
  const [isReferralModalOpen, setIsReferralModalOpen] = useState(false);
  const [refPatientName, setRefPatientName] = useState('');
  const [refGestation, setRefGestation] = useState(34);
  const [refFromFacility, setRefFromFacility] = useState('Aarogya Rural PHC');
  const [refToHospital, setRefToHospital] = useState(hospitals[0]?.name || 'District Mother & Child Specialty Hospital');
  const [refReason, setRefReason] = useState('Severe preeclampsia or obstructed labor needing emergency C-Section');
  const [refPriority, setRefPriority] = useState<HospitalReferral['priority']>('emergency_csection');

  // Filter logic
  const filteredHospitals = hospitals.filter(hosp => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = hosp.name.toLowerCase().includes(q);
      const matchDistrict = hosp.district.toLowerCase().includes(q);
      const matchAddress = hosp.address.toLowerCase().includes(q);
      if (!matchName && !matchDistrict && !matchAddress) return false;
    }

    if (selectedType !== 'all' && hosp.type !== selectedType) {
      return false;
    }

    if (filterCSectionOnly && !hosp.emergencyCSection24x7) {
      return false;
    }

    if (filterBloodBankOnly && !hosp.bloodBankOnSite) {
      return false;
    }

    if (filterGovtOnly && !hosp.freeGovtSubsidized) {
      return false;
    }

    return true;
  });

  const handleSelectHospital = (hosp: Hospital) => {
    setSelectedFacilityForRoute(hosp);
  };

  const handleClearRoute = () => {
    setSelectedFacilityForRoute(null);
  };

  const handleCreateReferralSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!refPatientName.trim()) return;

    createReferral({
      patientName: refPatientName.trim(),
      gestationalWeek: Number(refGestation),
      referringFacility: refFromFacility,
      receivingHospital: refToHospital,
      referralReason: refReason,
      status: 'bed_reserved',
      priority: refPriority
    });

    setIsReferralModalOpen(false);
    setRefPatientName('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header & Subtitle */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-bold uppercase tracking-wider mb-2">
            <Compass className="w-3.5 h-3.5" />
            <span>Interactive Hospital Directory & Referral Grid</span>
          </div>
          <h1 className="font-heading text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Find Nearby Hospitals & Maternity Centers
          </h1>
          <p className="text-sm sm:text-base text-slate-600 mt-1 max-w-2xl">
            Locate 24/7 labor wards, available maternity beds, emergency C-Section facilities, and coordinate inter-hospital referrals.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {setActiveTab && (
            <button
              onClick={() => setActiveTab('hospital_reg')}
              className="bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl border border-rose-200 flex items-center gap-1.5 cursor-pointer transition shadow-xs"
            >
              <Plus className="w-4 h-4 text-rose-600" />
              <span>Register Hospital</span>
            </button>
          )}

          <button
            onClick={() => setIsReferralModalOpen(true)}
            className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-xs flex items-center gap-2 cursor-pointer"
          >
            <Send className="w-4 h-4 text-rose-400" />
            <span>Initiate Hospital Referral</span>
          </button>

          <button
            onClick={openSosModal}
            className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-md flex items-center gap-2 cursor-pointer animate-emergency"
          >
            <Ambulance className="w-4 h-4" />
            <span>Emergency SOS</span>
          </button>
        </div>
      </div>

      {/* Mode Switcher Tabs */}
      <div className="flex border-b border-slate-200 gap-4 text-sm font-bold">
        <button
          onClick={() => setActiveSection('hospitals')}
          className={`pb-3 border-b-2 transition flex items-center gap-2 ${
            activeSection === 'hospitals'
              ? 'border-rose-600 text-rose-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Building className="w-4 h-4" />
          <span>Hospitals & Facilities Directory ({hospitals.length})</span>
        </button>

        <button
          onClick={() => setActiveSection('referrals')}
          className={`pb-3 border-b-2 transition flex items-center gap-2 ${
            activeSection === 'referrals'
              ? 'border-rose-600 text-rose-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Send className="w-4 h-4" />
          <span>Emergency Hospital Referrals ({hospitalReferrals.length})</span>
        </button>
      </div>

      {activeSection === 'hospitals' ? (
        <>
          {/* Filter and Search Bar */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
              
              {/* Search box */}
              <div className="md:col-span-5 relative">
                <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by hospital name, district, or address..."
                  className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                />
              </div>

              {/* Facility Type Selector */}
              <div className="md:col-span-4">
                <select
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none bg-white text-slate-700"
                >
                  <option value="all">All Facility Types (District, Specialty, PHC)</option>
                  <option value="District Hospital">District Hospitals (Comprehensive)</option>
                  <option value="Maternity Specialty Center">Maternity Specialty Centers</option>
                  <option value="Sub-Divisional Hospital">Sub-Divisional Hospitals</option>
                  <option value="Primary Health Center (24/7)">Primary Health Centers (PHC)</option>
                  <option value="Community Health Center">Community Health Centers</option>
                </select>
              </div>

              {/* Quick Counter */}
              <div className="md:col-span-3 flex items-center justify-between md:justify-end text-xs font-semibold text-slate-500">
                <span>Showing: <strong className="text-rose-600">{filteredHospitals.length}</strong> facilities</span>
                {selectedFacilityForRoute && (
                  <button
                    onClick={handleClearRoute}
                    className="text-slate-500 hover:text-slate-800 underline text-xs ml-3"
                  >
                    Reset Route
                  </button>
                )}
              </div>
            </div>

            {/* Feature Checkbox Toggles */}
            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 text-xs">
              <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Filter by facility features:</span>
              
              <button
                onClick={() => setFilterCSectionOnly(!filterCSectionOnly)}
                className={`px-3 py-1.5 rounded-lg font-semibold border transition cursor-pointer flex items-center gap-1.5 ${
                  filterCSectionOnly
                    ? 'bg-red-50 border-red-500 text-red-700 ring-1 ring-red-400'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Activity className="w-3.5 h-3.5" />
                <span>24/7 Emergency C-Section Only</span>
              </button>

              <button
                onClick={() => setFilterBloodBankOnly(!filterBloodBankOnly)}
                className={`px-3 py-1.5 rounded-lg font-semibold border transition cursor-pointer flex items-center gap-1.5 ${
                  filterBloodBankOnly
                    ? 'bg-rose-50 border-rose-500 text-rose-700 ring-1 ring-rose-400'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <HeartPulse className="w-3.5 h-3.5" />
                <span>Blood Bank / Storage On-Site</span>
              </button>

              <button
                onClick={() => setFilterGovtOnly(!filterGovtOnly)}
                className={`px-3 py-1.5 rounded-lg font-semibold border transition cursor-pointer flex items-center gap-1.5 ${
                  filterGovtOnly
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-700 ring-1 ring-emerald-400'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>100% Free / Subsidized Scheme</span>
              </button>
            </div>
          </div>

          {/* Main Layout: Split Map & Facility Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Left / Top Map Container */}
            <div className="lg:col-span-7 sticky top-24 space-y-3">
              <div className="bg-white rounded-3xl p-3 border border-slate-200 shadow-sm overflow-hidden h-[450px] sm:h-[520px]">
                <HospitalMap
                  hospitals={filteredHospitals}
                  selectedHospital={selectedFacilityForRoute}
                  onSelectHospital={handleSelectHospital}
                  userLocation={userLocation}
                  showRoute={true}
                />
              </div>

              {/* Active Route Status Card */}
              {selectedFacilityForRoute ? (
                <div className="bg-gradient-to-r from-rose-50 to-pink-50 border border-rose-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div>
                    <div className="font-bold text-rose-900 flex items-center gap-1.5">
                      <Navigation className="w-4 h-4 text-rose-600" />
                      <span>Route Active to: {selectedFacilityForRoute.name}</span>
                    </div>
                    <div className="text-slate-600 mt-0.5">
                      Distance: <strong>{selectedFacilityForRoute.distanceKm} km</strong> • Estimated Emergency Drive Time: <strong>~{selectedFacilityForRoute.travelTimeMinutes} minutes</strong>
                    </div>
                  </div>
                  <div className="flex gap-2 shrink-0">
                    <a
                      href={`tel:${selectedFacilityForRoute.emergencyPhone}`}
                      className="bg-red-600 hover:bg-red-700 text-white font-bold px-3 py-1.5 rounded-lg flex items-center gap-1"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      <span>Call Hospital ER</span>
                    </a>
                    <button
                      onClick={handleClearRoute}
                      className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 font-medium px-2.5 py-1.5 rounded-lg"
                    >
                      Clear Route
                    </button>
                  </div>
                </div>
              ) : (
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 text-xs text-slate-500 flex items-center gap-2">
                  <Navigation className="w-4 h-4 text-slate-400 shrink-0" />
                  <span>Click <strong>"Get Emergency Directions"</strong> on any hospital below to view the route line on the interactive map.</span>
                </div>
              )}
            </div>

            {/* Right Facility List */}
            <div className="lg:col-span-5 space-y-4">
              <div className="flex items-center justify-between pb-1">
                <h2 className="font-heading font-extrabold text-lg text-slate-900">
                  Nearby Hospitals ({filteredHospitals.length})
                </h2>
                <span className="text-[11px] text-slate-500">Live bed count updated</span>
              </div>

              {filteredHospitals.length === 0 ? (
                <div className="bg-white rounded-2xl p-8 border border-slate-200 text-center space-y-3">
                  <AlertCircle className="w-8 h-8 text-slate-400 mx-auto" />
                  <div className="font-bold text-slate-800">No facilities match your search</div>
                  <p className="text-xs text-slate-500">Try resetting your filters.</p>
                </div>
              ) : (
                filteredHospitals.map((hosp) => {
                  const isSelected = selectedFacilityForRoute?.id === hosp.id;
                  return (
                    <div
                      key={hosp.id}
                      className={`bg-white rounded-2xl p-4 sm:p-5 border transition-all space-y-3 shadow-xs ${
                        isSelected
                          ? 'border-rose-500 ring-2 ring-rose-300 shadow-md'
                          : 'border-slate-200 hover:border-rose-200'
                      }`}
                    >
                      {/* Name, Type & Distance */}
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap mb-1">
                            <span className="text-[10px] font-extrabold uppercase tracking-wider text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full inline-block">
                              {hosp.type}
                            </span>
                            {hosp.licenseNumber && (
                              <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded">
                                Lic: {hosp.licenseNumber}
                              </span>
                            )}
                            {hosp.isVerified && (
                              <span className="text-[10px] font-extrabold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                Verified
                              </span>
                            )}
                          </div>
                          <h3 className="font-heading font-bold text-base text-slate-900">
                            {hosp.name}
                          </h3>
                          <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span>{hosp.address}</span>
                          </p>
                        </div>

                        <div className="text-right shrink-0">
                          <div className="font-extrabold text-sm text-slate-900">
                            {hosp.distanceKm} km
                          </div>
                          <div className="text-[11px] text-slate-500">
                            ~{hosp.travelTimeMinutes} mins
                          </div>
                        </div>
                      </div>

                      {/* Available Beds Badges */}
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2 text-emerald-900">
                          <div className="text-[10px] uppercase font-bold text-emerald-700">Available Maternity Beds</div>
                          <div className="font-extrabold text-base text-emerald-800">
                            {hosp.availableMaternityBeds} <span className="text-xs font-normal text-emerald-600">/ {hosp.totalMaternityBeds}</span>
                          </div>
                        </div>

                        <div className="bg-sky-50 border border-sky-200 rounded-xl p-2 text-sky-900">
                          <div className="text-[10px] uppercase font-bold text-sky-700">Available NICU Beds</div>
                          <div className="font-extrabold text-base text-sky-800">
                            {hosp.availableNicuBeds} <span className="text-xs font-normal text-sky-600">({hosp.nicuLevel})</span>
                          </div>
                        </div>
                      </div>

                      {/* Hospital Facilities / Services List */}
                      <div className="space-y-1">
                        <div className="text-[10px] uppercase font-bold text-slate-400">Hospital Facilities & Specialized Care:</div>
                        <div className="flex flex-wrap gap-1 text-[11px]">
                          {hosp.services.map((srv, idx) => (
                            <span key={idx} className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md font-medium">
                              {srv}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Hospital Contact Details */}
                      <div className="pt-2 border-t border-slate-100 space-y-1">
                        <div className="text-[10px] uppercase font-bold text-slate-400">Hospital Contact Details:</div>
                        <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600">
                          <div>
                            <span className="text-slate-400 block font-semibold">General Reception:</span>
                            <a href={`tel:${hosp.phone}`} className="text-slate-800 font-bold hover:underline">{hosp.phone}</a>
                          </div>
                          <div>
                            <span className="text-slate-400 block font-semibold">Ambulance Desk:</span>
                            <a href={`tel:${hosp.ambulancePhone}`} className="text-rose-600 font-bold hover:underline">{hosp.ambulancePhone}</a>
                          </div>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="pt-2 flex items-center gap-2 border-t border-slate-100">
                        <button
                          onClick={() => handleSelectHospital(hosp)}
                          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                            isSelected
                              ? 'bg-rose-600 text-white shadow-xs'
                              : 'bg-rose-50 hover:bg-rose-100 text-rose-700'
                          }`}
                        >
                          <Navigation className="w-3.5 h-3.5" />
                          <span>{isSelected ? 'Route Active on Map' : 'Get Emergency Directions'}</span>
                        </button>

                        <a
                          href={`tel:${hosp.emergencyPhone}`}
                          className="py-2 px-3 rounded-xl text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white flex items-center justify-center gap-1.5 transition shrink-0"
                        >
                          <PhoneCall className="w-3.5 h-3.5 text-rose-400" />
                          <span>Call ER: {hosp.emergencyPhone}</span>
                        </a>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

          </div>
        </>
      ) : (
        /* EMERGENCY HOSPITAL REFERRALS SECTION */
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-rose-600 text-xs font-bold uppercase tracking-wider">
                  Inter-Facility Obstetric Coordination
                </span>
                <h2 className="font-heading font-extrabold text-2xl text-slate-900 mt-1">
                  Emergency Hospital Referrals & Inter-Facility Transfers
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Connecting Primary Health Centers (PHCs) directly to higher tertiary obstetric trauma centers with advance bed reservation.
                </p>
              </div>

              <button
                onClick={() => setIsReferralModalOpen(true)}
                className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs flex items-center gap-2 self-start sm:self-auto"
              >
                <Plus className="w-4 h-4" />
                <span>New Emergency Referral</span>
              </button>
            </div>

            <div className="divide-y divide-slate-100">
              {hospitalReferrals.map((ref) => (
                <div key={ref.id} className="py-4 space-y-2.5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-sm">{ref.patientName}</span>
                        <span className="text-xs text-slate-500">({ref.gestationalWeek} Weeks Gestation)</span>
                        <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase bg-red-100 text-red-700">
                          {ref.priority.replace('_', ' ')}
                        </span>
                      </div>
                      <div className="text-xs text-slate-600 mt-0.5">
                        Transfer from: <strong>{ref.referringFacility}</strong> &rarr; Target: <strong className="text-rose-700">{ref.receivingHospital}</strong>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-bold uppercase ${
                        ref.status === 'in_transit' ? 'bg-amber-100 text-amber-800 animate-pulse' : ref.status === 'bed_reserved' ? 'bg-sky-100 text-sky-800' : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {ref.status.replace('_', ' ')}
                      </span>
                      <span className="text-[11px] text-slate-400">{ref.timestamp}</span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <strong>Referral Clinical Summary:</strong> {ref.referralReason}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Referral Modal */}
      {isReferralModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 space-y-4">
            <h3 className="font-heading font-extrabold text-xl text-slate-900">
              Initiate Emergency Maternal Referral
            </h3>
            <p className="text-xs text-slate-500">
              Pre-alert receiving hospital to prepare C-Section theater, blood units, and neonatal incubators.
            </p>

            <form onSubmit={handleCreateReferralSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-bold mb-1">Patient Name *</label>
                <input
                  type="text"
                  required
                  value={refPatientName}
                  onChange={(e) => setRefPatientName(e.target.value)}
                  placeholder="e.g. Rekha Devi"
                  className="w-full px-3 py-2 border rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Gestation (Weeks) *</label>
                  <input
                    type="number"
                    min="4"
                    max="44"
                    required
                    value={refGestation}
                    onChange={(e) => setRefGestation(Number(e.target.value))}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Priority / Emergency Need *</label>
                  <select
                    value={refPriority}
                    onChange={(e) => setRefPriority(e.target.value as any)}
                    className="w-full px-3 py-2 border rounded-xl bg-white"
                  >
                    <option value="emergency_csection">Emergency C-Section</option>
                    <option value="nicu_needed">NICU Nursery Required</option>
                    <option value="blood_transfusion">Acute Hemorrhage / Blood Needed</option>
                    <option value="routine">High-Risk Consultation</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Referring Clinic/PHC *</label>
                  <input
                    type="text"
                    required
                    value={refFromFacility}
                    onChange={(e) => setRefFromFacility(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Target Receiving Hospital *</label>
                  <select
                    value={refToHospital}
                    onChange={(e) => setRefToHospital(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl bg-white"
                  >
                    {hospitals.map(h => (
                      <option key={h.id} value={h.name}>{h.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Clinical Reasons & Current Status *</label>
                <textarea
                  rows={3}
                  required
                  value={refReason}
                  onChange={(e) => setRefReason(e.target.value)}
                  placeholder="e.g. Obstructed labor, fetal bradycardia, meconium stained liquor..."
                  className="w-full px-3 py-2 border rounded-xl resize-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsReferralModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow-xs"
                >
                  Transmit Referral & Reserve Bed
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
