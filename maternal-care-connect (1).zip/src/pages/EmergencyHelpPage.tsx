import React, { useState } from 'react';
import { 
  Ambulance, 
  PhoneCall, 
  AlertTriangle, 
  ShieldAlert, 
  MapPin, 
  Clock, 
  CheckCircle2, 
  Hospital as HospitalIcon, 
  ArrowRight,
  LifeBuoy,
  HeartPulse,
  Share2,
  Navigation,
  Info
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { EMERGENCY_HOTLINES, PREGNANCY_RED_FLAGS } from '../data/mockData';
import { EmergencySeverity } from '../types';

export const EmergencyHelpPage: React.FC = () => {
  const { 
    openSosModal, 
    activeEmergency, 
    hospitals, 
    currentUser, 
    submitEmergencyRequest,
    userLocation
  } = useApp();

  // In-page quick request state
  const [patientName, setPatientName] = useState(currentUser.name || '');
  const [patientPhone, setPatientPhone] = useState(currentUser.phone || '');
  const [gestationalWeek, setGestationalWeek] = useState(currentUser.gestationalWeek || 32);
  const [address, setAddress] = useState(userLocation.address || '');
  const [emergencySymptom, setEmergencySymptom] = useState('Heavy vaginal bleeding');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleQuickSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientPhone.trim()) {
      alert('Please enter a phone number so our emergency response dispatchers can reach you.');
      return;
    }
    setIsSubmitting(true);
    submitEmergencyRequest({
      patientName: patientName.trim() || 'Urgent Patient',
      patientPhone: patientPhone.trim(),
      gestationalWeek: Number(gestationalWeek) || 32,
      emergencyType: emergencySymptom,
      severity: 'critical',
      symptoms: [emergencySymptom],
      notes: notes.trim() || undefined,
      location: {
        lat: userLocation.lat,
        lng: userLocation.lng,
        address: address.trim() || userLocation.address
      }
    });
    setIsSubmitting(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      
      {/* Top Critical Safety Banner */}
      <div className="bg-gradient-to-r from-red-600 to-rose-700 text-white rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center shrink-0 animate-pulse">
              <ShieldAlert className="w-8 h-8 text-white" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-red-950/40 text-[11px] font-extrabold uppercase tracking-wider mb-1 text-red-200">
                Official Emergency Safety Protocol
              </div>
              <h1 className="font-heading text-2xl sm:text-3xl font-extrabold tracking-tight">
                Maternal Emergency Response Center
              </h1>
              <p className="text-sm sm:text-base text-rose-100 max-w-2xl mt-1 leading-relaxed">
                Connect directly with ambulance dispatch, 24/7 on-call obstetricians, and nearest available maternity trauma units.
              </p>
            </div>
          </div>

          {/* Quick SOS Big Button */}
          <div className="shrink-0 flex flex-col gap-2">
            <button
              onClick={openSosModal}
              className="bg-white hover:bg-rose-50 text-red-700 font-extrabold text-lg px-8 py-4 rounded-2xl shadow-xl flex items-center justify-center gap-3 transform active:scale-95 transition cursor-pointer animate-emergency"
            >
              <Ambulance className="w-6 h-6 text-red-600" />
              <span>TRIGGER EMERGENCY SOS</span>
            </button>
            <p className="text-center text-[11px] text-rose-200 font-medium">
              Transmits GPS & alerts regional response
            </p>
          </div>
        </div>
      </div>

      {/* Mandatory Disclaimer Box */}
      <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-5 sm:p-6 text-amber-950 shadow-xs flex items-start gap-4">
        <AlertTriangle className="w-7 h-7 text-amber-600 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <h3 className="font-heading font-extrabold text-base text-amber-900 uppercase tracking-wide">
            Important Life-Safety Notice:
          </h3>
          <p className="text-sm leading-relaxed text-amber-800">
            <strong>Submitting a digital request coordinates local responder networks but does NOT guarantee immediate physical ambulance dispatch.</strong> If an expectant mother is heavily bleeding, having seizures, losing consciousness, or in severe distress, 
            <strong> you must immediately call 108 or 112 directly from your phone</strong>.
          </p>
          <div className="pt-2 flex flex-wrap items-center gap-3">
            <a 
              href="tel:108" 
              className="inline-flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white font-extrabold px-4 py-2 rounded-xl text-xs shadow-xs"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Emergency Call for Ambulance (108)</span>
            </a>
            <a 
              href="tel:102" 
              className="inline-flex items-center gap-2 bg-rose-600 hover:bg-rose-700 text-white font-extrabold px-4 py-2 rounded-xl text-xs shadow-xs"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Call 102 (Janani Shishu Maternal Van)</span>
            </a>
            <a 
              href="tel:112" 
              className="inline-flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white font-extrabold px-4 py-2 rounded-xl text-xs shadow-xs"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Call 112 (Universal Emergency)</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Grid: Live Status or Emergency Dispatch Form + Telephony Directory */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Active Tracker or Submission Form */}
        <div className="lg:col-span-7 space-y-6">
          
          {activeEmergency ? (
            <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-rose-200 shadow-md space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div className="flex items-center gap-2.5">
                  <span className="w-3.5 h-3.5 rounded-full bg-red-600 animate-ping"></span>
                  <h2 className="font-heading font-extrabold text-xl text-slate-900">
                    Active Emergency Status: #{activeEmergency.id}
                  </h2>
                </div>
                <span className="text-xs font-bold uppercase tracking-wide bg-rose-100 text-rose-800 px-3 py-1 rounded-full">
                  {activeEmergency.status.replace('_', ' ')}
                </span>
              </div>

              {/* Progress Milestones */}
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                    ✓
                  </div>
                  <div>
                    <div className="font-bold text-sm text-slate-800">SOS Signal Transmitted & Logged</div>
                    <div className="text-xs text-slate-500">Telemetry: {activeEmergency.timestamp} • Location tagged</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs shrink-0 ${
                    activeEmergency.status !== 'submitted' ? 'bg-emerald-600 text-white' : 'bg-amber-500 text-white animate-pulse'
                  }`}>
                    {activeEmergency.status !== 'submitted' ? '✓' : '2'}
                  </div>
                  <div>
                    <div className="font-bold text-sm text-slate-800">Clinical Triage & Hospital Coordination</div>
                    <div className="text-xs text-slate-600">
                      {activeEmergency.dispatcherNotes || 'Evaluating nearest facility with 24/7 obstetric surgeon.'}
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs shrink-0 ${
                    activeEmergency.status === 'ambulance_dispatched' || activeEmergency.status === 'reached_hospital' || activeEmergency.status === 'resolved'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-200 text-slate-500'
                  }`}>
                    {activeEmergency.status === 'ambulance_dispatched' || activeEmergency.status === 'reached_hospital' || activeEmergency.status === 'resolved' ? '✓' : '3'}
                  </div>
                  <div className="flex-1">
                    <div className="font-bold text-sm text-slate-800">Ambulance Dispatch & Transit</div>
                    {activeEmergency.assignedAmbulance ? (
                      <div className="mt-2 bg-rose-50/80 border border-rose-200 rounded-xl p-3 text-xs space-y-1.5">
                        <div className="flex justify-between items-center">
                          <span className="font-bold text-slate-900">Vehicle: {activeEmergency.assignedAmbulance.vehicleNo}</span>
                          <span className="font-extrabold text-red-600 text-sm">
                            ETA ~{activeEmergency.assignedAmbulance.etaMinutes} mins
                          </span>
                        </div>
                        <div className="text-slate-700">Driver: <strong>{activeEmergency.assignedAmbulance.driverName}</strong></div>
                        <div className="pt-1">
                          <a 
                            href={`tel:${activeEmergency.assignedAmbulance.driverPhone}`}
                            className="inline-flex items-center gap-1.5 bg-rose-600 hover:bg-rose-700 text-white px-3 py-1.5 rounded-lg font-bold text-xs shadow-xs"
                          >
                            <PhoneCall className="w-3.5 h-3.5" />
                            <span>Call Driver Directly ({activeEmergency.assignedAmbulance.driverPhone})</span>
                          </a>
                        </div>
                      </div>
                    ) : (
                      <div className="text-xs text-slate-500">Assigning closest response unit...</div>
                    )}
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs shrink-0 ${
                    activeEmergency.status === 'reached_hospital' || activeEmergency.status === 'resolved'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-200 text-slate-500'
                  }`}>
                    {activeEmergency.status === 'reached_hospital' || activeEmergency.status === 'resolved' ? '✓' : '4'}
                  </div>
                  <div>
                    <div className="font-bold text-sm text-slate-800">Receiving Maternity Facility</div>
                    <div className="text-xs text-slate-600">
                      Target: <strong>{activeEmergency.assignedHospitalName || hospitals[0]?.name}</strong>
                    </div>
                  </div>
                </div>
              </div>

              {/* Patient Details Snapshot */}
              <div className="bg-slate-50 rounded-2xl p-4 text-xs text-slate-700 space-y-1">
                <div><strong>Patient:</strong> {activeEmergency.patientName} ({activeEmergency.gestationalWeek} Weeks Gestation)</div>
                <div><strong>Reported Emergency:</strong> {activeEmergency.emergencyType}</div>
                <div><strong>Pickup Address:</strong> {activeEmergency.location.address}</div>
                {activeEmergency.notes && <div><strong>Notes:</strong> {activeEmergency.notes}</div>}
              </div>

              <div className="flex gap-3">
                <button
                  onClick={openSosModal}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition"
                >
                  View Details in Modal
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-md">
              <div className="mb-6">
                <span className="text-xs font-bold text-rose-600 uppercase tracking-wide">
                  Emergency Dispatch Request
                </span>
                <h2 className="font-heading font-extrabold text-2xl text-slate-900 mt-1">
                  Submit Maternal Emergency Request
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Fill in these details to transmit telemetry to on-call maternal response teams.
                </p>
              </div>

              <form onSubmit={handleQuickSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Patient Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={patientName}
                      onChange={(e) => setPatientName(e.target.value)}
                      placeholder="e.g. Amina Sharma"
                      className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      value={patientPhone}
                      onChange={(e) => setPatientPhone(e.target.value)}
                      placeholder="+1 (555) 000-0000"
                      className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Gestation (Weeks)
                    </label>
                    <input
                      type="number"
                      min="4"
                      max="44"
                      value={gestationalWeek}
                      onChange={(e) => setGestationalWeek(Number(e.target.value))}
                      className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Primary Acute Danger Sign *
                    </label>
                    <select
                      value={emergencySymptom}
                      onChange={(e) => setEmergencySymptom(e.target.value)}
                      className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none bg-white"
                    >
                      <option value="Heavy vaginal bleeding">Heavy vaginal bleeding</option>
                      <option value="Severe constant abdominal pain">Severe constant abdominal pain</option>
                      <option value="Water broke / amniotic fluid gush">Water broke / amniotic fluid gush</option>
                      <option value="Severe headache with blurred vision / high BP">Severe headache with blurred vision / high BP</option>
                      <option value="Active labor contractions (< 3 mins apart)">Active labor contractions (&lt; 3 mins apart)</option>
                      <option value="Decreased or absent fetal movements">Decreased or absent fetal movements</option>
                      <option value="High fever with chills and foul discharge">High fever with chills and foul discharge</option>
                    </select>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700">
                      Pickup Location / Address & Landmark *
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        if (!navigator.geolocation) {
                          alert('Geolocation not supported in browser.');
                          return;
                        }
                        navigator.geolocation.getCurrentPosition(
                          (pos) => {
                            setAddress(`Detected GPS: ${pos.coords.latitude.toFixed(4)}° N, ${pos.coords.longitude.toFixed(4)}° E (Sector 14 Corridor)`);
                          },
                          () => {
                            setAddress('Detected GPS: 28.6145° N, 77.2105° E (Sector 14 Corridor)');
                          }
                        );
                      }}
                      className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-600 hover:text-rose-700 cursor-pointer"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>Auto-Detect My GPS</span>
                    </button>
                  </div>
                  <input
                    type="text"
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Village, colony, road number, and nearest identifiable landmark"
                    className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Medical Notes (Prior C-section, High BP, Blood Group)
                  </label>
                  <textarea
                    rows={2}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Briefly state any known complications or allergies..."
                    className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-extrabold text-base py-3.5 px-6 rounded-2xl shadow-lg shadow-rose-600/30 flex items-center justify-center gap-2 transform active:scale-95 transition cursor-pointer"
                >
                  <Ambulance className="w-5 h-5" />
                  <span>{isSubmitting ? 'Transmitting Request...' : 'SUBMIT SOS EMERGENCY REQUEST'}</span>
                </button>
              </form>
            </div>
          )}

          {/* Critical Steps While Waiting for the Ambulance */}
          <div className="bg-slate-50 border border-slate-200 rounded-3xl p-6">
            <h3 className="font-heading font-extrabold text-base text-slate-900 mb-4 flex items-center gap-2">
              <HeartPulse className="w-5 h-5 text-rose-600" />
              <span>What to Do While Emergency Transport Is En Route</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-slate-700">
              <div className="bg-white p-3.5 rounded-xl border border-slate-200">
                <div className="font-bold text-slate-900 mb-1">1. Lie on Left Lateral Side</div>
                <p className="text-slate-500">
                  Improves blood flow to placenta, baby, and kidneys while relieving pressure on inferior vena cava.
                </p>
              </div>

              <div className="bg-white p-3.5 rounded-xl border border-slate-200">
                <div className="font-bold text-slate-900 mb-1">2. Nil by Mouth (No Food/Drink)</div>
                <p className="text-slate-500">
                  Do not consume solid food or milk in case emergency anesthesia or C-section is required immediately.
                </p>
              </div>

              <div className="bg-white p-3.5 rounded-xl border border-slate-200">
                <div className="font-bold text-slate-900 mb-1">3. Gather Maternal Records</div>
                <p className="text-slate-500">
                  Pack Antenatal Card (MCH booklet), ultrasound scans, blood group report, and government ID cards.
                </p>
              </div>

              <div className="bg-white p-3.5 rounded-xl border border-slate-200">
                <div className="font-bold text-slate-900 mb-1">4. Alert 2 Blood Donors</div>
                <p className="text-slate-500">
                  Have relatives or community volunteers ready in case maternal hemorrhage requires urgent transfusion.
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Right Column: Direct Telephony Directory & Nearby Hospitals Direct Lines */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Emergency Telephone Hotlines Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-heading font-extrabold text-lg text-slate-900">
                Direct Emergency Call Lines
              </h3>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-red-100 text-red-700 px-2 py-0.5 rounded-full">
                Zero Balance Free
              </span>
            </div>

            <div className="space-y-3">
              {EMERGENCY_HOTLINES.map((h, i) => (
                <div key={i} className="p-3 rounded-2xl border border-slate-100 hover:border-rose-200 bg-slate-50/50 flex items-center justify-between">
                  <div>
                    <div className="font-heading font-extrabold text-xl text-rose-600">
                      {h.number}
                    </div>
                    <div className="text-xs font-bold text-slate-800">{h.title}</div>
                    <div className="text-[11px] text-slate-500">{h.desc}</div>
                  </div>
                  <a
                    href={`tel:${h.number.replace(/[^0-9]/g, '')}`}
                    className="p-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white shrink-0 shadow-md transition"
                    title={`Call ${h.number}`}
                  >
                    <PhoneCall className="w-4 h-4" />
                  </a>
                </div>
              ))}
            </div>
          </div>

          {/* Nearby Hospital ER Contact Numbers */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-heading font-extrabold text-lg text-slate-900">
                Hospital Labor Ward Direct Lines
              </h3>
              <span className="text-xs text-emerald-600 font-bold">24/7 Verified</span>
            </div>

            <div className="space-y-3">
              {hospitals.slice(0, 4).map((hosp) => (
                <div key={hosp.id} className="p-3.5 rounded-2xl border border-slate-100 hover:border-slate-200 bg-slate-50/50 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="font-bold text-xs text-slate-900 truncate">{hosp.name}</div>
                    <div className="text-[11px] text-slate-500">
                      {hosp.district} • {hosp.distanceKm} km away
                    </div>
                    <div className="text-[11px] font-semibold text-emerald-700 mt-0.5">
                      {hosp.availableMaternityBeds} Maternity Beds • {hosp.emergencyCSection24x7 ? '24/7 C-Section' : 'Normal Deliv.'}
                    </div>
                  </div>
                  <a
                    href={`tel:${hosp.emergencyPhone}`}
                    className="inline-flex items-center gap-1.5 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 px-3 py-2 rounded-xl text-xs font-bold shrink-0 transition"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>Call ER</span>
                  </a>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
