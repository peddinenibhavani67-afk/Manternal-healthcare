export type EmergencySeverity = 'critical' | 'high' | 'moderate';

export type EmergencyStatus = 
  | 'submitted'
  | 'triaged'
  | 'ambulance_dispatched'
  | 'reached_hospital'
  | 'resolved';

export interface LocationCoordinates {
  lat: number;
  lng: number;
  address: string;
  landmark?: string;
  district?: string;
}

export interface AmbulanceInfo {
  id: string;
  vehicleNo: string;
  driverName: string;
  driverPhone: string;
  type: 'Basic Life Support (BLS)' | 'Advanced Neonatal/Maternal ALS' | 'Community Maternal Van';
  status: 'available' | 'dispatched' | 'at_hospital' | 'maintenance';
  currentLocationName: string;
  currentLat: number;
  currentLng: number;
  etaMinutes: number;
  assignedRequestId?: string;
  assignedHospital?: string;
}

export interface EmergencyRequest {
  id: string;
  patientName: string;
  patientPhone: string;
  alternatePhone?: string;
  gestationalWeek: number;
  emergencyType: string;
  severity: EmergencySeverity;
  symptoms: string[];
  notes?: string;
  location: LocationCoordinates;
  status: EmergencyStatus;
  timestamp: string;
  assignedAmbulance?: AmbulanceInfo;
  assignedHospitalId?: string;
  assignedHospitalName?: string;
  dispatcherNotes?: string;
}

export type FacilityType = 
  | 'District Hospital'
  | 'Maternity Specialty Center'
  | 'Sub-Divisional Hospital'
  | 'Primary Health Center (24/7)'
  | 'Community Health Center';

export interface Hospital {
  id: string;
  name: string;
  type: FacilityType;
  address: string;
  district: string;
  phone: string;
  emergencyPhone: string;
  ambulancePhone: string;
  lat: number;
  lng: number;
  distanceKm?: number;
  travelTimeMinutes?: number;
  services: string[];
  emergencyCSection24x7: boolean;
  nicuLevel: 'Level I' | 'Level II' | 'Level III' | 'None';
  bloodBankOnSite: boolean;
  freeGovtSubsidized: boolean;
  totalMaternityBeds: number;
  availableMaternityBeds: number;
  availableNicuBeds: number;
  rating: number;
  reviewsCount: number;
  verifiedDate: string;
  isOpen24x7: boolean;
  licenseNumber?: string;
  isVerified?: boolean;
  registrationStatus?: 'approved' | 'pending' | 'rejected';
}

export type HospitalApprovalStatus = 'pending' | 'approved' | 'rejected';

export interface HospitalRegistration {
  id: string;
  name: string;
  licenseNumber: string;
  type: FacilityType;
  address: string;
  district: string;
  phone: string;
  emergencyPhone: string;
  ambulancePhone: string;
  lat: number;
  lng: number;
  services: string[];
  emergencyCSection24x7: boolean;
  nicuLevel: 'Level I' | 'Level II' | 'Level III' | 'None';
  bloodBankOnSite: boolean;
  freeGovtSubsidized: boolean;
  totalMaternityBeds: number;
  availableMaternityBeds: number;
  availableNicuBeds: number;
  submittedAt: string;
  status: HospitalApprovalStatus;
  reviewedAt?: string;
  rejectionReason?: string;
  verificationNotes?: string;
  licenseDocumentName?: string;
  contactPersonName?: string;
  contactPersonRole?: string;
  contactPersonEmail?: string;
}

export type DoctorSpecialization = 
  | 'Obstetrician & Gynecologist'
  | 'Maternal-Fetal Medicine (High Risk)'
  | 'Certified Nurse Midwife'
  | 'Perinatal Specialist'
  | 'Lactation & Postnatal Consultant';

export interface Doctor {
  id: string;
  name: string;
  title: string;
  specialization: DoctorSpecialization;
  hospitalId: string;
  hospitalName: string;
  experienceYears: number;
  qualification: string;
  languages: string[];
  rating: number;
  reviewsCount: number;
  availableNow: boolean;
  nextAvailableSlot: string;
  consultationFee: number; // 0 for government/subsidized
  avatarUrl: string;
  bio: string;
  supportedModes: ('video' | 'in-person' | 'emergency-call')[];
}

export interface Appointment {
  id: string;
  doctorId: string;
  doctorName: string;
  doctorSpecialization: string;
  doctorAvatar?: string;
  patientName: string;
  patientPhone: string;
  patientEmail?: string;
  date: string;
  timeSlot: string;
  consultType: 'video' | 'in-person' | 'emergency-call';
  gestationalWeek: number;
  reason: string;
  status: 'confirmed' | 'completed' | 'cancelled';
  createdAt: string;
  meetingLink?: string;
  consultationNotes?: string;
  prescriptions?: string[];
}

export interface HealthReminder {
  id: string;
  title: string;
  category: 'checkup' | 'vaccine' | 'nutrition' | 'scan' | 'emergency_plan';
  dueDate: string;
  completed: boolean;
  recommendedWeek?: number;
  description: string;
}

export interface MedicalRecord {
  id: string;
  patientId: string;
  title: string;
  category: 'ultrasound' | 'lab_report' | 'prescription' | 'discharge_summary';
  date: string;
  facility: string;
  doctor: string;
  summary: string;
  keyValues: { [key: string]: string };
  downloadUrl?: string;
}

export interface VitalCheckLog {
  id: string;
  date: string;
  time: string;
  gestationalWeek: number;
  bloodPressureSystolic: number;
  bloodPressureDiastolic: number;
  fetalKickCount: number; // in 2 hours
  weightKg: number;
  bloodSugarMgDl?: number;
  notes?: string;
}

export interface HealthUpdate {
  id: string;
  title: string;
  category: 'advisory' | 'vaccine_drive' | 'rural_camp' | 'nutrition';
  badge: string;
  date: string;
  summary: string;
  details: string;
  source: string;
}

export interface HospitalReferral {
  id: string;
  patientName: string;
  gestationalWeek: number;
  referringFacility: string;
  receivingHospital: string;
  referralReason: string;
  status: 'pending' | 'accepted' | 'bed_reserved' | 'in_transit' | 'received';
  timestamp: string;
  priority: 'emergency_csection' | 'nicu_needed' | 'blood_transfusion' | 'routine';
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'patient' | 'admin' | 'dispatcher';
  gestationalWeek?: number;
  expectedDueDate?: string;
  bloodGroup?: string;
  address?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  emergencyContactRelation?: string;
  preferredHospitalId?: string;
  highRiskFlags?: string[];
  gravidaPara?: string; // e.g. G2P1
  lastMenstrualPeriod?: string;
}
