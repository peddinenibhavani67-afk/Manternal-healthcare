import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { EmergencyModal } from './components/EmergencyModal';
import { HomePage } from './pages/HomePage';
import { EmergencyHelpPage } from './pages/EmergencyHelpPage';
import { FindHospitalsPage } from './pages/FindHospitalsPage';
import { DoctorConsultationPage } from './pages/DoctorConsultationPage';
import { PregnancyCarePage } from './pages/PregnancyCarePage';
import { UserDashboard } from './pages/UserDashboard';
import { AdminDashboard } from './pages/AdminDashboard';
import { HospitalRegistrationPage } from './pages/HospitalRegistrationPage';
import { Ambulance, PhoneCall } from 'lucide-react';

const MainLayout: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('home');
  const { openSosModal, activeEmergency } = useApp();

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans selection:bg-rose-500 selection:text-white">
      {/* Navigation */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Pages */}
      <main className="flex-1">
        {activeTab === 'home' && <HomePage setActiveTab={setActiveTab} />}
        {activeTab === 'emergency' && <EmergencyHelpPage />}
        {activeTab === 'hospitals' && <FindHospitalsPage setActiveTab={setActiveTab} />}
        {activeTab === 'hospital_reg' && <HospitalRegistrationPage setActiveTab={setActiveTab} />}
        {activeTab === 'doctors' && <DoctorConsultationPage />}
        {activeTab === 'care' && <PregnancyCarePage />}
        {activeTab === 'dashboard' && <UserDashboard />}
        {activeTab === 'admin' && <AdminDashboard />}
      </main>

      {/* Floating Emergency Action on Bottom Right for mobile/desktop accessibility */}
      <aside 
        aria-label="Floating Emergency Actions"
        className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-2.5 print:hidden"
      >
        {activeEmergency ? (
          <button
            onClick={() => {
              setActiveTab('emergency');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="bg-amber-500 hover:bg-amber-600 text-white px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 font-bold text-xs animate-bounce cursor-pointer border-2 border-white"
          >
            <Ambulance className="w-4 h-4" />
            <span>Active SOS #{activeEmergency.id} (Track)</span>
          </button>
        ) : null}

        <button
          onClick={openSosModal}
          className="bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white p-4 sm:px-5 sm:py-3.5 rounded-2xl shadow-2xl shadow-rose-600/40 flex items-center gap-2.5 font-extrabold text-sm transform active:scale-95 transition-all animate-emergency cursor-pointer border-2 border-white/80"
          title="Instant Emergency SOS"
        >
          <Ambulance className="w-6 h-6" />
          <span className="hidden sm:inline">SOS EMERGENCY</span>
        </button>
      </aside>

      {/* Emergency Modal */}
      <EmergencyModal />

      {/* Footer */}
      <Footer setActiveTab={setActiveTab} />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
